package io.hmheng.scoring.calculations.standards;

import com.hmhco.api.scoring.view.save.AssignmentItemScoreView;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by nandipatim on 3/5/18.
 */
@Component
public class StandardScoreCalculations {

  public int getItemsCorrectCount(List<AssignmentItemScoreView> itemScores) {

    int itemsCount = 0;

    if (CollectionUtils.isEmpty(itemScores)) {
      return itemsCount;
    }

    itemsCount = (int) itemScores.stream()
      .filter(AssignmentItemScoreView::isItemCorrect).count();

    return itemsCount;
  }

  public int getItemsCorrectPoints(List<AssignmentItemScoreView> itemScores) {

    int itemsCount = 0;

    if (CollectionUtils.isEmpty(itemScores)) {
      return itemsCount;
    }
    itemsCount = itemScores.stream().filter(AssignmentItemScoreView::isItemCorrect)
      .mapToInt(AssignmentItemScoreView::getItemScore).sum();

    return itemsCount;
  }

  public Double getStandardProficiencyScore(int attainedPoints , int standardPoints) {

    return getStandardProficiencyScore(attainedPoints , standardPoints , 2);
  }


  public Double getStandardProficiencyScore(int attainedPoints , int standardPoints , int roundOff) {

    Double standardProficiency = 0.0;

    if (standardPoints > 0) {
      standardProficiency = new BigDecimal(attainedPoints)
        .divide(new BigDecimal(standardPoints), roundOff, BigDecimal.ROUND_HALF_UP)
        .doubleValue();

    }
    return standardProficiency;
  }

  public int getStandardPoints(List<AssignmentItemScoreView> itemScores) {

    int points = 0;

    if (CollectionUtils.isEmpty(itemScores)) {
      return points;
    }

    points = itemScores.stream().mapToInt(assignmentItemScore ->
        (assignmentItemScore != null && assignmentItemScore.getItemMaxScore() == null)
          ? 0 : assignmentItemScore.getItemMaxScore()).sum();

    return points;
  }

  public int getStandardAttainedPoints(List<AssignmentItemScoreView> itemScores) {

    int attainedPoints = 0;

    if (CollectionUtils.isEmpty(itemScores)) {
      return attainedPoints;
    }

    attainedPoints = itemScores.stream().mapToInt(assignmentItemScore ->
        (assignmentItemScore.getItemScore() == null) ? 0 : assignmentItemScore.getItemScore()).sum();

    return attainedPoints;
  }

  public Double getAvgPointsCorrect(int itemCorrectPoints , int totalPoints) {
    return getAvgPointsCorrect(itemCorrectPoints , totalPoints , 2);
  }

  public Double getAvgPointsCorrect(int itemCorrectPoints , int totalPoints , int roundOff) {
    Double avgPointsCorrect = 0.0;

    if (totalPoints > 0) {
      avgPointsCorrect = new BigDecimal(itemCorrectPoints)
        .divide(new BigDecimal(totalPoints), roundOff, BigDecimal.ROUND_HALF_UP).doubleValue();

    }
    return avgPointsCorrect;
  }

  public Double getAvgItemsCorrect(int standardCorrectItemCount , int totalItems) {
    return getAvgItemsCorrect(standardCorrectItemCount , totalItems , 2);
  }

  public Double getAvgItemsCorrect(int standardCorrectItemCount , int totalItems , int roundOff) {
    Double avgItemsCorrect = 0.0;

    if (totalItems > 0) {
      avgItemsCorrect = new BigDecimal(standardCorrectItemCount)
              .divide(new BigDecimal(totalItems), roundOff, BigDecimal.ROUND_HALF_UP).doubleValue();
    }
    return avgItemsCorrect;
  }

}
