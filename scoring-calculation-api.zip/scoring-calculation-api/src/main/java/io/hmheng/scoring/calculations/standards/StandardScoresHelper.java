package io.hmheng.scoring.calculations.standards;

import com.hmhco.api.scoring.view.retrive.StandardScoreView;
import com.hmhco.api.scoring.view.save.AssignmentItemScoreView;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by nandipatim on 3/5/18.
 */

@Component
@Slf4j
public class StandardScoresHelper {

  @Autowired
  private StandardScoreCalculations standardScoreCalculations;

  public List<StandardScoreView> getStandardScores(StandardToItemScores standardToItemScores) {
    Map<UUID, List<AssignmentItemScoreView>> itemScoreViewMapScored = standardToItemScores
        .getItemScoreViewMapScored();
    if (standardToItemScores.getItemScoreViewMapNotScored() == null) {
      standardToItemScores.setItemScoreViewMapNotScored(new HashMap());
    }
    Map<UUID, List<AssignmentItemScoreView>> itemScoreViewMapNotScored = standardToItemScores
        .getItemScoreViewMapNotScored();
    List<StandardScoreView> standardScoreViews = new ArrayList<>();
    itemScoreViewMapScored.forEach( (standard , studentItemScores) -> {
      if (!CollectionUtils.isEmpty(studentItemScores)) {
        StandardScoreView standardScoreView = new StandardScoreView();
        standardScoreView.setStandardId(standard);
        Integer standardPoints = standardScoreCalculations.getStandardPoints(studentItemScores);
        standardScoreView.setTotalPoints(standardPoints);
        Integer itemCount = CollectionUtils.isEmpty(studentItemScores) ? 0 : studentItemScores.size();
        standardScoreView.setItemCount(itemCount);
        List<AssignmentItemScoreView> studentItemScoresNotScored = itemScoreViewMapNotScored
            .get(standard);
        Integer notScoredCount = CollectionUtils.isEmpty(studentItemScoresNotScored) ? 0 :
            studentItemScoresNotScored.size();
        standardScoreView.setTotalItemsCount(itemCount + notScoredCount);
        Integer standardAttainedPoints = standardScoreCalculations
            .getStandardAttainedPoints(studentItemScores);
        standardScoreView.setAttainedPoints(standardAttainedPoints);
        Integer standardCorrectItemCount = standardScoreCalculations
            .getItemsCorrectCount(studentItemScores);
        standardScoreView.setCorrectItemsCount(standardCorrectItemCount);
        Integer standardItemCorrectPoints = standardScoreCalculations
            .getItemsCorrectPoints(studentItemScores);
        standardScoreView.setCorrectItemsPoints(standardItemCorrectPoints);
        standardScoreView.setAvgPointsCorrect(
            standardScoreCalculations.getAvgPointsCorrect(standardItemCorrectPoints ,standardPoints));
        standardScoreView.setAvgItemsCorrect(standardScoreCalculations
            .getAvgItemsCorrect(standardCorrectItemCount ,itemCount));
        standardScoreView.setStandardProficiencyScore(standardScoreCalculations
            .getStandardProficiencyScore(standardAttainedPoints ,standardPoints));
        standardScoreViews.add(standardScoreView);
      }
    });
    return standardScoreViews;
  }

}
