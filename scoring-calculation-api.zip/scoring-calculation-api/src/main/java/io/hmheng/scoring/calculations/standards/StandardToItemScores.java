package io.hmheng.scoring.calculations.standards;

import com.hmhco.api.scoring.view.save.AssignmentItemScoreView;
import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by nandipatim on 3/9/18.
 */

@Data
public class StandardToItemScores {

  Map<UUID, List<AssignmentItemScoreView>> itemScoreViewMapScored;
  Map<UUID, List<AssignmentItemScoreView>> itemScoreViewMapNotScored;

}
