package io.hmheng.scoring.calculations.standards;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * Created by nandipatim on 3/12/18.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@Configuration
public class SpringApplicationTest {

 @Configuration
 @ComponentScan(basePackages = {"io.hmheng.scoring.calculations"})
 static class ContextConfiguration {}

 @Autowired
 protected ApplicationContext ctx;

 @Test
 public void dummy() {

 }
}
