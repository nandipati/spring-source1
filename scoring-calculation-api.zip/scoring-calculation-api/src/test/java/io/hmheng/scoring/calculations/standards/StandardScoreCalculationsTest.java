package io.hmheng.scoring.calculations.standards;

import com.hmhco.api.scoring.utils.ItemResponse;
import com.hmhco.api.scoring.utils.ItemStatus;
import com.hmhco.api.scoring.view.save.AssignmentItemScoreView;

import java.util.ArrayList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

/**
 * Created by nandipatim on 3/12/18.
 */
public class StandardScoreCalculationsTest {

  private List<AssignmentItemScoreView> assignmentItemScoresProvisional =null;

  private List<AssignmentItemScoreView> assignmentItemScores =null;

  StandardScoreCalculations standardScoreCalculations = new StandardScoreCalculations();

  public StandardScoreCalculationsTest() {
  }

  @Before
  public void setup() {

    assignmentItemScoresProvisional = getItemScoresProvisional();
    assignmentItemScores = getItemScores();
  }

  public List<AssignmentItemScoreView> getItemScoresProvisional(){
    assignmentItemScoresProvisional = new ArrayList<>();

    AssignmentItemScoreView assignmentItemScore1 = new AssignmentItemScoreView();
    assignmentItemScore1.setItemRefId("Item1");
    assignmentItemScore1.setItemMaxScore(2);
    assignmentItemScore1.setItemResponse(ItemResponse.CORRECT);
    assignmentItemScore1.setItemScore(2);
    assignmentItemScore1.setItemStatus(ItemStatus.COMPLETED);
    assignmentItemScore1.setItemProficiencyScore(1.00);
    assignmentItemScore1.setManualscoring(Boolean.FALSE);

    AssignmentItemScoreView assignmentItemScore2 = new AssignmentItemScoreView();
    assignmentItemScore2.setItemRefId("Item2");
    assignmentItemScore2.setItemResponse(ItemResponse.NOT_SCORED);
    assignmentItemScore2.setManualscoring(Boolean.TRUE);
    assignmentItemScore2.setItemMaxScore(null);
    assignmentItemScore2.setItemProficiencyScore(null);
    assignmentItemScore2.setItemScore(null);
    assignmentItemScore2.setItemStatus(ItemStatus.NOT_STARTED);

    AssignmentItemScoreView assignmentItemScore3 = new AssignmentItemScoreView();
    assignmentItemScore3.setItemRefId("Item3");
    assignmentItemScore3.setItemResponse(ItemResponse.INCORRECT);
    assignmentItemScore3.setManualscoring(Boolean.FALSE);
    assignmentItemScore3.setItemMaxScore(2);
    assignmentItemScore3.setItemProficiencyScore(0.0);
    assignmentItemScore3.setItemScore(0);
    assignmentItemScore3.setItemStatus(ItemStatus.COMPLETED);

    AssignmentItemScoreView assignmentItemScore4 = new AssignmentItemScoreView();
    assignmentItemScore4.setItemRefId("Item4");
    assignmentItemScore4.setItemResponse(ItemResponse.PARTIAL_CREDIT);
    assignmentItemScore4.setManualscoring(Boolean.TRUE);
    assignmentItemScore4.setItemMaxScore(2);
    assignmentItemScore4.setItemProficiencyScore(0.5);
    assignmentItemScore4.setItemScore(1);
    assignmentItemScore4.setItemStatus(ItemStatus.COMPLETED);

    AssignmentItemScoreView assignmentItemScore5 = new AssignmentItemScoreView();
    assignmentItemScore5.setItemRefId("Item5");
    assignmentItemScore5.setItemResponse(ItemResponse.NOT_ANSWERED);
    assignmentItemScore5.setManualscoring(Boolean.TRUE);
    assignmentItemScore5.setItemMaxScore(2);
    assignmentItemScore5.setItemProficiencyScore(0.00);
    assignmentItemScore5.setItemScore(0);
    assignmentItemScore5.setItemStatus(ItemStatus.COMPLETED);

    assignmentItemScoresProvisional.add(assignmentItemScore1);
    assignmentItemScoresProvisional.add(assignmentItemScore2);
    assignmentItemScoresProvisional.add(assignmentItemScore3);
    assignmentItemScoresProvisional.add(assignmentItemScore4);
    assignmentItemScoresProvisional.add(assignmentItemScore5);

    return assignmentItemScoresProvisional;
  }

  public List<AssignmentItemScoreView> getItemScores(){
    assignmentItemScores = new ArrayList<>();

    AssignmentItemScoreView assignmentItemScore1 = new AssignmentItemScoreView();
    assignmentItemScore1.setItemRefId("Item1");
    assignmentItemScore1.setItemMaxScore(2);
    assignmentItemScore1.setItemResponse(ItemResponse.CORRECT);
    assignmentItemScore1.setItemScore(2);
    assignmentItemScore1.setItemStatus(ItemStatus.COMPLETED);
    assignmentItemScore1.setItemProficiencyScore(1.00);
    assignmentItemScore1.setManualscoring(Boolean.FALSE);

    AssignmentItemScoreView assignmentItemScore2 = new AssignmentItemScoreView();
    assignmentItemScore2.setItemRefId("Item2");
    assignmentItemScore2.setItemResponse(ItemResponse.NOT_ANSWERED);
    assignmentItemScore2.setManualscoring(Boolean.FALSE);
    assignmentItemScore2.setItemMaxScore(2);
    assignmentItemScore2.setItemProficiencyScore(0.00);
    assignmentItemScore2.setItemScore(0);
    assignmentItemScore2.setItemStatus(ItemStatus.COMPLETED);

    AssignmentItemScoreView assignmentItemScore3 = new AssignmentItemScoreView();
    assignmentItemScore3.setItemRefId("Item3");
    assignmentItemScore3.setItemResponse(ItemResponse.INCORRECT);
    assignmentItemScore3.setManualscoring(Boolean.FALSE);
    assignmentItemScore3.setItemMaxScore(2);
    assignmentItemScore3.setItemProficiencyScore(0.0);
    assignmentItemScore3.setItemScore(0);
    assignmentItemScore3.setItemStatus(ItemStatus.COMPLETED);

    AssignmentItemScoreView assignmentItemScore4 = new AssignmentItemScoreView();
    assignmentItemScore4.setItemRefId("Item4");
    assignmentItemScore4.setItemResponse(ItemResponse.PARTIAL_CREDIT);
    assignmentItemScore4.setManualscoring(Boolean.TRUE);
    assignmentItemScore4.setItemMaxScore(2);
    assignmentItemScore4.setItemProficiencyScore(0.5);
    assignmentItemScore4.setItemScore(1);
    assignmentItemScore4.setItemStatus(ItemStatus.COMPLETED);

    AssignmentItemScoreView assignmentItemScore5 = new AssignmentItemScoreView();
    assignmentItemScore5.setItemRefId("Item5");
    assignmentItemScore5.setItemResponse(ItemResponse.PARTIAL_CREDIT);
    assignmentItemScore5.setManualscoring(Boolean.TRUE);
    assignmentItemScore5.setItemMaxScore(4);
    assignmentItemScore5.setItemProficiencyScore(0.5);
    assignmentItemScore5.setItemScore(2);
    assignmentItemScore5.setItemStatus(ItemStatus.COMPLETED);

    assignmentItemScores.add(assignmentItemScore1);
    assignmentItemScores.add(assignmentItemScore2);
    assignmentItemScores.add(assignmentItemScore3);
    assignmentItemScores.add(assignmentItemScore4);
    assignmentItemScores.add(assignmentItemScore5);

    return assignmentItemScores;
  }


  @Test
  public void getItemsCorrectCountTest() {

    int itemCorrectCount = standardScoreCalculations.getItemsCorrectCount(assignmentItemScores);
    Assert.assertEquals(1 , itemCorrectCount);
  }

  @Test
  public void getItemsCorrectCountProvisionalTest() {

    int itemCorrectCount = standardScoreCalculations.getItemsCorrectCount(assignmentItemScoresProvisional);
    Assert.assertEquals(1 , itemCorrectCount);
  }

  @Test
  public void getItemsCorrectPointsTest() {
    int itemsCorrectPoints = standardScoreCalculations.getItemsCorrectPoints(assignmentItemScores);
    Assert.assertEquals(2 , itemsCorrectPoints);
  }

  @Test
  public void getStandardPointsTest() {
    int standardPoints = standardScoreCalculations.getStandardPoints(assignmentItemScores);
    Assert.assertEquals(12 , standardPoints);
  }

  @Test
  public void getStandardAttainedPointsTest() {
    int standardAttainedPoints = standardScoreCalculations.getStandardAttainedPoints(assignmentItemScores);
    Assert.assertEquals(5 , standardAttainedPoints);
  }

  @Test
  public void getAvgPointsCorrectTest() {
    int itemsCorrectPoints = standardScoreCalculations.getItemsCorrectPoints(assignmentItemScores);
    int standardPoints = standardScoreCalculations.getStandardPoints(assignmentItemScores);

    double avgPointsCorrect = standardScoreCalculations.getAvgPointsCorrect(itemsCorrectPoints , standardPoints);
    Assert.assertEquals(0.17 , avgPointsCorrect , 0.0);
  }

  @Test
  public void getAvgItemsCorrectTest() {
    int itemCorrectCount = standardScoreCalculations.getItemsCorrectCount(assignmentItemScores);
    double avgItemsCorrect = standardScoreCalculations.getAvgItemsCorrect(itemCorrectCount ,
       assignmentItemScores.size());
    Assert.assertEquals(0.2 , avgItemsCorrect , 0.0);
  }

  @Test
  public void getStandardProficiencyScore() {
    int attainedPoints = standardScoreCalculations.getStandardAttainedPoints(assignmentItemScores);
    int standardPoints = standardScoreCalculations.getStandardPoints(assignmentItemScores);
    double proficiencyScore = standardScoreCalculations.getStandardProficiencyScore(attainedPoints ,
       standardPoints);
    Assert.assertEquals(0.42 , proficiencyScore , 0.0);
  }
}
