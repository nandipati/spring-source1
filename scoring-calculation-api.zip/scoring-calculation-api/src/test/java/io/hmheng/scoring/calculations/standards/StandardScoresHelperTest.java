package io.hmheng.scoring.calculations.standards;

import com.hmhco.api.scoring.view.retrive.StandardScoreView;
import com.hmhco.api.scoring.view.save.AssignmentItemScoreView;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

/**
 * Created by nandipatim on 3/12/18.
 */
public class StandardScoresHelperTest extends SpringApplicationTest {

  @Autowired
  private StandardScoresHelper standardScoresHelper;

  private List<AssignmentItemScoreView> assignmentItemScores =null;

  @Before
  public void setup(){
    StandardScoreCalculationsTest standardScoreCalculationsTest = new StandardScoreCalculationsTest();
    assignmentItemScores = standardScoreCalculationsTest.getItemScores();
  }

  @Test
  public void getStandardScoresTest() {
    StandardToItemScores standardToItemScores = new StandardToItemScores();
    HashMap<UUID , List<AssignmentItemScoreView>> itemScoreViewMapScored = new HashMap<>();
    HashMap<UUID , List<AssignmentItemScoreView>> itemScoreViewMapNotScored = new HashMap<>();
    UUID standardId = UUID.randomUUID();
    itemScoreViewMapScored.put(standardId , assignmentItemScores);
    standardToItemScores.setItemScoreViewMapScored(itemScoreViewMapScored);
    standardToItemScores.setItemScoreViewMapNotScored(itemScoreViewMapNotScored);
    List<StandardScoreView> standardScoreViews = standardScoresHelper.getStandardScores(standardToItemScores);

    StandardScoreView standardScoreView = standardScoreViews.get(0);
    Assert.assertEquals(1 , (int)standardScoreView.getCorrectItemsCount());
    Assert.assertEquals(5 , (int)standardScoreView.getTotalItemsCount());
    Assert.assertEquals(5 , (int)standardScoreView.getAttainedPoints());
    Assert.assertEquals(5 , (int)standardScoreView.getItemCount());
    Assert.assertEquals(2 , (int)standardScoreView.getCorrectItemsPoints());
    Assert.assertEquals(0.2 , standardScoreView.getAvgItemsCorrect() , 0.0);
    Assert.assertEquals(12 , (int)standardScoreView.getTotalPoints());
    Assert.assertEquals(0.42 , standardScoreView.getStandardProficiencyScore() , 0.0);
    Assert.assertEquals(0.17 , standardScoreView.getAvgPointsCorrect() , 0.0);
  }
}
