package com.rsieng.scoring.driver.streaming;

/**
 * Created by nandipatim on 5/31/17.
 */
public enum ConfigType {
  CONSUMER,
  PRODUCER;
}
