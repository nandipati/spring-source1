package com.rsieng.scoring.driver.streaming;

/**
 * Created by nandipatim on 5/18/18.
 */
public interface Constants {

  String ASWS_DISABLE_CERT_CHECK = "com.amazonaws.sdk.disableCertChecking";
  String SPARK_EXECUTOR_URI = "spark.executor.uri";
  String SPARK_MERMORY_FRAC = "spark.memory.fraction";
  String SPARK_MEMORY_SF = "spark.memory.storageFraction";
  String SPARK_DRIVER_MEMORY = "spark.driver.memory";
  String SPARK_EXECUTOR_MEMORY = "spark.executor.memory";
  String SPARK_ENV = "spark.app.env";
  String SPARK_APP_CHECKPOINT = "spark.app.checkpoint_dir";
}
