package com.rsieng.scoring.driver.streaming;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.STSAssumeRoleSessionCredentialsProvider;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesis.model.DescribeStreamResult;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClientBuilder;
import java.io.Serializable;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@NoArgsConstructor
@ConfigurationProperties("aws.kinesis")
@EnableConfigurationProperties
public class KinesisStreamConfigurations implements Serializable {

  private List<KinesisStreamConfiguration> streamConfigurations;

  @Data
  @NoArgsConstructor
  public static class KinesisStreamConfiguration extends StreamConfiguration {

    @NonNull
    private String stream;

    @NonNull
    private String region;

    @NonNull
    private String kinesisEndpoint;

    private boolean useSts;

    private String roleArn;

    private String roleSessionName;

    private Integer sparkProcessingParallelism;

    public AmazonKinesis kinesisClient() {
        AmazonKinesisClientBuilder builder = AmazonKinesisClientBuilder.standard().withRegion(region);
        if (useSts) {
          builder = builder.withCredentials(new STSAssumeRoleSessionCredentialsProvider.Builder(roleArn, roleSessionName)
              .withStsClient(AWSSecurityTokenServiceClientBuilder.standard().withCredentials(new
                  DefaultAWSCredentialsProviderChain()).withRegion(region).build()).build());
        }

      return builder.build();
    }

    public DescribeStreamResult describeStream() {
      return kinesisClient().describeStream(getStream());
    }

  }

}
