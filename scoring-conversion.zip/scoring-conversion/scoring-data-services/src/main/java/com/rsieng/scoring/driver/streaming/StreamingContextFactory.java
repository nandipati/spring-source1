package com.rsieng.scoring.driver.streaming;

import com.rsieng.scoring.driver.streaming.model.KinesisMessage;
import java.io.Serializable;
import lombok.extern.slf4j.Slf4j;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * Created by nandipatim on 1/24/17.
 */
@Component
@Slf4j
public class StreamingContextFactory implements Serializable {
  private static final long serialVersionUID = 1L;

  @Value("${spark.app.env}")
  private String sparkAppEnv;

  @Value("${spark.app.master:''}")
  private String sparkMaster;

  @Value("${spark.app.home:''}")
  private String sparkHome;

  @Value("${spark.app.batchMillis}")
  private Long batchMillis;

  @Value("${aws.app.disableCertChecking:true}")
  private String awsDisableCertChecking;

  @Value("${spark.app.memory.fraction:''}")
  private String sparkMemoryFraction;

  @Value("${spark.app.memory.storageFraction:''}")
  private String sparkMemoryStorageFraction;

  @Value("${spark.executor.uri:''}")
  private String sparkExecutorUri;

  @Value("${spark.executor.memory:''}")
  private String sparkExecutorMemory;

  @Value("${spark.driver.memory:''}")
  private String sparkDriverMemory;

  @Value("${spark.app.enableYarnMaster:''}")
  private Boolean enableYarnMaster;

  @Value("${spark.app.label}")
  private String appName;

  @Value("${spark.app.enableCheckpoint:''}")
  private Boolean enableCheckpoint;

  public JavaStreamingContext create() {
    //TODO: All the config has to be moved to yml or config service
    SparkConf conf = new SparkConf();
    System.getProperties().setProperty(Constants.ASWS_DISABLE_CERT_CHECK, awsDisableCertChecking);
    conf.set(Constants.SPARK_EXECUTOR_URI, sparkExecutorUri);
    //Change it the local Where spark is installed to
    //Below means you are working Yarn standalone rather than mesos cluster for development.
    //Change it the local Where spark is installed to
    if(enableYarnMaster) {
      conf.setMaster(sparkMaster);
      conf.setSparkHome(sparkHome);
      conf.set(Constants.SPARK_MERMORY_FRAC, sparkMemoryFraction);
      conf.set(Constants.SPARK_MEMORY_SF, sparkMemoryStorageFraction);
      conf.set(Constants.SPARK_DRIVER_MEMORY, sparkDriverMemory);
      conf.set(Constants.SPARK_EXECUTOR_MEMORY, sparkExecutorMemory);
      conf.set(Constants.SPARK_ENV, sparkAppEnv);
    }
    /* else {
      if(enableCheckpoint) {
        setIfNotDefined(conf, Constants.SPARK_APP_CHECKPOINT, String.format(
            "/%s/checkpoint/", sparkAppEnv));
      }
    }*/

    conf.setAppName(appName);

    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer");
    conf.registerKryoClasses(new Class[]{KinesisMessage.class});

    JavaStreamingContext streamingContext = new JavaStreamingContext(new JavaSparkContext(conf), new Duration(batchMillis));
    if(!enableYarnMaster && enableCheckpoint) {
      streamingContext.checkpoint(streamingContext.sparkContext().getConf().get(Constants.SPARK_APP_CHECKPOINT));
    }
    return streamingContext;
  }

  /**
   * Set a configuration value according to an order of precedence 1. System Property 2. Value passed into the conf 3.
   * Default value
   *
   * @return Spark Conf
   */
  private String setIfNotDefined(SparkConf conf, String key, String value) {
    String setValue = value;
    // Use a value in the conf if set
    if (conf.contains(key)) {
      setValue = conf.get(key);
    } else {
      conf.set(key, setValue);
    }
    return setValue;
  }
}
