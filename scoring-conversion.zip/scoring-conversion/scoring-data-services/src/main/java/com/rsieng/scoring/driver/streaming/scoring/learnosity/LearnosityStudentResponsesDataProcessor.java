package com.rsieng.scoring.driver.streaming.scoring.learnosity;

import com.rsieng.scoring.driver.streaming.scoring.learnosity.domain.StudentSession;
import java.util.function.Consumer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Created by nandipatim on 3/8/17.
 */
@Slf4j
@Component
public class LearnosityStudentResponsesDataProcessor implements Consumer<StudentSession> {

  private String localUrl = "http://localhost:";

  @Autowired
  private Environment environment;


  @Override
  public void accept(StudentSession studentSession) {
    String[] profiles = environment.getActiveProfiles();
    if(studentSession != null) {
      log.info("Processing Student Session Scores from Learnosity start: {}", studentSession);
    }
  }
}
