package com.rsieng.scoring.driver.streaming.scoring.learnosity.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.core.Relation;

@Data
@NoArgsConstructor
@JsonRootName("item")
@Relation(value = "item", collectionRelation = "items")
public class Item {

  private String reference;

  private Source source;

  private Integer time;

  @JsonProperty("response_ids")
  private List<String> responseIds;

  @JsonProperty("user_flagged")
  private boolean userFlagged;

  private Scoring scoring;

  @Override
  public String toString() {
    return "Item{" +
        "reference='" + reference + '\'' +
        ", source='" + source + '\'' +
        ", time=" + time +
        ", responseIds=" + responseIds +
        ", userFlagged=" + userFlagged +
        ", scoring=" + scoring +
        '}';
  }
}
