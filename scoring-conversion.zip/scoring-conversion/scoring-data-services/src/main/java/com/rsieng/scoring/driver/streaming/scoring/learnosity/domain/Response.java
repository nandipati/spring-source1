package com.rsieng.scoring.driver.streaming.scoring.learnosity.domain;

import com.fasterxml.jackson.annotation.JsonRootName;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonRootName("response")
public class Response {

  private List<ResponseValue> value;

  @Override
  public String toString() {
    return "Response{" +
        "value='" + value + '\'' +
        '}';
  }
}
