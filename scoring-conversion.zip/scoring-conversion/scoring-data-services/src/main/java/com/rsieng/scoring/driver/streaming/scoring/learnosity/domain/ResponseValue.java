package com.rsieng.scoring.driver.streaming.scoring.learnosity.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.core.Relation;

@Data
@NoArgsConstructor
@JsonRootName("value")
@Relation(value = "value", collectionRelation = "values")
public class ResponseValue {

  private List<String> value;

  private String type;

  @JsonProperty("api_version")
  private String apiVersion;

  @JsonProperty("wordCount")
  private Integer wordCount;

  @Override
  public String toString() {
    return "ResponseValue{" +
        "value='" + value + '\'' +
        "wordCount='" + wordCount + '\'' +
        ", apiVersion='" + apiVersion + '\'' +
        '}';
  }

}
