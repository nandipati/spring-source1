package com.rsieng.scoring.driver.streaming.scoring.learnosity.domain;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonRootName("source")
public class Source {

  private String reference;

  @JsonProperty("organisation_id")
  private Integer organisationId;

  @JsonProperty("item_pool_id")
  private String itemPoolId;

  @Override
  public String toString() {
    return "Source{" +
        "reference='" + reference + '\'' +
        ", organisationId='" + organisationId + '\'' +
        ", itemPoolId=" + itemPoolId +
        '}';
  }
}
