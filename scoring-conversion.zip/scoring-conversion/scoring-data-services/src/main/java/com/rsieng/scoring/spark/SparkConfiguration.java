package com.rsieng.scoring.spark;

import com.rsieng.scoring.driver.streaming.InputStreamFactory;
import com.rsieng.scoring.driver.streaming.StreamingContextFactory;
import com.rsieng.scoring.driver.streaming.model.KinesisMessage;
import java.io.Serializable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * Created by nandipatim on 1/24/17.
 */
@Configuration
@ComponentScan
@Slf4j
public class SparkConfiguration implements Serializable{

  @Autowired
  StreamingContextFactory streamingContextFactory;

  @Autowired
  InputStreamFactory<KinesisMessage> inputStreamFactory;

  @Autowired
  Environment environment;

  @Bean
  ScoringServicesSparkRunner sparkRunner() {


      ScoringServicesSparkRunner sparkRunner = new ScoringServicesSparkRunner(streamingContextFactory , inputStreamFactory
          ,environment);
    try {
      sparkRunner .execute();
    } catch (InterruptedException e) {
      log.error("Error while starting Spark Runner {} ",e);
      e.printStackTrace();
    }
    return sparkRunner;
  }
}
