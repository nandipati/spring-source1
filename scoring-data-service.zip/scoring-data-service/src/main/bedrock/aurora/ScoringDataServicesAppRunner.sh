#!/bin/bash

DOCKER_CONTAINER=$1
DOCKER_TAG=$2
STAGE=$3
SPARK_APP_ROLE=$4
SPARK_UI_PORT=$5
MESOS_SCALING_GROUP=$6
SPARK_EXECUTOR_CORE=$7
SPARK_EXTRA_CORE=$8
SPARK_EXECUTOR_OVERHEAD=$9
SPARK_TOTAL_EXECUTOR_CORES=$10
JMXREMOTE_PORT=$7
JMXREMOTE_RMI_PORT=$8
PROMETHEUS_JMX_EXPORTER_PORT=$9

/bin/spark-submit \
    --conf spark.mesos.role=$SPARK_APP_ROLE \
     --conf spark.mesos.mesosExecutor.cores=0.5 \
    --conf spark.executor.uri=/mnt/efs/baseService/roles/hmheng-score/spark/spark-2.2.0-bin-hadoop2.7.tgz \
    --conf spark.mesos.executor.memoryOverhead=600 \
    --conf spark.mesos.extra.cores=1 \
    --conf spark.mesos.constraints=autoscale-type:$MESOS_SCALING_GROUP \
    --conf spark.mesos.executor.docker.image=$DOCKER_CONTAINER:$DOCKER_TAG \
    --conf spark.driver.extraJavaOptions="-Dspring.profiles.active=$STAGE -Dcom.sun.management.jmxremote=$JMXREMOTE_PORT -Dcom.sun.management.jmxremote.rmi.port=$JMXREMOTE_RMI_PORT -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false -javaagent:/home/hmheng-score/jmx_prometheus_javaagent-0.8.jar=$PROMETHEUS_JMX_EXPORTER_PORT:/home/hmheng-score/hmheng_scoring_data_services.yaml"  \
    --conf spark.executor.extraJavaOptions="-Dspring.profiles.active=$STAGE -Dlog4j.configuration=file:/log4j.xml" \
    --conf spark.mesos.executor.docker.volumes=/mnt/efs/baseService/roles/$SPARK_APP_ROLE/spark:/mnt/efs/baseService/roles/$SPARK_APP_ROLE/spark:rw \
    --conf spark.app.env=$STAGE \
    --conf spark.ui.port=$SPARK_UI_PORT \
    --total-executor-cores 1 \
    --master mesos://zk://zkro01.brcore01.internal:2181,zkro02.brcore01.internal:2181,zkro02.brcore01.internal:2181/baseService/hmheng-infra/us-east-1/brnpb/mesos/master \
    --class io.hmheng.scoring.ScoringDataServicesApp \
    /app.jar