package io.hmheng.scoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import org.springframework.context.annotation.ComponentScan;


/**
 * Created by nandipatim on 5/17/17.
 */
@SpringBootApplication
@ComponentScan("io.hmheng.scoring,io.hmheng.services,io.hmheng.authorization")
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
@EnableConfigurationProperties
public class ScoringDataServicesApp {
  public static void main(String[] args) {
    SpringApplication.run(ScoringDataServicesApp.class, args);
  }

}
