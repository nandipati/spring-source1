package io.hmheng.scoring.streams;


import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import java.util.Map;

public interface InputStreamFactory<T> {
  Map<String , JavaDStream<T>> create(JavaStreamingContext streamingContext);
}
