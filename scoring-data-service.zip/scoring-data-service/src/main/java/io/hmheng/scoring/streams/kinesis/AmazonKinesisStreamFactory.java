package io.hmheng.scoring.streams.kinesis;

import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream;
import io.hmheng.scoring.streams.InputStreamFactory;
import io.hmheng.scoring.streams.config.ConfigType;
import io.hmheng.scoring.streams.config.ConsumeAssesmentScoresStreamConfiguration;
import io.hmheng.scoring.streams.config.StreamConfiguration;
import io.hmheng.scoring.streams.kinesis.model.KinesisMessage;
import io.hmheng.scoring.streams.kinesis.model.KinesisRecordMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.spark.storage.StorageLevel;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kinesis.KinesisUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Created by nandipatim on 1/24/17.
 */
@Slf4j
@Component
public class AmazonKinesisStreamFactory implements InputStreamFactory<KinesisMessage>, Serializable {

  private static final long serialVersionUID = 1L;

  @Autowired
  private ConsumeAssesmentScoresStreamConfiguration consumeAssesmentScoresStreamConfiguration;

  public Map<String , JavaDStream<KinesisMessage>> create(JavaStreamingContext streamingContext) {

    Map<String , JavaDStream<KinesisMessage>> dstreamMap = new HashMap<>();

    if (consumeAssesmentScoresStreamConfiguration == null) {
      throw new RuntimeException("Stream Configurations cannot be Null for Consume Stream from Lernosity");
    }

    try {
      List<JavaDStream<KinesisMessage>> dstreamLists = new ArrayList<>();
      log.debug("Creating spark streams for stream {}", consumeAssesmentScoresStreamConfiguration.getStream());
      int numShards = consumeAssesmentScoresStreamConfiguration.describeStream()
              .getStreamDescription().getShards().size();
      log.debug("Found {} shards for {}", numShards, consumeAssesmentScoresStreamConfiguration.getStream());
      dstreamLists.addAll(createStreams(
              streamingContext, consumeAssesmentScoresStreamConfiguration, new Duration(2000), numShards));
      JavaDStream<KinesisMessage> ustreams = unionStreams(dstreamLists, streamingContext);
      ustreams.repartition(consumeAssesmentScoresStreamConfiguration.getSparkProcessingParallelism());
      dstreamMap.put(consumeAssesmentScoresStreamConfiguration.getRoleSessionName() , ustreams);
    } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
      throw new RuntimeException(e);
    }

    return dstreamMap;
  }

  protected List<JavaDStream<KinesisMessage>> createStreams(JavaStreamingContext jssc,
                                                            StreamConfiguration streamConfig,
                                                            Duration kinesisCheckpointInterval, int numStreams)
      throws ClassNotFoundException, IllegalAccessException, InstantiationException {
    List<JavaDStream<KinesisMessage>> dstreamsList = new ArrayList<>(numStreams);
    for (int i = 0; i < numStreams; i++) {
      dstreamsList.add(createStream(jssc, streamConfig, kinesisCheckpointInterval));
    }
    return dstreamsList;
  }

  protected JavaDStream<KinesisMessage> createStream(JavaStreamingContext jssc,
      StreamConfiguration streamConfig, Duration kinesisCheckpointInterval) throws ClassNotFoundException {

    Class<? extends Function<byte[], Object>> mapperBeanClass = null;
    Class<? extends Consumer<Object>> processorBeanClass = null;
    if (ConfigType.CONSUMER == streamConfig.getConfigType()) {
      mapperBeanClass = (Class<Function<byte[], Object>>) Class.forName(
          ((ConsumeAssesmentScoresStreamConfiguration) streamConfig).getMapperBeanClass());
      processorBeanClass = (Class<Consumer<Object>>) Class.forName(
          ((ConsumeAssesmentScoresStreamConfiguration) streamConfig).getProcessorBeanClass());
    }

    KinesisRecordMapper kinesisRecordMapper = KinesisRecordMapper.builder().stream(streamConfig.getStream())
            .appName(streamConfig.getAppName())
            .mapperBeanClass(mapperBeanClass)
            .processorBeanClass(processorBeanClass).build();

    JavaDStream<KinesisMessage> stream;
    if (streamConfig.isUseSts()) {
      stream = KinesisUtils
          .createStream(jssc, streamConfig.getAppName(), streamConfig.getStream(),  streamConfig.getKinesisEndpoint(),
              streamConfig.getRegion(), InitialPositionInStream.TRIM_HORIZON, kinesisCheckpointInterval,
              StorageLevel.MEMORY_AND_DISK_2(), kinesisRecordMapper, KinesisMessage.class, null, null,
              streamConfig.getRoleArn(), streamConfig.getRoleSessionName(), null);
    } else {
      stream = KinesisUtils
          .createStream(jssc, streamConfig.getAppName(), streamConfig.getStream(), streamConfig.getKinesisEndpoint(),
              streamConfig.getRegion(), InitialPositionInStream.TRIM_HORIZON, kinesisCheckpointInterval,
              StorageLevel.MEMORY_AND_DISK_2(), kinesisRecordMapper, KinesisMessage.class);
    }

    return stream;
  }

  protected <T> JavaDStream<T> unionStreams(List<JavaDStream<T>> dstreamLists, JavaStreamingContext streamingContext) {

    log.info("dStreamLists size " + dstreamLists.size());

    return (dstreamLists.size() > 1)
            ? streamingContext.union(dstreamLists.get(0), dstreamLists.subList(1, dstreamLists.size())) :
            dstreamLists.get(0);
  }

}
