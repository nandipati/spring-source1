package io.hmheng.scoring.streams.scoring;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import com.hmhco.api.scoring.view.retrive.RetrieveFormativeActivitySessionView;


import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;


import java.io.IOException;
import java.util.function.Function;


/**
 * Created by nandipatim on 3/8/17.
 */
@Slf4j
@Component
public class ScoringSessionDataMapper implements Function<byte[], RetrieveFormativeActivitySessionView> {

  private ObjectReader objectReader;

  public ScoringSessionDataMapper() {
    objectReader = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        .readerFor(RetrieveFormativeActivitySessionView.class);
  }

  @Override
  public RetrieveFormativeActivitySessionView apply(byte[] bytes) {
    try {
      log.info("Deserializing message into String from Lernosity Session Data services");
      RetrieveFormativeActivitySessionView studentSession = (
              RetrieveFormativeActivitySessionView) objectReader.readValue(bytes);
      log.info("LernosityStudentSessionDataMapper in Lernosity DataMapper {} ",studentSession);
      return studentSession;
    } catch (IOException e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    }
  }
}
