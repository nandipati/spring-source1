package io.hmheng.scoring.streams.scoring;


import com.hmhco.api.scoring.view.enums.TestType;
import com.hmhco.api.scoring.view.request.SaveAssignmentSessionStandardScoresView;
import com.hmhco.api.scoring.view.retrive.RetrieveFormativeActivitySessionView;

import com.hmhco.api.scoring.view.retrive.RetrieveFormativeSessionView;
import com.hmhco.api.scoring.view.retrive.StandardScoreView;
import com.hmhco.api.scoring.view.save.AssignmentItemScoreView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;
import io.hmheng.scoring.calculations.standards.StandardScoresHelper;
import io.hmheng.scoring.calculations.standards.StandardToItemScores;
import io.hmheng.scoring.streams.scoring.helper.ScoringSessionDataProcessorHelper;
import io.hmheng.services.api.ContentSourceService;
import io.hmheng.services.api.ScoringService;
import io.hmheng.services.api.domain.AssesmentResourceInfo;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;


/**
 * Created by nandipatim on 3/8/17.
 */
@Slf4j
@Component
public class ScoringSessionDataProcessor implements Consumer<RetrieveFormativeActivitySessionView> {

  @Autowired
  private ScoringService scoringService;

  @Autowired
  private ContentSourceService contentSourceService;

  @Autowired
  private StandardScoresHelper standardScoresHelper;

  @Autowired
  private ScoringSessionDataProcessorHelper scoringSessionDataProcessorHelper;

  @Override
  public void accept(RetrieveFormativeActivitySessionView studentSession) {

    log.info("the student session received by spark" + studentSession);

    if (studentSession != null) {

      String testTypeString = studentSession.getEventType();

      try {

        TestType testType = TestType.valueOf(testTypeString);

        if (testType.getProductType().isCalculateStandardScores()) {
          UUID activityId = studentSession.getActivityId();
          String resourceId = studentSession.getResourceId();
          List<AssignmentItemToStandardMapView> itemToStandardMapViews =
              scoringService.getItemStandardMap(activityId);
          Boolean isItemStandardMapAlreadyPresent = Boolean.TRUE;
          if (CollectionUtils.isEmpty(itemToStandardMapViews)) {
            isItemStandardMapAlreadyPresent = Boolean.FALSE;
            AssesmentResourceInfo assesmentResourceInfo = contentSourceService
                    .resourceItemToStandardMapping(resourceId);
            itemToStandardMapViews = assesmentResourceInfo.getItemToStandardMapping();
          }
          if (!CollectionUtils.isEmpty(itemToStandardMapViews)) {

            Map<String , AssignmentItemToStandardMapView> assignmentItemViewMap = new HashMap<>();
            itemToStandardMapViews.forEach(assignmentItemToStandardMapView -> {
              assignmentItemViewMap.put(assignmentItemToStandardMapView.getItemRefId() ,
                  assignmentItemToStandardMapView);
            });
            RetrieveFormativeSessionView retrieveFormativeSessionView = studentSession
                .getRetrieveFormativeSessionView();
            List<AssignmentItemScoreView> itemscores = retrieveFormativeSessionView.getAssignmentItemScores();
            StandardToItemScores standardToItemScores = scoringSessionDataProcessorHelper
                .getItemScoresMap(assignmentItemViewMap, itemscores);
            Map<UUID, List<AssignmentItemScoreView>> itemScoreViewMapScored = standardToItemScores
                .getItemScoreViewMapScored();
            if (!CollectionUtils.isEmpty(itemScoreViewMapScored)) {
              SaveAssignmentSessionStandardScoresView assignmentSessionStandardScoresView =
                  new SaveAssignmentSessionStandardScoresView();
              List<StandardScoreView> standardScoreViews = standardScoresHelper
                  .getStandardScores(standardToItemScores);
              assignmentSessionStandardScoresView.setStandardScores(standardScoreViews);
              if (!isItemStandardMapAlreadyPresent) {
                assignmentSessionStandardScoresView.setItemToStandardMapping(itemToStandardMapViews);
              }
              assignmentSessionStandardScoresView.setResourceId(resourceId);
              assignmentSessionStandardScoresView.setTestType(testType);
              log.info("assignmentSessionStandardScoresView -> {}", assignmentSessionStandardScoresView);
              scoringService.saveStudentSessionStandardScores(activityId ,
                  retrieveFormativeSessionView.getSessionId(), assignmentSessionStandardScoresView);
            }
          }
        }
      } catch (IllegalArgumentException iae) {
        log.error("Event Type is not supported in Scoring yet - {}",testTypeString);
      }
    }
  }

}
