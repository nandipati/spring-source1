package io.hmheng.scoring.streams.scoring.helper;

import com.hmhco.api.scoring.view.save.AssignmentItemScoreView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;
import io.hmheng.scoring.calculations.standards.StandardToItemScores;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by nandipatim on 3/5/18.
 */
@Slf4j
@Component
public class ScoringSessionDataProcessorHelper {

  public StandardToItemScores getItemScoresMap(Map<String,
      AssignmentItemToStandardMapView> assignmentItemViewMap, List<AssignmentItemScoreView> itemscores) {

    // Map for Standards to Item Scores.
    StandardToItemScores standardToItemScores = new StandardToItemScores();
    Map<UUID, List<AssignmentItemScoreView>> itemScoreViewMap = new HashMap<>();
    Map<UUID, List<AssignmentItemScoreView>> itemScoreViewMapNotScored = new HashMap<>();
    standardToItemScores.setItemScoreViewMapScored(itemScoreViewMap);
    standardToItemScores.setItemScoreViewMapNotScored(itemScoreViewMapNotScored);

    itemscores.forEach(itemScore -> {
      // Only considering items which are scored.
      if (itemScore != null) {
        //Add Logic for multi part question.
        String itemRefid = itemScore.getItemRefId();
        List<String> itemRefs = null;
        if (itemRefid != null && itemRefid.contains("_") && !assignmentItemViewMap.containsKey(itemRefid)) {
          String[] items = itemRefid.split("_");
          itemRefs = Arrays.asList(items);
        } else {
          itemRefs = new ArrayList<String>();
          itemRefs.add(itemRefid);
        }
        itemRefs.forEach(itemRef -> {
          AssignmentItemToStandardMapView itemToStandardMap = assignmentItemViewMap.get(itemRef);
          if (itemToStandardMap != null) {
            List<UUID> standards = itemToStandardMap.getStandards();
            if (!CollectionUtils.isEmpty(standards)) {
              standards.forEach(standard -> {
                if (itemScore.isScored()) {
                  if (itemScoreViewMap.get(standard) == null) {
                    itemScoreViewMap.put(standard, new ArrayList<AssignmentItemScoreView>());
                  }
                  itemScoreViewMap.get(standard).add(itemScore);
                } else {
                  if (itemScoreViewMapNotScored.get(standard) == null) {
                    itemScoreViewMapNotScored.put(standard, new ArrayList<AssignmentItemScoreView>());
                  }
                  itemScoreViewMapNotScored.get(standard).add(itemScore);
                }
              });
            }
          }
        });
      }
    });

    return standardToItemScores;
  }
}
