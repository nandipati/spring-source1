package io.hmheng.springframework.extn.context;

import lombok.extern.slf4j.Slf4j;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;


@Slf4j
@SpringBootApplication(scanBasePackageClasses = {
        WorkerSpringApplicationContext.class},exclude = {DataSourceAutoConfiguration.class,
        DataSourceTransactionManagerAutoConfiguration.class,
        HibernateJpaAutoConfiguration.class , JmxAutoConfiguration.class})
@EnableConfigurationProperties
@ComponentScan(" io.hmheng.scoring.streams.scoring"  + ", resources"
        + ", io.hmheng.scoring.streams.kinesis, io.hmheng.scoring.streams.config ,io.hmheng.services"
        + ",io.hmheng.scoring.calculations , io.hmheng.authorization"  )
public class WorkerSpringApplicationContext {

  private static final Object monitor = new Object();

  private static ConfigurableApplicationContext applicationContext;

  protected static void start(String... profiles) {
    synchronized (monitor) {
      if (applicationContext == null) {
        log.info("Starting Spring context on worker.");
        SpringApplication app = new SpringApplication(WorkerSpringApplicationContext.class);
        app.setAdditionalProfiles(profiles);
        app.setWebEnvironment(false);
        applicationContext = app.run();
        applicationContext.registerShutdownHook();
      }
    }
  }

  public static ApplicationContext getContext(String... profiles) {
    if (applicationContext == null) {
      start(profiles);
    }
    return applicationContext;
  }

}
