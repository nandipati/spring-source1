package io.hmheng.scoring.streams.scoring;

import com.hmhco.api.scoring.utils.ItemResponse;
import com.hmhco.api.scoring.utils.ItemStatus;
import com.hmhco.api.scoring.view.retrive.StandardScoreView;
import com.hmhco.api.scoring.view.save.AssignmentItemScoreView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;

import io.hmheng.scoring.calculations.standards.StandardScoresHelper;
import io.hmheng.scoring.calculations.standards.StandardToItemScores;
import io.hmheng.scoring.streams.scoring.helper.ScoringSessionDataProcessorHelper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.UUID;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by nandipatim on 3/12/18.
 */
public class ScoringSessionDataProcessorHelperTest extends SpringApplicationTest {

  private List<AssignmentItemScoreView> assignmentItemScoresProvisional =null;
  private UUID standard1 = UUID.randomUUID();
  private UUID standard2 = UUID.randomUUID();
  private UUID standard3 = UUID.randomUUID();

  @Autowired
  private ScoringSessionDataProcessorHelper scoringSessionDataProcessorHelper;

  @Autowired
  private StandardScoresHelper standardScoresHelper;

  @Before
  public void setup() {

    assignmentItemScoresProvisional = getItemScoresProvisional();
  }

  public List<AssignmentItemScoreView> getItemScoresProvisional(){
    assignmentItemScoresProvisional = new ArrayList<>();
    AssignmentItemScoreView assignmentItemScore1 = new AssignmentItemScoreView();
    assignmentItemScore1.setItemRefId("Item1");
    assignmentItemScore1.setItemMaxScore(2);
    assignmentItemScore1.setItemResponse(ItemResponse.CORRECT);
    assignmentItemScore1.setItemScore(2);
    assignmentItemScore1.setItemStatus(ItemStatus.COMPLETED);
    assignmentItemScore1.setItemProficiencyScore(1.00);
    assignmentItemScore1.setManualscoring(Boolean.FALSE);

    AssignmentItemScoreView assignmentItemScore2 = new AssignmentItemScoreView();
    assignmentItemScore2.setItemRefId("Item2");
    assignmentItemScore2.setItemResponse(ItemResponse.NOT_SCORED);
    assignmentItemScore2.setManualscoring(Boolean.TRUE);
    assignmentItemScore2.setItemMaxScore(null);
    assignmentItemScore2.setItemProficiencyScore(null);
    assignmentItemScore2.setItemScore(null);
    assignmentItemScore2.setItemStatus(ItemStatus.NOT_STARTED);

    AssignmentItemScoreView assignmentItemScore3 = new AssignmentItemScoreView();
    assignmentItemScore3.setItemRefId("Item3");
    assignmentItemScore3.setItemResponse(ItemResponse.INCORRECT);
    assignmentItemScore3.setManualscoring(Boolean.FALSE);
    assignmentItemScore3.setItemMaxScore(2);
    assignmentItemScore3.setItemProficiencyScore(0.0);
    assignmentItemScore3.setItemScore(0);
    assignmentItemScore3.setItemStatus(ItemStatus.COMPLETED);

    AssignmentItemScoreView assignmentItemScore4 = new AssignmentItemScoreView();
    assignmentItemScore4.setItemRefId("Item4");
    assignmentItemScore4.setItemResponse(ItemResponse.PARTIAL_CREDIT);
    assignmentItemScore4.setManualscoring(Boolean.TRUE);
    assignmentItemScore4.setItemMaxScore(2);
    assignmentItemScore4.setItemProficiencyScore(0.5);
    assignmentItemScore4.setItemScore(1);
    assignmentItemScore4.setItemStatus(ItemStatus.COMPLETED);

    AssignmentItemScoreView assignmentItemScore5 = new AssignmentItemScoreView();
    assignmentItemScore5.setItemRefId("Item5");
    assignmentItemScore5.setItemResponse(ItemResponse.NOT_ANSWERED);
    assignmentItemScore5.setManualscoring(Boolean.TRUE);
    assignmentItemScore5.setItemMaxScore(2);
    assignmentItemScore5.setItemProficiencyScore(0.00);
    assignmentItemScore5.setItemScore(0);
    assignmentItemScore5.setItemStatus(ItemStatus.COMPLETED);

    assignmentItemScoresProvisional.add(assignmentItemScore1);
    assignmentItemScoresProvisional.add(assignmentItemScore2);
    assignmentItemScoresProvisional.add(assignmentItemScore3);
    assignmentItemScoresProvisional.add(assignmentItemScore4);
    assignmentItemScoresProvisional.add(assignmentItemScore5);

    return assignmentItemScoresProvisional;
  }


  public Map<String,AssignmentItemToStandardMapView > prepareItemScoresMap() {
    Map<String,AssignmentItemToStandardMapView > assignmentItemViewMap = new HashMap();
    AssignmentItemToStandardMapView assignmentItemToStandardMap1 = new AssignmentItemToStandardMapView();
    assignmentItemToStandardMap1.setItemRefId("Item1");
    assignmentItemToStandardMap1.setStandards(new ArrayList<>());
    assignmentItemToStandardMap1.getStandards().add(standard1);
    assignmentItemToStandardMap1.getStandards().add(standard2);
    assignmentItemViewMap.put("Item1" , assignmentItemToStandardMap1);
    AssignmentItemToStandardMapView assignmentItemToStandardMap2 = new AssignmentItemToStandardMapView();
    assignmentItemToStandardMap2.setItemRefId("Item2");
    assignmentItemToStandardMap2.setStandards(new ArrayList<>());
    assignmentItemToStandardMap2.getStandards().add(standard1);
    assignmentItemToStandardMap2.getStandards().add(standard2);
    assignmentItemToStandardMap2.getStandards().add(standard3);
    assignmentItemViewMap.put("Item2" , assignmentItemToStandardMap2);
    AssignmentItemToStandardMapView assignmentItemToStandardMap3 = new AssignmentItemToStandardMapView();
    assignmentItemToStandardMap3.setItemRefId("Item3");
    assignmentItemToStandardMap3.setStandards(new ArrayList<>());
    assignmentItemToStandardMap3.getStandards().add(standard3);
    assignmentItemToStandardMap3.getStandards().add(standard1);
    assignmentItemViewMap.put("Item3" , assignmentItemToStandardMap3);
    AssignmentItemToStandardMapView assignmentItemToStandardMap4 = new AssignmentItemToStandardMapView();
    assignmentItemToStandardMap4.setItemRefId("Item4");
    assignmentItemToStandardMap4.setStandards(new ArrayList<>());
    assignmentItemToStandardMap4.getStandards().add(standard1);
    assignmentItemToStandardMap4.getStandards().add(standard2);
    assignmentItemViewMap.put("Item4" , assignmentItemToStandardMap4);
    AssignmentItemToStandardMapView assignmentItemToStandardMap5 = new AssignmentItemToStandardMapView();
    assignmentItemToStandardMap5.setItemRefId("Item5");
    assignmentItemToStandardMap5.setStandards(new ArrayList<>());
    assignmentItemToStandardMap5.getStandards().add(standard1);
    assignmentItemToStandardMap5.getStandards().add(standard3);
    assignmentItemViewMap.put("Item5" , assignmentItemToStandardMap5);
    return assignmentItemViewMap;
  }

  @Test
  public void getItemScoresMapTest() {

    StandardToItemScores standardToItemScores = scoringSessionDataProcessorHelper.getItemScoresMap(
        prepareItemScoresMap() , assignmentItemScoresProvisional);
    List<StandardScoreView> standardScoreViews = standardScoresHelper.getStandardScores(standardToItemScores);

    standardScoreViews.forEach(standardScoreView -> {
      if (standard1.equals(standardScoreView.getStandardId())) {
        Assert.assertEquals(1 , (int)standardScoreView.getCorrectItemsCount());
        Assert.assertEquals(5 , (int)standardScoreView.getTotalItemsCount());
        Assert.assertEquals(3 , (int)standardScoreView.getAttainedPoints());
        Assert.assertEquals(4 , (int)standardScoreView.getItemCount());
        Assert.assertEquals(2 , (int)standardScoreView.getCorrectItemsPoints());
        Assert.assertEquals(0.25 , standardScoreView.getAvgItemsCorrect() , 0.0);
        Assert.assertEquals(8 , (int)standardScoreView.getTotalPoints());
        Assert.assertEquals(0.38 , standardScoreView.getStandardProficiencyScore() , 0.0);
        Assert.assertEquals(0.25 , standardScoreView.getAvgPointsCorrect() , 0.0);
      }
    });

  }
}
