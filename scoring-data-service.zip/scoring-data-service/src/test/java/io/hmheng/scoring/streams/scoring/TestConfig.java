package io.hmheng.scoring.streams.scoring;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Created by nandipatim on 3/13/18.
 */
@Configuration
@EnableAutoConfiguration(exclude={ FlywayAutoConfiguration.class, FlywayAutoConfiguration.FlywayConfiguration.class,
    DataSourceAutoConfiguration.class,
    DataSourceTransactionManagerAutoConfiguration.class,
    HibernateJpaAutoConfiguration.class , JmxAutoConfiguration.class})
@ComponentScan(basePackages = {"io.hmheng.scoring.calculations",
    "io.hmheng.scoring.streams.scoring.ScoringSessionDataProcessorHelper"})
public class TestConfig {
}
