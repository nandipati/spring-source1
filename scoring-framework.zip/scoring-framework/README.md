# scoring-framework
hmhone scoring executor and scheduler framework

# Run MESOS

## Start Master:
    cd /usr/local/sbin
    sudo ./mesos-master --ip=127.0.0.1 --work_dir=/var/lib/mesos
## Start Slave:
    cd /usr/local/sbin
    sudo ./mesos-slave --master=127.0.0.1:5050

## Run the Framework
    sbt run

### Create the executable jar
    sbt assembly

### Run the jar
    java -Djava.library.path="/usr/local/lib" -jar target/scala-2.11/scoring-framework-0.1.0


## Test locally with scoring-engine and scoring api
    start the master and slave
    run mvn clean install on the scoring-engine
    in ScoringFramework.scala change the command that is executed with the proper location for the scoring-engine jar
    on spring-scoring project run:
        vagrant up
        mvn spring-boot:run
    Run the Framework