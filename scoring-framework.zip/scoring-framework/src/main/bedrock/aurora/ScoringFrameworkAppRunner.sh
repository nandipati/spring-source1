#!/bin/bash

DOCKER_CONTAINER=$1
DOCKER_TAG=$2
STAGE=$3
SPARK_APP_ROLE=$4
SPARK_UI_PORT=$5
MESOS_SCALING_GROUP=$6



/bin/spark-submit \
    --conf spark.mesos.role=$SPARK_APP_ROLE \
    --conf spark.mesos.mesosExecutor.cores=0.5 \
    --conf spark.executor.uri=/mnt/efs/service/roles/hmheng-score/spark/spark-2.2.0-bin-hadoop2.7.tgz \
    --conf spark.mesos.executor.memoryOverhead=600 \
    --conf spark.mesos.extra.cores=1 \
    --conf spark.mesos.constraints=autoscale-type:$MESOS_SCALING_GROUP \
    --conf spark.mesos.executor.docker.image=$DOCKER_CONTAINER:$DOCKER_TAG \
    --conf spark.mesos.executor.docker.volumes=/mnt/efs/service/roles/$SPARK_APP_ROLE/spark:/mnt/efs/service/roles/$SPARK_APP_ROLE/spark:rw \
    --conf spark.app.env=$STAGE \
    --conf spark.ui.port=$SPARK_UI_PORT \
    --conf spark.streaming.receiver.maxRate=500 \
    --conf spark.streaming.backpressure.initialRate=250 \
    --total-executor-cores 1 \
    --master mesos://zk://zkro01.brcore01.internal:2181,zkro02.brcore01.internal:2181,zkro02.brcore01.internal:2181/service/hmheng-infra/us-east-1/brnpb/mesos/master \
    --class io.hmheng.scoring.framework.ScoringFramework \
    /app.jar -scoring_profile=$STAGE