package io.hmheng.scoring

import com.typesafe.scalalogging.Logger
import org.slf4j.LoggerFactory

trait Logging {
  protected lazy val log = Logger(LoggerFactory.getLogger(getClass.getName))
}
