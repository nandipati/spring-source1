package io.hmheng.scoring.framework

import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration
import com.twitter.app.{App, Flag}
import io.hmheng.scoring.{Logging}
import io.hmheng.scoring.framework.config.ServicesConfiguration
import io.hmheng.scoring.framework.config.ServicesConfiguration.config
import io.hmheng.scoring.framework.event.LernosityKinesisScoresFactory
import io.hmheng.scoring.framework.jobs.{SparkJobHandler}
import io.hmheng.scoring.utils.{KinesisConfigurationUtil, SparkConfUtil}
import org.apache.spark.{SparkConf}
import org.apache.spark.streaming.{Milliseconds, StreamingContext}



object ScoringFramework extends App with SparkConfUtil with KinesisConfigurationUtil {

  val config = new {
    val scoringProfile: Flag[String] = flag("scoring_profile", "local", "scoring environment")
    val noOfAcceptableTasksConstraint:Flag[String] = flag("acceptable_tasks","5","Constraints to run number of tasks per framework")
    val forceTaskKillInMills:Flag[String] = flag("force_task_kill_mills","120000","Force Task to be killed in Mills")
  }
  var env:String = null
  var frameworkName = "spark.scoring.framework"
  val failoverTimeout = 300000 // 5 minutes, in milis
  val dockerImage = "spark.mesos.executor.docker.image"

  def main():Unit = {


    ScoringFramework.frameworkName = "io.hmheng." +
      config.scoringProfile() + "." + ScoringFramework.frameworkName

    env = ScoringFramework.config.scoringProfile()

    log.info("Framework [{}]!", frameworkName)
    log.info("Scoring Host:-----------------> [{}]",ServicesConfiguration.config.getString("scoring.host"))


    // Setup the SparkConfig and StreamingContext


    var sparkConfig = createSparkConf(frameworkName  , config.scoringProfile())
    log.info("Docker image [{}]", sparkConfig.get(dockerImage , "Nothing"))
    log.info("Spark Mesos Contraints [{}]!", sparkConfig.get("spark.mesos.constraints" , "Not Set"))

    val ssc = getStreamingContext(sparkConfig)

    SparkJobHandler.createQueueStream(ssc)

    val kinesisClientConfiguration:KinesisClientLibConfiguration = getKinesisClientLibConfiguration()


    startKinesisClient(ssc,kinesisClientConfiguration, sparkConfig , ScoringFramework.config.scoringProfile())

  }


  def startKinesisClient(ssc: StreamingContext , kinesisClientConfiguration:KinesisClientLibConfiguration
                         ,sparkConfig : SparkConf , env : String): Unit = {
    val kinesisPort:LernosityKinesisScoresFactory = new LernosityKinesisScoresFactory(kinesisClientConfiguration , ssc , env)
        try {
          kinesisPort.startUp()
        }
        catch {
          case t: Throwable => log.warn("Caught throwable while Processing Stream :{}", t.getStackTrace)
        }

  }

  def getStreamingContext(sparkConf: SparkConf): StreamingContext = {

    val checkpointDir: String  = sparkConf.get("spark.app.checkpoint_dir")

    functionToCreateContext()
  }

  def functionToCreateContext(): StreamingContext = {
    var sparkConfig = createSparkConf(frameworkName  , config.scoringProfile())
    val batchInterval = Milliseconds(2000)
    val ssc = new StreamingContext(sparkConfig, batchInterval)
    ssc
  }


}
