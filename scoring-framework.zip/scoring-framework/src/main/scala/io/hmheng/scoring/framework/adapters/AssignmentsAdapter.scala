package io.hmheng.scoring.framework.adapters

import java.time.LocalDateTime

import io.hmheng.scoring.services.assignments._
import io.hmheng.scoring.utils.json.JsonObjectMapper


class AssignmentsAdapter extends JsonObjectMapper{

  def accept(assignmentsServiceResponse: String): AssignmentsData = {
    val assignmentsResponse = objectMapper.readValue(assignmentsServiceResponse, classOf[AssignmentsResponse])
    handleAssignmentsServiceResponse(assignmentsResponse)
  }

  private[this] def handleAssignmentsServiceResponse(assignmentsResponse: AssignmentsResponse): AssignmentsData = {
    val testType = "B"
    val battery = deemBattery(assignmentsResponse.items.head.discipline)
    val grade = Some(assignmentsResponse.items.head.organisations.head.grades.head.grade).getOrElse("")
    val level = Some(assignmentsResponse.items.head.organisations.head.grades.head.level).getOrElse("")
    val startDate = originalDateTime(assignmentsResponse.items.head.originalStartDate, assignmentsResponse.items.head.startDate)
    val finishDate = originalDateTime(assignmentsResponse.items.head.originalFinishDate, assignmentsResponse.items.head.finishDate)
    val normDate = assignmentsResponse.items.head.normDate
    new AssignmentsData(testType, battery, grade, level, normDate, startDate, finishDate)
  }


  private[this] def deemBattery(discipline: String): String = {
    if (discipline.startsWith("M") || (discipline.startsWith("B") && !discipline.contains("ELA"))) {
      "M"
    }
    else {
      "E"
    }
  }

  private[this] def originalDateTime(originalDate: LocalDateTime, currentDate:LocalDateTime): LocalDateTime = {
    if (originalDate != null) {
      originalDate
    } else {
      currentDate
    }
  }
}
