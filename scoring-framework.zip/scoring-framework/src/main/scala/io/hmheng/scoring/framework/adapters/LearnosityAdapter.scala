package io.hmheng.scoring.framework.adapters

import java.util.UUID

import com.amazonaws.services.kinesis.model.Record
import com.fasterxml.jackson.databind.JsonMappingException
import io.hmheng.scoring.Logging
import io.hmheng.scoring.framework.ScoringFramework
import io.hmheng.scoring.framework.config.{Profile, ServicesConfiguration}
import io.hmheng.scoring.framework.event.SparkErrorHandler
import io.hmheng.scoring.framework.jobs.{ SparkJob}
import io.hmheng.scoring.processors.DataProcessor
import io.hmheng.scoring.services.learnosity.{LearnosityDataBenchmark, LearnosityDataFormative}
import io.hmheng.scoring.services.security.SecurityUtils
import io.hmheng.scoring.utils.{TestTypeHelper, TestType, FailureType, FailedRequest}
import io.hmheng.scoring.utils.json.JsonObjectMapper


class LearnosityAdapter(var env: String) extends JsonObjectMapper with Logging with TestTypeHelper{

    ScoringFramework.env = env

   def processRecord(record: Record): SparkJob = {
    val data: String = new String(record.getData.array(), "UTF-8")
    log.info("Processing record with data: {}", data)
    accept(data)
  }

  def accept(inputData: String): SparkJob = {
    val uuid = UUID.randomUUID().toString
    val startTime = System.currentTimeMillis()

    log.info("**** {} learnosity data received", uuid)
    log.info("**** {} profile", env)
    log.info("**** {} profile from ServicesConfiguration",ServicesConfiguration.profile)
    validate(inputData)
    var sparkJob: SparkJob = null
    val sifAuthorization = SecurityUtils.getSIFAuthorization(ServicesConfiguration.scoringClientId,
      ServicesConfiguration.scoringClientSecret)
    val authorization = sifAuthorization.getAuthorization
    val authCurrentDateTime = sifAuthorization.getAuthCurrentDateTime

    try {
      if (inputData.contains("\"ability_estimate\"")) {
        var benchmarkLearnosityData = getBenchmarkLearnosityData(inputData)
        sparkJob = new SparkJob(DataProcessor.processBenchmark(benchmarkLearnosityData, inputData), false, pushScores(benchmarkLearnosityData.status,false), inputData)
      } else {
        var formativeLearnosityData = getFormativeLearnosityData(inputData)
        var formativeSparkJobString = DataProcessor.processFormative(formativeLearnosityData, inputData)
        var testType = TestType.withName(formativeLearnosityData.eventType)
        var isProvisionScoresAllowed = isAllowProvisionalScores(testType)
        sparkJob = new SparkJob(formativeSparkJobString, true, pushScores(formativeLearnosityData.status , isProvisionScoresAllowed), inputData)
      }
      log.info(s"**** {} learnosity data received and job created time taken: ${System.currentTimeMillis() - startTime}", uuid)
    } catch {
      case exception: Exception =>
        log.error("Failed to create spark job {}!", inputData)
        log.error("Error cause: ", exception)
        SparkErrorHandler.sendToDeadletterSqsQueue()
    }

    sparkJob
  }

  def pushScores(input: String , isProvisionScoresAllowed: Boolean): Boolean = {
    var pushScores:Boolean = true
    if("Completed" != input && !isProvisionScoresAllowed){
      pushScores = false
    }
    pushScores
  }

  def validate(input: String): Unit = {
    require(input.nonEmpty, "Learnosity stream should not be empty!")
    require(input.contains("\"activity_id\":"), "Learnosity stream should contain activity_id!")
    require(input.contains("\"session_id\":"), "Learnosity stream should contain session_id!")
  }

  @throws(classOf[JsonMappingException])
  def getBenchmarkLearnosityData(inputData: String): LearnosityDataBenchmark = {
    try {
      objectMapper.readValue(inputData, classOf[LearnosityDataBenchmark])
    } catch {
      case exception: Exception =>
        log.error("DATA_INTEGRITY BENCHMARK Failed to convert Benchmark Learnosity Data : {}" , inputData);
        log.error("Error cause DATA_INTEGRITY: ", exception)
        throw exception
    }
  }

  @throws(classOf[JsonMappingException])
  def getFormativeLearnosityData(inputData: String): LearnosityDataFormative = {
    try {
      objectMapper.readValue(inputData, classOf[LearnosityDataFormative])
    } catch {
      case exception: Exception =>
        log.error("DATA_INTEGRITY FORMATIVE Failed to convert Formative Learnosity Data: {}" , inputData)
        log.error("Error cause DATA_INTEGRITY: ", exception)
        throw exception
    }
  }
}
