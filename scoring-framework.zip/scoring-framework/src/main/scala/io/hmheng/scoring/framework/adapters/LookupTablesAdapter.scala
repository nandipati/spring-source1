package io.hmheng.scoring.framework.adapters

import io.hmheng.scoring.services.scoringapi.{LossAndHossLookup, LookupTableList, LookupTable}
import io.hmheng.scoring.utils.json.JsonObjectMapper


class LookupTablesAdapter extends JsonObjectMapper {

  def getLookupTables(scoringInput:String):List[LookupTable] = {

    objectMapper.readValue(scoringInput, classOf[LookupTableList]).lookups
  }

  def getLossAndHoss(scoringInput:String):LossAndHossLookup = {
    if (scoringInput.equals("{}") || scoringInput.equals("{ }")) {
      return null
    }
    objectMapper.readValue(scoringInput, classOf[LossAndHossLookup])
  }
}
