package io.hmheng.scoring.framework.config


object AwsConfiguration extends Profile{

  def getARN: String = {
    config.getString("aws.arn")
  }

  def getAccountId: String = {
    config.getString("aws.accountId")
  }

  def getSessionTokenDurationSeconds: String = {
    config.getString("aws.sessionTokenDurationSeconds")
  }

  def getARNScoreDeadletter: String = {
    config.getString("aws.arnScoreDeadletter")
  }

  def getScoresAssesmentDeadletter: String = {
    config.getString("aws.scoresAssesmentDeadletter")
  }

  def getAccountIdDeadletter: String = {
    config.getString("aws.accountIdDeadletter")
  }

  def isSts:Boolean = {
    config.getBoolean("aws.isSts")
  }
}
