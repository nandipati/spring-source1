package io.hmheng.scoring.framework.config

import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration
import com.typesafe.config.ConfigException
import io.hmheng.scoring.Logging


object KinesisConfiguration extends Profile with Logging {

  def getApplicationName: String = {
    config.getString("kinesis.applicationName")
  }

  def getStreamName: String = {
    config.getString("kinesis.streamName")
  }

  def getAccessKey: String = {
    var accessKey: String = null
    try {
      accessKey = config.getString("kinesis.accessKey")
    }
    catch {
      case e:ConfigException => log.warn("No acessKey in configuration file")
    }
    accessKey
  }

  def getSecretKey: String = {
    var secretKey: String = null
    try {
      secretKey = config.getString("kinesis.secretKey")
    }
    catch {
      case e:ConfigException => log.warn("No secretKey in configuration file")
    }
    secretKey
  }

  def getRegion: String = {
    config.getString("kinesis.region")
  }

  def getPartitionKey: String = {
    config.getString("kinesis.partitionKey")
  }

  def getMaxRecords: Int= {
    var maxRecords: Int = KinesisClientLibConfiguration.DEFAULT_MAX_RECORDS
    try {
      config.getInt("kinesis.maxRecords")
    }catch {
      case e:ConfigException => log.warn("No Max Records in configuration file")
    }
    maxRecords
  }

  def getMaxThreads: Int= {
      config.getInt("kinesis.maxThreads")
  }

  def getEndpointUrl: String = {
    config.getString("kinesis.endpointUrl")
  }

}
