package io.hmheng.scoring.framework.config


object MesosConfiguration extends Profile{
  val mesosMaster = config.getString("mesos.master")
}
