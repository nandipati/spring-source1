package io.hmheng.scoring.framework.config

import com.typesafe.config.{ConfigSyntax, ConfigParseOptions, ConfigException, ConfigFactory}
import io.hmheng.scoring.framework.ScoringFramework
import io.hmheng.scoring.services.HttpRestClient


trait Profile {
  val profile = if (ScoringFramework.env !=null) ScoringFramework.env else ScoringFramework.config.scoringProfile()

  val codexURL = "https://user:5432132121@api.cert.br.internal/report-config-server/develop/scoringframework-" + profile + ".properties"
  val codexResponse = HttpRestClient.getRestContent(codexURL)

  val configurationOptions = ConfigParseOptions.defaults()
    .setSyntax(ConfigSyntax.PROPERTIES)
    .setAllowMissing(true)

  val localConfiguration =
    try {
      ConfigFactory.load.getConfig(profile)
    }
    catch {
      case e:ConfigException => null
    }

  val config = if (profile.equals("local") && localConfiguration != null)
    ConfigFactory.load.getConfig(profile) else ConfigFactory.parseString(codexResponse, configurationOptions)

}
