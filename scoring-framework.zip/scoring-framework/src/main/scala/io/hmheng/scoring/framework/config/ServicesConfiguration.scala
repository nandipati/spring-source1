package io.hmheng.scoring.framework.config


object ServicesConfiguration extends Profile {

  val retryLimitMesos:Int = config.getInt("retry.limit.mesos")
  val retryLimitBenchmarkTask:Int = config.getInt("retry.limit.benchmarkTask")
  val assignmentsHost: String = config.getString("assignments.host")
  val assignmentsClientId: String = config.getString("assignments.clientId")
  val assignmentsClientSecret: String = config.getString("assignments.clientSecret")
  val scoringHost: String = config.getString("scoring.host")
  val scoringClientId: String = config.getString("scoring.clientId")
  val scoringClientSecret: String = config.getString("scoring.clientSecret")

}
