package io.hmheng.scoring.framework.config

/**
 * Created by nandipatim on 9/9/16.
 */
object SparkConfiguration extends Profile{
  val sparkMaster = config.getString("spark.master")

  def getMesosExecutorCore: String = {
    config.getString("spark.mesos.mesosExecutor.cores")
  }

  def getExecutorUri: String = {
    config.getString("spark.executor.uri")
  }

  def getHomeDir: String = {
    config.getString("spark.mesos.home")
  }

  def getMemoryFraction: String = {
    config.getString("spark.memory.fraction")
  }

  def getMemoryStorageFraction: String = {
    config.getString("spark.memory.storageFraction")
  }
  
  def getDriverMemory: String ={
    config.getString("spark.driver.memory")
  }

  def getExecutorMemory: String ={
    config.getString("spark.executor.memory")
  }

  def dockerImage: String ={
    config.getString("spark.dockerImage")
  }
}
