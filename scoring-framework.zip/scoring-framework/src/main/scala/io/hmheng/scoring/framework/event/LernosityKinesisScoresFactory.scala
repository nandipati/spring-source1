package io.hmheng.scoring.framework.event

import com.amazonaws.auth.{DefaultAWSCredentialsProviderChain}
import com.amazonaws.regions.{Regions, Region}
import com.amazonaws.services.kinesis.AmazonKinesisClient
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.{InitialPositionInStream, KinesisClientLibConfiguration}
import io.hmheng.scoring.Logging
import io.hmheng.scoring.framework.config.{AwsConfiguration}
import io.hmheng.scoring.framework.jobs.{SparkJobHandler}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.kinesis.{KinesisUtils}
import org.apache.spark.streaming.{StreamingContext, Milliseconds}
import io.hmheng.scoring.framework.adapters.LearnosityAdapter



class LernosityKinesisScoresFactory(@transient val config: KinesisClientLibConfiguration , @transient val sc:StreamingContext
                                     ,env : String) extends Serializable with Logging{

  @transient lazy val adapter = new LearnosityAdapter(env)
  @transient lazy  val ssc  = build(sc,env)

  def build(sc: StreamingContext,env : String): StreamingContext = {

    val kinesisClient:AmazonKinesisClient = getKinesisClient(env)

    kinesisClient.setRegion(Region.getRegion(Regions.US_EAST_1));
    val numShards = kinesisClient.describeStream(config.getStreamName).getStreamDescription().getShards().size
    val numStreams = numShards
    val batchInterval = Milliseconds(20000)
    val kinesisCheckpointInterval = batchInterval
    val regionName = config.getRegionName
    // Create the Kinesis DStreams
    val kinesisStreams = (0 until numStreams).map { i =>
      //FIXME:KinesisInputDStream.builder should be used to remove deprecated code of KinesisUtils.
      if(AwsConfiguration.isSts) {
        KinesisUtils.createStream(sc, config.getApplicationName, config.getStreamName, config.getKinesisEndpoint, regionName,
          InitialPositionInStream.TRIM_HORIZON, kinesisCheckpointInterval, StorageLevel.MEMORY_AND_DISK_2, adapter.processRecord,
          null, null, AwsConfiguration.getARN, "SCORING_FRAMEWORK", null)
      }else{
        KinesisUtils.createStream(sc, config.getApplicationName, config.getStreamName, config.getKinesisEndpoint, regionName,
          InitialPositionInStream.TRIM_HORIZON, kinesisCheckpointInterval, StorageLevel.MEMORY_AND_DISK_2, adapter.processRecord)
      }
    }
    val unifiedStream = sc.union(kinesisStreams)
    //unifiedStream.foreachRDD{arrySparkJob++=_.collect()}
    unifiedStream.foreachRDD( rdd => {
      SparkJobHandler.addJobRDDToStream(rdd)

      log.info(s"Queue Size ${SparkJobHandler.jobsQueue.size} rdd {}",rdd.toString())
    })
    sc
  }

  def getKinesisClient(env:String): AmazonKinesisClient ={
      new AmazonKinesisClient(config.getKinesisCredentialsProvider, config.getKinesisClientConfiguration);
  }

  def startUp(): Unit = {
    ssc.start()
    ssc.awaitTermination()
  }

  def shutdown(): Unit = {
    ssc.stop(true,true)
  }

}
