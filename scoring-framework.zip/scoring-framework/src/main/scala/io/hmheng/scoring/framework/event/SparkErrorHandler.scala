package io.hmheng.scoring.framework.event

import com.amazonaws.regions.{Regions, Region}
import com.amazonaws.services.sqs.model.{GetQueueUrlResult, GetQueueUrlRequest, SendMessageRequest, CreateQueueRequest}
import com.amazonaws.services.sqs.{AmazonSQSClient, AmazonSQS}
import com.fasterxml.jackson.databind.{DeserializationFeature, ObjectMapper}
import io.hmheng.scoring.Logging
import io.hmheng.scoring.framework.config.AwsConfiguration
import io.hmheng.scoring.utils.FailedRequest
import io.hmheng.scoring.framework.scheduler.aws.configuration.{CredentialProvider}
import sun.java2d.cmm.Profile

import scala.collection.mutable

object SparkErrorHandler extends Logging  {
  val failedRequestQueue = mutable.Queue[FailedRequest]()

  def getFailedRequestQueue(): mutable.Queue[FailedRequest] = {
    synchronized {
      failedRequestQueue
    }
  }

  def addRequestToQueue(request: FailedRequest): Unit = {
    synchronized {
      failedRequestQueue += request
    }
  }

  def sendToDeadletterSqsQueue(): Unit = {
    var sqs: AmazonSQS = getAmazonSQSClientForProfile()
    val usEast1: Region = Region.getRegion(Regions.US_EAST_1)
    sqs.setRegion(usEast1)
    synchronized {
      try {
        val createQueueRequest: GetQueueUrlRequest = new GetQueueUrlRequest()
          .withQueueName(AwsConfiguration.getScoresAssesmentDeadletter)
          .withQueueOwnerAWSAccountId(AwsConfiguration.getAccountIdDeadletter)
        val deadletterQueueUrl: GetQueueUrlResult = sqs.getQueueUrl(createQueueRequest)

        var mapper: ObjectMapper = new ObjectMapper()
        mapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, true)
        while (failedRequestQueue.nonEmpty) {
          val request: FailedRequest = failedRequestQueue.dequeue()
          val requestJson: String = mapper.writeValueAsString(request)
          log.error("Sending failed scoring request to deadletter queue", request.getData)
          sqs.sendMessage(new SendMessageRequest(deadletterQueueUrl.getQueueUrl, requestJson))
        }
      } catch {
        case exception: Exception =>
          log.error("Failed to send message to deadletter queue")
          log.error("Error cause: ", exception)
          throw exception
      }
    }
  }

  def getAmazonSQSClientForProfile(): AmazonSQS = {
    var sqs: AmazonSQS = null
    log.info("current profile running: " + AwsConfiguration.profile)
    if(AwsConfiguration.profile.equals("local")) {
      sqs = new AmazonSQSClient()
    } else {
      sqs = new AmazonSQSClient(new CredentialProvider(AwsConfiguration.getARNScoreDeadletter))
    }
    sqs
  }

}
