package io.hmheng.scoring.framework.jobs


object JobUtils {

  val FORMATIVE_COMMAND: String =  "java -jar " + "/formative.jar"
  val BENCHMARK_COMMAND: String =  "java -jar " + "/benchmark.jar"
}
