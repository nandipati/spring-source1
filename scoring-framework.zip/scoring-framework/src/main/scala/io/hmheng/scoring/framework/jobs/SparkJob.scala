package io.hmheng.scoring.framework.jobs

import io.hmheng.scoring.framework.config.ServicesConfiguration
import io.hmheng.scoring.services.security.SecurityUtils

/**
 * Created by nandipatim on 9/23/16.
 */
class SparkJob( var command:String ,val data:String, val isFormative:Boolean, val kinesisMessage:String) extends Serializable {

  var authorization:String = null
  var authCurrentDateTime:String = null
  var endpoint:String = ServicesConfiguration.scoringHost

  def this(data:String, isFormative:Boolean , ispushScores:Boolean, kinesisMessage:String) = {
    this(if (isFormative) JobUtils.FORMATIVE_COMMAND else JobUtils.BENCHMARK_COMMAND , data , isFormative, kinesisMessage)

    if (isFormative) endpoint = endpoint+"/formative?pushScores="+ispushScores else endpoint = endpoint+"/benchmark?pushScores="+ispushScores

    val sifAuthorization = SecurityUtils.getSIFAuthorization(ServicesConfiguration.scoringClientId,
      ServicesConfiguration.scoringClientSecret)
    authorization = sifAuthorization.getAuthorization
    authCurrentDateTime = sifAuthorization.getAuthCurrentDateTime

    this.command = command + " \"" + data.replace("\"","@")+ "\" " + endpoint + " \"" + authorization + "\" " + authCurrentDateTime
  }

  def getEndpoint:String = {
    endpoint
  }

  def getAuthorization:String = {
    authorization
  }

  def getAuthCurrentDateTime:String = {
    authCurrentDateTime
  }

  def getData:String = {
    data
  }

  def isBenchmark:Boolean = {
    !isFormative
  }

  def getKinesisMessage:String = {
    kinesisMessage
  }
}
