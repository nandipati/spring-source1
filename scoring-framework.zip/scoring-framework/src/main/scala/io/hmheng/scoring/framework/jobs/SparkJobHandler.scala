package io.hmheng.scoring.framework.jobs

import io.hmheng.scoring.Logging
import io.hmheng.scoring.domain.benchmark.BenchmarkAdapter
import io.hmheng.scoring.domain.formative.FormativeAdapter
import io.hmheng.scoring.framework.ScoringFramework._
import io.hmheng.scoring.framework.config.ServicesConfiguration
import io.hmheng.scoring.framework.event.SparkErrorHandler
import io.hmheng.scoring.utils.{FailureType, FailedRequest}
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream

import scala.collection.mutable

/**
 * Created by nandipatim on 9/23/16.
 */
object SparkJobHandler extends Logging{

  val jobsQueue = mutable.Queue[RDD[SparkJob]]()
  var ssc: StreamingContext = null

  def getJobsQueue(ssc : StreamingContext): mutable.Queue[RDD[SparkJob]] = {

    synchronized {
      if (ssc != null) {
          this.ssc = ssc
        }
      jobsQueue
    }
  }

  def addJobToStream(jobToStream: SparkJob): Unit = {
    synchronized {
      jobsQueue += ssc.sparkContext.makeRDD(Seq(jobToStream))
    }
  }

  def addJobRDDToStream(jobToStream: RDD[SparkJob]): Unit = {
    synchronized {
      jobsQueue += jobToStream
    }
  }

  def addJobRDDToStream(jobsToStream: List[RDD[SparkJob]]): Unit = {
    synchronized {
      log.info("Adding to stream "+jobsToStream.size)
      jobsQueue ++=jobsToStream
    }
  }

  def addJobsToStream(jobsToStream: List[SparkJob]): Unit = {
    synchronized {
      log.info("Adding to stream "+jobsToStream.size)
      jobsQueue += ssc.sparkContext.makeRDD(jobsToStream)
    }
  }

  def createQueueStream(sc: StreamingContext): Unit ={

    val datastream = sc.queueStream(SparkJobHandler.getJobsQueue(sc))
    datastream.foreachRDD(rdd =>
      rdd.foreach{ sparkJob => try {
        if(sparkJob != null && sparkJob.getData != null) {
          log.info("Processing RDD from Queue {} ", sparkJob.getData)
          System.out.println("Processing RDD from Queue to Engine :"+sparkJob.getData);
          processScoresThroughScoringEngine(sparkJob, 1)
        }
      } catch {
        case exception: Exception =>
          if(sparkJob != null && sparkJob.getData != null) {
            log.error("Scoring Engine failed to process task for scores {} after retries !", sparkJob.getData)
            SparkErrorHandler.sendToDeadletterSqsQueue()
          }else{
            log.error("Scoring Engine failed to process task for scores {} after retries where no data!", exception.getMessage)
          }
      }
      }
    )
  }

  def processScoresThroughScoringEngine(sparkJob :SparkJob, callCount: Int): Unit = {
    try {
      if(sparkJob.isFormative)
        new FormativeAdapter().accept(sparkJob.getData,sparkJob.getEndpoint,sparkJob.getAuthorization,sparkJob.getAuthCurrentDateTime)
      else
        new BenchmarkAdapter().accept(sparkJob.getData,sparkJob.getEndpoint,sparkJob.getAuthorization,sparkJob.getAuthCurrentDateTime)
    } catch {
      case exception: Exception if callCount < ServicesConfiguration.retryLimitBenchmarkTask =>
        log.warn("Scoring Engine failed to process task for scores {}, retrying!", sparkJob.getData)
        log.warn("Error cause: ", exception)
        processScoresThroughScoringEngine(sparkJob, callCount+1)
      case exception: Exception =>
        log.error("Scoring Engine failed to process task for scores {}!", sparkJob.getData)
        log.error("Error cause: ", exception)
        var eventType: String = ""
        if(sparkJob.isFormative) {
          eventType = "FORMATIVE"
        } else  {
          eventType = "BENCHMARK"
        }
        SparkErrorHandler.addRequestToQueue(new FailedRequest(
          FailureType.POST_SCORES,
          eventType,
          sparkJob.getKinesisMessage,
          exception))
        throw exception
    }
  }
}
