package io.hmheng.scoring.framework.scheduler.aws.configuration

import java.util.UUID

import com.amazonaws.auth.{BasicSessionCredentials, AWSCredentials, AWSCredentialsProvider}
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClient
import com.amazonaws.services.securitytoken.model.{AssumeRoleResult, AssumeRoleRequest}
import io.hmheng.scoring.Logging
import io.hmheng.scoring.framework.config.AwsConfiguration


class CredentialProvider(var arn: String)
  extends AWSCredentialsProvider with Logging {

  override def getCredentials: BasicSessionCredentials = {
    val tokenServiceClient: AWSSecurityTokenServiceClient = new AWSSecurityTokenServiceClient

    val assumeRequest: AssumeRoleRequest = new AssumeRoleRequest()
      .withRoleArn(arn)
      .withDurationSeconds(AwsConfiguration.getSessionTokenDurationSeconds.toInt)
      .withRoleSessionName(UUID.randomUUID.toString)
    val assumeResult:AssumeRoleResult = tokenServiceClient.assumeRole(assumeRequest)


    new BasicSessionCredentials(assumeResult.getCredentials.getAccessKeyId, assumeResult.getCredentials.getSecretAccessKey, assumeResult.getCredentials.getSessionToken)
  }

  override def refresh(): Unit = {

  }

}
