package io.hmheng.scoring.framework.scheduler.aws.configuration

import com.amazonaws.auth.AWSCredentialsProvider
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.{InitialPositionInStream, KinesisClientLibConfiguration}


class KCLConfigBuilder(appName: String,
                       streamName: String,
                       credentialsProvider: AWSCredentialsProvider,
                       workerName: String) {

  var config = new KinesisClientLibConfiguration(appName, streamName,
    credentialsProvider, workerName)

  def withInitialPositionInStream(positionInStream: InitialPositionInStream): KCLConfigBuilder = {
      config = config.withInitialPositionInStream(positionInStream)
    this
  }

  def withRegionName(regionName: String): KCLConfigBuilder = {
    config = config.withRegionName(regionName)
    this
  }

  def withMaxRecords(maxRecords: Int): KCLConfigBuilder = {
    config = config.withMaxRecords(maxRecords)
    this
  }

  def withEndpointUrl(endpointUrl: String): KCLConfigBuilder = {
    config = config.withKinesisEndpoint(endpointUrl)
    this

  }

  def build = {
    config
  }
}
