package io.hmheng.scoring.processors

import io.hmheng.scoring.services.learnosity.LearnosityDataBenchmark
import io.hmheng.scoring.utils.json.JsonBaseConfiguration


case class BenchmarkScoringEngineEntity(val learnosityData: LearnosityDataBenchmark)
  extends JsonBaseConfiguration {
}
