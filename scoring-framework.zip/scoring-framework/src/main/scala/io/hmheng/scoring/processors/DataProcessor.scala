package io.hmheng.scoring.processors

import io.hmheng.scoring.Logging
import io.hmheng.scoring.framework.adapters.{AssignmentsAdapter, LookupTablesAdapter}
import io.hmheng.scoring.framework.config.ServicesConfiguration
import io.hmheng.scoring.framework.event.SparkErrorHandler
import io.hmheng.scoring.services.assignments.{AssignmentsData, AssignmentsService}
import io.hmheng.scoring.services.learnosity.{LearnosityDataBenchmark, LearnosityDataFormative, ItemResponse, Subscore}
import io.hmheng.scoring.services.scoringapi.{LookupTable, LossAndHossLookup, PssCoefficientLookup, ScoringService}
import io.hmheng.scoring.utils._
import io.hmheng.scoring.utils.json.JsonObjectMapper


object DataProcessor extends JsonObjectMapper with Logging with TestTypeHelper{

  val EVENT_TYPE_FORMATIVE = "FORMATIVE"
  val EVENT_TYPE_BENCHMARK = "BENCHMARK"
  var assignmentsService: AssignmentsService = new AssignmentsService

  @throws(classOf[Exception])
  def processBenchmark(benchmarkLearnosityData: LearnosityDataBenchmark, inputData: String): String = {
    processBenchmark(benchmarkLearnosityData, 1, inputData)
  }

  def validateLookupData(listOfSlots: List[String],
                         lookupTableList: List[LookupTable],
                         lossAndHoss: LossAndHossLookup) = {
    require(listOfSlots != null, "slots can't be null")
    require(lookupTableList != null, "lookup table data can't be null")
    require(lossAndHoss != null, "loss-hoss can't be null")
    require(lossAndHoss.loss > 0, "Loss can't be zero")
    require(lossAndHoss.hoss > 0, "Hoss can't be zero")
  }

  @throws(classOf[Exception])
  def processBenchmark(benchmarkLearnosityData: LearnosityDataBenchmark, callCount: Int, inputData: String): String = {
    try {
      val lookupTablesAdapter = new LookupTablesAdapter
      val assignmentsAdapter = new AssignmentsAdapter

      val sessionId = benchmarkLearnosityData.sessionId
      val activityId = benchmarkLearnosityData.activityId

      log.debug("DataProcessor.processBenchmark for activity: {}", activityId)

      val assignmentsServiceResponse = assignmentsService.getAssignmentDetailsBySessionId(sessionId, activityId)
      val assignmentsData = assignmentsAdapter.accept(assignmentsServiceResponse)

      log.info("Assignments data: {}", assignmentsData)

      val scoringService = new ScoringService(assignmentsData.testType,
        assignmentsData.battery, assignmentsData.testLevel,
        FormatsAndConfiguration.getNormYearFromDate(assignmentsData.normDate), assignmentsData.grade)

      //call scoring service to get the coefficients
      val scoringInput = scoringService.getCoefficientLookupTables

      //calling scoring service to get the lossandhoss
      val lossAndHoss = lookupTablesAdapter.getLossAndHoss(scoringService.getLossAndHoss)

      //get the lookup tables
      val lookupTableList = lookupTablesAdapter.getLookupTables(scoringInput)

      //get the slots from the lookupTables response
      val listOfSlots = lookupTableList.map(x => assignmentsData.battery + x.slot)

      validateLookupData(listOfSlots,lookupTableList,lossAndHoss)

      val benchmarkScoringEngineEntity = new BenchmarkScoringEngineEntity(
        updateBenchmarkData(benchmarkLearnosityData, listOfSlots, lookupTableList, assignmentsData, lossAndHoss))

      objectMapper.writeValueAsString(benchmarkScoringEngineEntity)
    } catch {
      case exception: Exception if callCount < ServicesConfiguration.retryLimitBenchmarkTask =>
        log.warn("Failed to create benchmark task for activity {}, retrying!", benchmarkLearnosityData.activityId)
        log.warn("Error cause: ", exception)
        processBenchmark(benchmarkLearnosityData, callCount+1, inputData)
      case exception: Exception =>
        log.error("Failed to create benchmark task for activity {}!", benchmarkLearnosityData.activityId)
        log.error("Error cause: ", exception)
        log.error("{}", benchmarkLearnosityData);
        log.error("{}", inputData);
        SparkErrorHandler.addRequestToQueue(new FailedRequest(
          FailureType.PROCESS_LOOKUP,
          "BENCHMARK",
          inputData,
          exception
        ))
        throw exception
    }
  }


  def processFormative(formativeLearnosityData: LearnosityDataFormative, inputData: String): String = {
    log.debug("DataProcessor.processFormative")

    try {
      val formativeScoringEntity = new FormativeScoringEngineEntity(updateFormativeData(formativeLearnosityData))
      objectMapper.writeValueAsString(formativeScoringEntity)
    } catch {
      case exception: Exception =>
        exception.printStackTrace()
        log.error("Failed to create formative task for activity {}!", formativeLearnosityData.activityId)
        log.error("Error cause DATA_INTEGRITY : ", exception)
        log.error("DATA_INTEGRITY Error to convert data from Learnosity for Formative : {}", inputData)
        throw exception
    }
  }

  /**
    * Function updates the list of responses received from Learnosity with the right scores for multiple responses items
    *
    * @param responses the list of responses received from Learnosity
    * @return the list of updated responses (all items with multiple responses are joined into a single response result)
    */
  private[this] def sumMultipleResponsesForSameItem(responses: List[ItemResponse],
                                                    formativeData: LearnosityDataFormative,
                                                    isAllowProvisionalScores:Boolean): List[ItemResponse] = {

    def sum[T](xs: List[T])(f: (T) => Int) = xs.map(f).sum
    val updatedResponses: List[ItemResponse] = replaceNullScoresWithZero(responses ,
                                                                        formativeData,
                                                                        isAllowProvisionalScores)
    updatedResponses.groupBy(_.itemReference).map {
      case (k, v) =>
        if (!areAllScoresNull(v)) {
          val maxScore:Integer = validateForMaxScoreZero(sum(v)(_.maxScore) , isAllowProvisionalScores:Boolean);
          var responseId = areAllScoresResponseId(v)
          var questionType = areAllScoresQuestionType(v)
          val automarkable = areAllScoresAutomarkable(v)
          val scoringStatus = getScoringStatusForItem(v)
          if(!formativeData.manualScoringRequired) {
            formativeData.manualScoringRequired = !automarkable
          }

          new ItemResponse(responseId , questionType, maxScore, int2Integer(sum(v)(_.score)), areAllScoresAttempted(v),
            areAllScoresAutomarkable(v), k, scoringStatus)
        }else {
          var responseId = areAllScoresResponseId(v);
          val maxScore:Integer = validateForMaxScoreZero(sum(v)(_.maxScore) , isAllowProvisionalScores:Boolean);
          var questionType = areAllScoresQuestionType(v);
          val scoringStatus = getScoringStatusForItem(v)
          if(!isAllowProvisionalScores) {
            new ItemResponse(responseId, questionType, maxScore, null, false, false, k, scoringStatus)
          }else{
            val score = sum(v)(_.score)
            val automarkable = areAllScoresAutomarkable(v)
            if(!formativeData.manualScoringRequired) {
              formativeData.manualScoringRequired = !automarkable
            }
            new ItemResponse(responseId, questionType, maxScore, score,  areAllScoresAttempted(v), automarkable,
              k, scoringStatus)
          }
        }
    }.to[collection.immutable.List]
  }

  private[this] def getScoringStatusForItem(responses: List[ItemResponse]): String = {

    var scoringStatus: String = "NOT_STARTED"
    var previousResponseStatus: String = ""

    responses.foreach(response => {
      if(response.score == 0 && response.maxScore == 0) {
        if (scoringStatus.equals("COMPLETED")) {
          scoringStatus = "IN_PROGRESS"
          previousResponseStatus = "IN_PROGRESS"
        }else{
          previousResponseStatus = "NOT_STARTED"
        }
      } else if(response.maxScore > 0 && !previousResponseStatus.equals("IN_PROGRESS")
        && !previousResponseStatus.equals("NOT_STARTED")){
        scoringStatus = "COMPLETED"
      }
    })
    scoringStatus
  }

    private[this] def areAllScoresResponseId(responses: List[ItemResponse]): String = {

    var responseId:String = "";
    var responseSize = responses.size;

    responses.foreach(response => {
      if(responseSize > 1) {
        responseId = responseId + "|" + response.responseId
      }else{
        responseId = response.responseId
      }
    })

    responseId
  }

  private[this] def areAllScoresQuestionType(responses: List[ItemResponse]): String = {

    var questionType:String = "";
    var responseSize = responses.size;
    responses.foreach(response => {
      if(responseSize > 1) {
        questionType = questionType + "|" + response.questionType
      }else{
        questionType = response.questionType
      }
    })

    questionType
  }

  private[this] def validateForMaxScoreZero(maxScore: Integer , isAllowProvisionalScores:Boolean): Integer = {
      if(!isAllowProvisionalScores) {
        require(maxScore != null, "Max Score should be be present when it is attempted and not automarkable. Skipping record!")
        require(maxScore > 0, "Max Score must be bigger than zero. Skipping record as it is marked as attempted but is not automarkable!")
      }
      maxScore
  }

  /**
    * Function created to replace the null score values for the questions inside an item,
    * but only when not all the scores for that item are null
    *
    * @param responses list of the responses gotten from Learnosity
    * @return list of responses with updated scores only where same item has multiple responses
    */
  private[this] def replaceNullScoresWithZero(responses: List[ItemResponse],
                                              formativeData: LearnosityDataFormative,
                                              isAllowProvisionalScores: Boolean): List[ItemResponse] = {
    responses.foreach(response => {

      if (response.score == null && response.maxScore == null) {
        response.scoringStatus = "NOT_STARTED"
      }else{
        response.scoringStatus = "COMPLETED"
      }

        if(!isAllowProvisionalScores){
        response.validateItemRespnse
        if (response.score == null && (response.attempted || response.automarkable)) {
          response.score = int2Integer(0)
          if(response.maxScore == null) {
            response.maxScore = int2Integer(0)
          }
        }
      }else{
        if(!formativeData.status.equals("ReadyForScoring") && formativeData.status.equals("Completed")) {
          if(!response.automarkable && response.score == null && response.maxScore == null){
            formativeData.status = "ReadyForScoring"
          }
        }
        if (response.score == null || response.maxScore == null) {
          response.score = int2Integer(0)
          if(response.maxScore == null) {
            response.maxScore = int2Integer(0)
          }
        }
      }
    })
    responses
  }

  /**
    * Function updates the formative data received from Learnosity with the eventType and
    * the right scores for multiple responses items
    *
    * @param formativeData data received from Learnosity
    * @return formativeData with eventType and updated scores
    */
  private[this] def updateFormativeData(formativeData: LearnosityDataFormative): LearnosityDataFormative = {

    val scoringService = new ScoringService(EVENT_TYPE_FORMATIVE , null , null , 0 , null)

    val eventString = scoringService.getEvent(formativeData.activityId)
    val event = scoringService.mapObject(eventString)

    if(event.testType == null) {
      event.testType = EVENT_TYPE_FORMATIVE
    }

    val eventTypeEnum = TestType.withName(event.testType)
    formativeData.eventType = TestType.withName(event.testType).toString

    if(event.manualScoringRequired == null) {
      event.manualScoringRequired = false
    }

    formativeData.manualScoringRequired = event.manualScoringRequired

    val allowProvisionalScores = isAllowProvisionalScores(eventTypeEnum)
    formativeData.isAllowProvisionalScores = allowProvisionalScores;

    formativeData.responses = sumMultipleResponsesForSameItem(formativeData.responses, formativeData , allowProvisionalScores)
    formativeData
  }

  /**
    * The function checks if all the scores in the given responses list are null
    *
    * @param responses list of responses for only one item
    * @return true or false if it meets the criteria
    */
  private[this] def areAllScoresNull(responses: List[ItemResponse]): Boolean = responses match {
    case x :: xs => if (xs.nonEmpty) xs forall (_.score == x.score && x.score == null) else x.score == null
    case _ => true
  }

  /**
   * The function checks if all the scores in the given responses list are null
   *
   * @param responses list of responses for only one item
   * @return true or false if it meets the criteria
   */
  private[this] def areAllScoresAttempted(responses: List[ItemResponse]): Boolean = {

    var attempted:Boolean = false

    responses.foreach(response => {
        if (response.attempted) {
          attempted = response.attempted
        } else if(!response.attempted && response.score > 0){
          attempted = true
        }
      })

    attempted
  }


  private[this] def areAllScoresAutomarkable(responses: List[ItemResponse]): Boolean = {

    var automarkable:Boolean = false

    responses.foreach(response => {
      if (response.automarkable && response.maxScore <= 0) {
        automarkable = false
      } else if(response.automarkable){
        automarkable = response.automarkable
      }
    })

    automarkable
  }


  private[this] def updateBenchmarkData(benchmarkData: LearnosityDataBenchmark,
                                        listOfSlots: List[String],
                                        lookupTableList: List[LookupTable],
                                        assignmentsData: AssignmentsData,
                                        lossAndHoss: LossAndHossLookup): LearnosityDataBenchmark = {
    benchmarkData.subscores = addLookupToSubscores(filterSubscores(benchmarkData.subscores, listOfSlots), lookupTableList)
    benchmarkData.activityDiscipline = assignmentsData.battery
    benchmarkData.activityGrade = assignmentsData.grade
    benchmarkData.activityLevel = assignmentsData.testLevel
    benchmarkData.normDate = assignmentsData.normDate
    benchmarkData.startDate = assignmentsData.startDate
    benchmarkData.finishDate = assignmentsData.finishDate
    benchmarkData.eventType = EVENT_TYPE_BENCHMARK
    benchmarkData.hoss = lossAndHoss.hoss.toDouble
    benchmarkData.loss = lossAndHoss.loss.toDouble
    benchmarkData
  }

  private[this] def filterSubscores(subscores: List[Subscore], slots: List[String]): List[Subscore] = {
    subscores.filter(s => slots.exists(x => x.equals(s.id)))
  }

  private[this] def addLookupToSubscores(subscores: List[Subscore], lookupTableList: List[LookupTable]): List[Subscore] = {
    subscores.foreach(s => s.lookup = lookupTableList.filter(x => s.id.equals(x.discipline + x.slot)).head)
    subscores
  }

}

