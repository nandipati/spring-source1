package io.hmheng.scoring.processors

import io.hmheng.scoring.services.learnosity.LearnosityDataFormative
import io.hmheng.scoring.utils.json.JsonBaseConfiguration


class FormativeScoringEngineEntity(val learnosityData: LearnosityDataFormative)
  extends JsonBaseConfiguration {
}
