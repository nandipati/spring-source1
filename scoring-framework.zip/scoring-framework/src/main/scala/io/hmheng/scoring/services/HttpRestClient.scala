package io.hmheng.scoring.services

import io.hmheng.scoring.framework.config.ServicesConfiguration
import org.apache.http.client.methods.HttpGet
import org.apache.http.impl.client.HttpClientBuilder
import io.hmheng.scoring.services.security.SecurityUtils.getSIFAuthorization

import scala.io.Source


object HttpRestClient {

  def getRestContentWithSecurity(url: String): String = {
    getRestContentWithSecurity(url , null)
  }

  def getRestContentWithSecurity(url: String , contentType: String): String = {
    val httpClient = HttpClientBuilder.create.build
    val httpResponse = httpClient.execute(getHttpRequest(url , contentType))
    val entity = httpResponse.getEntity
    var content = ""
    if (entity != null) {
      val inputStream = entity.getContent
      content = Source.fromInputStream(inputStream).getLines.mkString
      inputStream.close()
    }
    httpClient.close()
    content
  }

  private[this] def getHttpRequest(url: String , contentType:String): HttpGet = {
    val httpRequest:HttpGet = new HttpGet(url)
    val sifAuthorization = getSIFAuthorization(ServicesConfiguration.assignmentsClientId, ServicesConfiguration.assignmentsClientSecret)

    if(contentType != null){
      httpRequest.addHeader("content-type", contentType);
    }

    httpRequest.addHeader("AUTHORIZATION", sifAuthorization.getAuthorization)
    httpRequest.addHeader("authCurrentDateTime", sifAuthorization.getAuthCurrentDateTime)
    httpRequest
  }


  /**
    * Used for calling CODEX to get the configuration properties for a specific scoring profile
    * @param url CODEX url
    * @return configuration properties
    */
  def getRestContent(url:String): String = {
    val httpClient = HttpClientBuilder.create.build
    val httpResponse = httpClient.execute(new HttpGet(url))
    val entity = httpResponse.getEntity
    var content = ""
    if (entity != null) {
      val inputStream = entity.getContent
      content = Source.fromInputStream(inputStream).mkString
      inputStream.close()
    }
    httpClient.close()
    content
  }

}
