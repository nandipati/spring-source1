package io.hmheng.scoring.services.assignments

import java.time.LocalDateTime


case class AssignmentsData(val testType:String,
                           val battery:String,
                           val grade:String,
                           val testLevel:String,
                           val normDate:LocalDateTime,
                           val startDate:LocalDateTime,
                           val finishDate:LocalDateTime) {
  require(testType != null, "Test type should always be present")
  require(battery != null, "Discipline should always be present")
  require(normDate != null, "NormDate should always be present")
  require(startDate != null, "StartDate should always be present")
  require(finishDate != null, "FinishDate should always be present")

}
