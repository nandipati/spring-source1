package io.hmheng.scoring.services.assignments

import java.time.LocalDateTime

import com.fasterxml.jackson.databind.annotation.{JsonSerialize, JsonDeserialize}
import io.hmheng.scoring.utils.json.{LocalDateTimeDeserializer, LocalDateTimeSerializer, JsonBaseConfiguration}


case class AssignmentsResponse(val items: List[Item]) extends JsonBaseConfiguration {

}
case class Item(val assignmentStatus:String,
                val discipline:String,
                val eventName:String,
                @JsonSerialize(using = classOf[LocalDateTimeSerializer])
                @JsonDeserialize(using = classOf[LocalDateTimeDeserializer])
                var startDate:LocalDateTime,
                @JsonSerialize(using = classOf[LocalDateTimeSerializer])
                @JsonDeserialize(using = classOf[LocalDateTimeDeserializer])
                var finishDate:LocalDateTime,
                @JsonSerialize(using = classOf[LocalDateTimeSerializer])
                @JsonDeserialize(using = classOf[LocalDateTimeDeserializer])
                var normDate:LocalDateTime,
                @JsonSerialize(using = classOf[LocalDateTimeSerializer])
                @JsonDeserialize(using = classOf[LocalDateTimeDeserializer])
                var originalStartDate:LocalDateTime,
                @JsonSerialize(using = classOf[LocalDateTimeSerializer])
                @JsonDeserialize(using = classOf[LocalDateTimeDeserializer])
                var originalFinishDate:LocalDateTime,
                val refId:String,
                val status:String,
                val organisations:List[Organisation]) extends JsonBaseConfiguration {

  require(discipline != null, "Discipline should always be present")
  require(normDate != null, "NormDate should always be present")
  require(startDate != null, "Start Date should always be present")
  require(finishDate != null, "Finish Date should always be present")
  require(refId != null, "RefId should always be present")
}

case class Organisation(val grades:List[Grade]) extends JsonBaseConfiguration {

}

case class Grade(val grade:String,
                 val level:String,
                 val resource: Resource) extends  JsonBaseConfiguration {

}

case class Resource(val instanceRefId:String,
                    val primaryId:String,
                    val secondaryId:String) extends JsonBaseConfiguration {

}
