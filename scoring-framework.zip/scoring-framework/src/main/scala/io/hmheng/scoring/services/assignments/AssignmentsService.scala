package io.hmheng.scoring.services.assignments


import io.hmheng.scoring.framework.config.ServicesConfiguration
import io.hmheng.scoring.services.HttpRestClient
import io.hmheng.scoring.utils.FormatsAndConfiguration.format
import io.hmheng.scoring.utils.json.JsonObjectMapper


class AssignmentsService extends JsonObjectMapper {

  def getAssignmentDetailsBySessionId(sessionId: String, activityId: String): String = {
    val endpoint = ServicesConfiguration.assignmentsHost + "/testingEvents?sessionId={sessionId}"
    val url = format(endpoint, Map("sessionId" -> sessionId))
    HttpRestClient.getRestContentWithSecurity(url)
  }
}
