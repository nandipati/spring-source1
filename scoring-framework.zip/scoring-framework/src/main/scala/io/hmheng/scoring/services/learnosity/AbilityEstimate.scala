package io.hmheng.scoring.services.learnosity

import com.fasterxml.jackson.annotation.JsonProperty
import io.hmheng.scoring.utils.json.JsonBaseConfiguration


case class AbilityEstimate(@JsonProperty("ability_estimate") val abilityEstimate:Double,
                           @JsonProperty("standard_error") val standardError:Double)
  extends JsonBaseConfiguration {
}
