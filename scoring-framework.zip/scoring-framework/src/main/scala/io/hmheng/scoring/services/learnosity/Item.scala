package io.hmheng.scoring.services.learnosity

import com.fasterxml.jackson.annotation.JsonProperty
import io.hmheng.scoring.utils.json.JsonBaseConfiguration

/**
 * Created by nandipatim on 2/23/17.
 */
case class Item (@JsonProperty("reference") var itemReference: String,
                 var time: Integer,
                 @JsonProperty("user_flagged") var userFlagged: Boolean,
                 var scoring: Scoring
                 )
  extends JsonBaseConfiguration {

}

case class Scoring (var score: Integer,
                    @JsonProperty("max_score") var maxScore: Integer,
                    @JsonProperty("type") var itemType: String,
                     @JsonProperty("max_score_of_attempted") maxScoreAttempted: Integer,
                    @JsonProperty("max_score_of_unmarked") maxScoreUnmarked: Integer)
  extends JsonBaseConfiguration {

}