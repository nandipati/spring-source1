package io.hmheng.scoring.services.learnosity

import java.lang.{Double => JDouble}
import java.time.LocalDateTime

import com.fasterxml.jackson.annotation.JsonProperty
import com.fasterxml.jackson.databind.annotation.{JsonSerialize, JsonDeserialize}
import io.hmheng.scoring.utils.json.{LocalDateTimeDeserializer, LocalDateTimeSerializer, JsonBaseConfiguration}
import org.json.JSONObject


case class LearnosityDataBenchmark(@JsonProperty("activity_id") activityId: String,
                                   var activityGrade: String,
                                   var activityLevel: String,
                                   @JsonSerialize(using = classOf[LocalDateTimeSerializer])
                                   @JsonDeserialize(using = classOf[LocalDateTimeDeserializer])
                                   var normDate: LocalDateTime,
                                   @JsonSerialize(using = classOf[LocalDateTimeSerializer])
                                   @JsonDeserialize(using = classOf[LocalDateTimeDeserializer])
                                   var startDate: LocalDateTime,
                                   @JsonSerialize(using = classOf[LocalDateTimeSerializer])
                                   @JsonDeserialize(using = classOf[LocalDateTimeDeserializer])
                                   var finishDate: LocalDateTime,
                                   var eventType: String,
                                   var activityDiscipline: String,
                                   @JsonProperty("max_score") maxScore: Int,
                                   score:Int,
                                   @JsonProperty("session_id") sessionId: String,
                                   status: String,
                                   var subscores: List[Subscore],
                                   @JsonProperty("user_id") userId: String,
                                   var loss: JDouble,
                                   var hoss: JDouble,
                                   var items: List[Item],
                                   var responses:List[BenchmarkItemResponse])  extends JsonBaseConfiguration  {
  require(maxScore>=0, "Max Score must be a positive value!")
  require(score>=0, "Score must be a positive value!")
}

case class LearnosityDataBenchmarkList(data: List[LearnosityDataBenchmark]) extends JsonBaseConfiguration

case class BenchmarkItemResponse(@JsonProperty("response_id") var responseId: String,
                        @JsonProperty("question_type") var questionType: String,
                        @JsonProperty("max_score") var maxScore: Integer,
                        var score: Integer,
                        var attempted: Boolean,
                        var automarkable: Boolean,
                        @JsonProperty("item_reference") itemReference: String,
                        var response: Map[String,Object]) extends JsonBaseConfiguration {

}

case class Response(var value: List[String],
                    @JsonProperty("type") var responseType: String,
                    var wordCount: Integer) extends JsonBaseConfiguration {

}