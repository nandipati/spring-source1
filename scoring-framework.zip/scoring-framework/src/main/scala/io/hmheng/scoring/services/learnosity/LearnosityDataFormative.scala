package io.hmheng.scoring.services.learnosity

import com.fasterxml.jackson.annotation.JsonProperty
import io.hmheng.scoring.utils.TestType._
import io.hmheng.scoring.utils.json.JsonBaseConfiguration

case class LearnosityDataFormative (@JsonProperty("activity_id") activityId:String,
                                    var eventType:String,
                                    @JsonProperty("session_id") sessionId:String,
                                    var status:String,
                                    @JsonProperty("user_id") userId:String,
                                    var items: List[Item],
                                    var responses:List[ItemResponse],
                                    val metadata:LearnosityMetadata,
                                    var manualScoringRequired: Boolean,
                                    var isAllowProvisionalScores: Boolean)  extends JsonBaseConfiguration  {
}

case class ItemResponse(@JsonProperty("response_id") var responseId: String,
                    @JsonProperty("question_type") var questionType: String,
                    @JsonProperty("max_score") var maxScore: Integer,
                    var score: Integer,
                    var attempted: Boolean,
                    var automarkable: Boolean,
                    @JsonProperty("item_reference") itemReference: String,
                    var scoringStatus : String) extends JsonBaseConfiguration {

  validateResponse

  def validateResponse: Unit = {

    require(itemReference != null, "Item id should always be present. Skipping record!")
  }

  def validateItemRespnse: Unit = {
    if (!attempted && !automarkable) {
      if (maxScore != null) {
        require(maxScore>0, "Max Score must be bigger than zero!")
      } else {
        require((attempted || automarkable), "Attempted or Automarkable for item must be true . Skipping record! ")
      }
    } else {
      if (automarkable) {
        require(maxScore != null, "Max Score should be be present when it is automarkable. Skipping record!")
        require(maxScore > 0, "Max Score must be bigger than zero. Skipping record!")
      }
    }
  }

}
