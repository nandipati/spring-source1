package io.hmheng.scoring.services.learnosity

import com.fasterxml.jackson.annotation.JsonProperty
import io.hmheng.scoring.utils.json.JsonBaseConfiguration

/**
 * Created by nandipatim on 8/17/17.
 */
case class LearnosityMetadata(@JsonProperty("activity_template_id") var activityTemplateId: String)
  extends JsonBaseConfiguration{
}
