package io.hmheng.scoring.services.learnosity

import com.fasterxml.jackson.annotation.JsonProperty
import io.hmheng.scoring.services.scoringapi.{LookupTable, PssCoefficientLookup}
import io.hmheng.scoring.utils.json.JsonBaseConfiguration

case class Subscore(@JsonProperty("ability_estimate") val abilityEstimate: AbilityEstimate,
                    val id:String,
                    @JsonProperty("attempted_max_score") val attemptedMaxScore:Int,
                    @JsonProperty("max_score") val maxScore:Int,
                    @JsonProperty("num_attempted") val numAttempted:Int,
                    @JsonProperty("num_questions") val numQuestions:Int,
                    @JsonProperty("num_unmarked") val numUnmarked:Int,
                    val score:Int,
                    val title:String,
                    @JsonProperty("unmarked_max_score") val unmarkedMaxScore:Int,
                    var lookup:LookupTable,
                    val items:List[String])
  extends JsonBaseConfiguration {

  require(maxScore>=0, "Max Score must be a positive value!")
  require(score>=0, "Score must be a positive value!")
  require(numAttempted>=0, "NumAttempted must be a positive value!")
  require(numQuestions>=0, "NumQuestions must be a positive value!")
  require(numUnmarked>=0, "NumUnmarked must be a positive value!")
}
