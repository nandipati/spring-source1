package io.hmheng.scoring.services.scoringapi

import java.util.UUID

import io.hmheng.scoring.utils.TestType._

/**
 * Created by nandipatim on 8/17/17.
 */
case class Event(val activityId: UUID,
                 val eventId: UUID,
                 var manualScoringRequired: Boolean,
                 var testType: String) {

}
