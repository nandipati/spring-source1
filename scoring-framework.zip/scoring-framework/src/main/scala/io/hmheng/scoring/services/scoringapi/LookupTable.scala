package io.hmheng.scoring.services.scoringapi

import com.fasterxml.jackson.annotation.JsonProperty
import io.hmheng.scoring.utils.json.JsonBaseConfiguration


case class LookupTable (val mapId:Int,
                        val discipline:String,
                        val level:String,
                        val slot:String,
                        val version:Int,
                        @JsonProperty("type") val scoreType:String,
                        val scaleScoreCoefficientsLookup:ScaleScoreCoefficientsLookup,
                        val thetaCoefficientsLookup:ThetaCoefficientsLookup,
                        val scaledScoreLimitsLookup:ScaledScoreLimitsLookup,
                        val pssCoeficientsLookup:PssCoefficientLookup)
  extends JsonBaseConfiguration {
  require(slot.toInt<=28 && slot.toInt>=1, "Slot must have a value between 1 and 28!")
}
case class LookupTableList(lookups: List[LookupTable])