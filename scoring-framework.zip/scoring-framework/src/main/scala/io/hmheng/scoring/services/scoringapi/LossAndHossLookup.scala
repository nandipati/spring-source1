package io.hmheng.scoring.services.scoringapi

import io.hmheng.scoring.utils.json.JsonBaseConfiguration


case class LossAndHossLookup(val loss:Int,
                             val hoss:Int) extends JsonBaseConfiguration{

}
