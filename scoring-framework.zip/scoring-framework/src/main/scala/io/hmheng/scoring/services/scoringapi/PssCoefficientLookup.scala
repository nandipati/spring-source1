package io.hmheng.scoring.services.scoringapi

import io.hmheng.scoring.utils.json.JsonBaseConfiguration

/**
  * Created by fodori on 6/23/16.
  */
case class PssCoefficientLookup(val lookupId:Int,
                                val version:Int,
                                val testType:String,
                                val battery:String,
                                val equationType:Int,
                                val testLevel:Int,
                                val semester:String,
                                val normYear:Int,
                                val slot:Int,
                                val coefficientA: Double,
                                val coefficientB: Double,
                                val coefficientC: Double) extends JsonBaseConfiguration {

}