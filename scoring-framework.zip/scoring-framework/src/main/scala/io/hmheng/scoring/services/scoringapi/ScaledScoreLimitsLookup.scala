package io.hmheng.scoring.services.scoringapi

import io.hmheng.scoring.utils.json.JsonBaseConfiguration

case class ScaledScoreLimitsLookup(val lookupId:Int,
                                   val version:Int,
                                   val slot:Int,
                                   val input:String,
                                   val bin1Lo:String,
                                   val bin1Hi:String,
                                   val bin2Lo:String,
                                   val bin2Hi:String,
                                   val bin3Lo:String,
                                   val bin3Hi:String,
                                   val bin4Lo:String,
                                   val bin4Hi:String)  extends JsonBaseConfiguration{
  require(slot<=28 && slot>=1, "Slot must have a value between 1 and 28!")
}
