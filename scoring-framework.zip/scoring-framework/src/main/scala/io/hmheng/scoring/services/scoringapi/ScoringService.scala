package io.hmheng.scoring.services.scoringapi

import io.hmheng.scoring.framework.config.ServicesConfiguration
import io.hmheng.scoring.services.HttpRestClient
import io.hmheng.scoring.utils.FormatsAndConfiguration
import io.hmheng.scoring.utils.json.JsonObjectMapper
import FormatsAndConfiguration.format


case class ScoringService(val testType: String,
                          val battery: String,
                          val testLevel: String,
                          val normYear: Int,
                          val grade: String) extends JsonObjectMapper {

  def getCoefficientLookupTables: String = {
    validateParameters()
    val endpoint = ServicesConfiguration.scoringHost + "/lookups/coefficients?testType={testType}&battery={battery}&level={level}&normYear={normYear}"
    val level: Int = if (testLevel.startsWith("K")) 0 else testLevel.toInt

    val pathVariableMap = Map("testType" -> testType,
      "battery" -> battery,
      "level" -> level.toString,
      "normYear" -> normYear.toString)
    val url = format(endpoint, pathVariableMap)

    "{ \"lookups\": " + HttpRestClient.getRestContentWithSecurity(url) + "}"
  }


  def formatTestLevel(testLevel: String) = {
    var formattedTestLevel = testLevel
    if(testLevel.length < 2 && !testLevel.equals("K")){
      formattedTestLevel = "0" + formattedTestLevel
    }
    if(testLevel.equals("K") || testLevel.equals("0")){
      formattedTestLevel = "KG"
    }
    formattedTestLevel
  }


  def getLossAndHoss: String = {
    require(battery != null && battery.length == 1, "Battery value should be 'E' or 'M'")
    require(testLevel != null, "Grade should be a values between KG,01,02,...,11")

    val formattedTestLevel = formatTestLevel(testLevel)
    val endpoint = ServicesConfiguration.scoringHost + "/lookups/lossandhoss/battery/{battery}/grade/{grade}"
    val url = format(endpoint, Map("battery" -> battery, "grade" -> formattedTestLevel))
    HttpRestClient.getRestContentWithSecurity(url)
  }

  private[this] def validateParameters(): Unit = {
    require(normYear >= 14, "Norm year should be greater than 13!")
  }
  
    def getEvent(activityId:String): String = {
      require(activityId != null , "Activity Id should not be null")
      val endpoint = ServicesConfiguration.scoringHost + "/events/{activityId}"
      val url = format(endpoint, Map("activityId" -> activityId))

      HttpRestClient.getRestContentWithSecurity(url , "application/json")
    }
    def mapObject(event: String): Event = {
      val eventResponse = objectMapper.readValue(event, classOf[Event])
      eventResponse
    }
  
}
