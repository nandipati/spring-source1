package io.hmheng.scoring.services.scoringapi

import io.hmheng.scoring.utils.json.JsonBaseConfiguration


case class ThetaCoefficientsLookup(val lookupId:Int,
                                   val version:Int,
                                   val equationType:Int,
                                   val semester:String,
                                   val slot:Int,
                                   val coefficientA:Double,
                                   val coefficientB:Double)  extends JsonBaseConfiguration{
  require(slot<=28 && slot>=1, "Slot must have a value between 1 and 28!")
  require(equationType==3, "Equation Type must be equal with 3!")
}
