package io.hmheng.scoring.services.security

import com.hmhpub.common.token.auth.SIFAuthorization
import org.joda.time.DateTime
import org.joda.time.format.ISODateTimeFormat


object SecurityUtils {

  def getSIFAuthorization(clientId: String, clientSecret: String): SIFAuthorization = {
    val isoAuthCurrentDateTime = ISODateTimeFormat.dateTime().print(DateTime.now())
    new SIFAuthorization(clientId, clientSecret, isoAuthCurrentDateTime)
  }

}
