package io.hmheng.scoring.utils

import java.time.LocalDateTime

import com.fasterxml.jackson.databind.annotation.{JsonDeserialize, JsonSerialize}
import io.hmheng.scoring.utils.FailureType.FailureType
import io.hmheng.scoring.utils.json.{LocalDateTimeDeserializer, LocalDateTimeSerializer}


class FailedRequest(fType: FailureType, eventType: String, inputData: String, ex: Exception,
  var fDate:LocalDateTime = LocalDateTime.now()) {
  val failureType: String = fType.toString
  val failedEventType: String = eventType
  val exception: Exception = ex
  val data: String = inputData
  @JsonSerialize(using = classOf[LocalDateTimeSerializer])
  @JsonDeserialize(using = classOf[LocalDateTimeDeserializer])
  val failureDate: LocalDateTime = fDate

  def getData(): String = {
    data
  }

  def getFailureType(): String = {
    failureType
  }

  def getException(): Exception = {
    exception
  }

  def getFailedEventType: String = {
    failedEventType
  }

  def getFailureDate: LocalDateTime = {
    failureDate
  }
}
