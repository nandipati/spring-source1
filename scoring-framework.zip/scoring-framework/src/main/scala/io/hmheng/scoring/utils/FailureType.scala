package io.hmheng.scoring.utils

object FailureType extends Enumeration {
    type FailureType = Value
    val PROCESS_LOOKUP, POST_SCORES, DATA_INTEGRITY, NONE = Value
}
