package io.hmheng.scoring.utils

import java.time.LocalDateTime


object FormatsAndConfiguration {

  val regex = "\\{([^}]*)\\}".r

  def format(inputString:String, replaceWith:Map[String, String]):String = {
    val placeHolder = regex findFirstIn inputString
    placeHolder match  {
      case None => inputString
      case Some(s) =>
        val key = s.stripPrefix("{").stripSuffix("}")
        format(regex.replaceFirstIn(inputString, replaceWith.get(key).get),
               replaceWith.filterNot((t)=>t._1.equals(key)))
    }
  }

  def getNormYearFromDate(normDate:LocalDateTime):Int = {
    normDate.getYear % 100
  }
}
