package io.hmheng.scoring.utils

import java.util.concurrent.Executors

import io.hmheng.scoring.framework.config.KinesisConfiguration

import scala.concurrent.{ExecutionContext, Future}

/**
 * Created by nandipatim on 9/9/16.
 */
object IterableExtensions {

  implicit val ec = new ExecutionContext {
    val threadPool = Executors.newFixedThreadPool(KinesisConfiguration.getMaxThreads)
    override def reportFailure(cause: Throwable): Unit = {}
    override def execute(runnable: Runnable): Unit = threadPool.submit(runnable);
    def shutdown() = threadPool.shutdown();
  }

  implicit class ForeachAsync[T](iterable: Iterable[T]) {
    def foreachAsync[F <: Future[_]](futureFunc: T => F, callBackFn:PartialFunction[Any, Unit], onCompleteFn:Option[() => Unit ] = None)(implicit ec: ExecutionContext):Unit = {

      def next(i: Iterator[T]): Unit = {
        if (i.hasNext) {
          futureFunc(i.next) onComplete {
            case msg => if (callBackFn.isDefinedAt(msg)) {
              callBackFn(msg)
              next(i)
            } else throw new IllegalArgumentException(s"Provided pattern argument [$callBackFn] is incorrect and does not match with the received message: $msg ")
          }
        } else
        if(onCompleteFn.isDefined) onCompleteFn.get()
      }
      next(iterable.iterator)
    }
  }
}