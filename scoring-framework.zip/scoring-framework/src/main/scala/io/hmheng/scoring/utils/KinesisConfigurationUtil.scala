package io.hmheng.scoring.utils

import java.net.InetAddress
import java.util.UUID

import com.amazonaws.auth.{AWSCredentialsProvider, BasicSessionCredentials}
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration
import io.hmheng.scoring.Logging
import io.hmheng.scoring.framework.config.{AwsConfiguration, KinesisConfiguration}
import io.hmheng.scoring.framework.scheduler.aws.configuration.{CredentialProvider, KCLConfigBuilder}
import org.apache.spark.SparkConf

/**
 * Created by nandipatim on 10/31/16.
 */
trait KinesisConfigurationUtil extends Logging{

  def getKinesisClientLibConfiguration() : KinesisClientLibConfiguration = {
    val credentialsProvider: CredentialProvider = new CredentialProvider(AwsConfiguration.getARN)
    val workerId = InetAddress.getLocalHost.getCanonicalHostName + "." + UUID.randomUUID()

    val kinesisClientConfiguration: KinesisClientLibConfiguration =
      new KCLConfigBuilder(KinesisConfiguration.getApplicationName,
        KinesisConfiguration.getStreamName,
        credentialsProvider,
        workerId)
        .withRegionName(KinesisConfiguration.getRegion)
        .withMaxRecords(KinesisConfiguration.getMaxRecords)
        .withEndpointUrl(KinesisConfiguration.getEndpointUrl)
        .build

    kinesisClientConfiguration
  }
 }
