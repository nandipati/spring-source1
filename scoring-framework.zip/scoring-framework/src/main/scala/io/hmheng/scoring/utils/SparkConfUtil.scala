package io.hmheng.scoring.utils

import io.hmheng.scoring.Logging
import io.hmheng.scoring.framework.config.SparkConfiguration
import org.apache.spark.SparkConf

/**
 * Created by nandipatim on 10/26/16.
 */
trait SparkConfUtil extends Logging{

  def getConfigurationValue(sparkConf: SparkConf , key: String,
                            defaultValue: String) : String = {

    sparkConf.get(key , defaultValue)
  }

  def createSparkConf(frameworkName : String , profile : String) : SparkConf ={

    var sparkConfig = new SparkConf().setAppName(frameworkName)

    var checkpointDir = String.format("/mnt/efs/service/roles/hmheng-score/spark/%s/checkpoint/", profile)
    sparkConfig.set("spark.app.checkpoint_dir",checkpointDir)

    if("local".equals(profile)){
      sparkConfig.setMaster(SparkConfiguration.sparkMaster)
      sparkConfig.set("spark.executor.uri" , SparkConfiguration.getExecutorUri)
      sparkConfig.set("spark.mesos.executor.docker.image", SparkConfiguration.dockerImage)
      sparkConfig.setSparkHome(SparkConfiguration.getHomeDir)
      sparkConfig.set("spark.mesos.mesosExecutor.cores", SparkConfiguration.getMesosExecutorCore)
      sparkConfig.set("spark.memory.fraction", SparkConfiguration.getMemoryFraction)
      sparkConfig.set("spark.memory.storageFraction", SparkConfiguration.getMemoryStorageFraction)
      sparkConfig.set("spark.driver.memory" , SparkConfiguration.getDriverMemory)
      sparkConfig.set("spark.executor.memory" , SparkConfiguration.getExecutorMemory)
      sparkConfig.set("spark.app.env",profile)
      sparkConfig.set("spark.app.checkpoint_dir", SparkConfiguration.getHomeDir);
      sparkConfig.set("spark.mesos.executor.docker.volumes" , SparkConfiguration.getHomeDir);
    }
    sparkConfig
  }
}
