package io.hmheng.scoring.utils

/**
 * Created by nandipatim on 8/17/17.
 */
object TestType extends Enumeration{

  type TestType = Value
  val FORMATIVE, BENCHMARK, PROGRAM,PERFORMANCE_TASK, NONE = Value
}
