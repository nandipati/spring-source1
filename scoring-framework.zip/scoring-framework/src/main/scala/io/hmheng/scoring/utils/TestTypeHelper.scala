package io.hmheng.scoring.utils

import io.hmheng.scoring.utils.TestType._

/**
 * Created by nandipatim on 8/17/17.
 */
trait TestTypeHelper {

  def isAllowProvisionalScores(testType: TestType):Boolean = {

    testType match {
      case TestType.BENCHMARK | TestType.FORMATIVE | TestType.PERFORMANCE_TASK | TestType.NONE => false
      case n => true
    }
  }
}
