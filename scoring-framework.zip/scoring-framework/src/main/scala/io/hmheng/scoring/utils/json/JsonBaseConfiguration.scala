package io.hmheng.scoring.utils.json

import com.fasterxml.jackson.annotation.JsonIgnoreProperties


@JsonIgnoreProperties(ignoreUnknown = true)
trait JsonBaseConfiguration {

}
