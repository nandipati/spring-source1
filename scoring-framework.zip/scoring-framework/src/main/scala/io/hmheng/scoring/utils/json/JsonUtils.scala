package io.hmheng.scoring.utils.json

import java.io.IOException
import java.time.{ZonedDateTime, LocalDateTime}

import com.fasterxml.jackson.core.{JsonGenerator, JsonParser, JsonProcessingException}
import com.fasterxml.jackson.databind.{DeserializationContext, JsonDeserializer, JsonSerializer, SerializerProvider}


class LocalDateTimeSerializer extends JsonSerializer[LocalDateTime] {

  @throws(classOf[IOException])
  @throws(classOf[JsonProcessingException])
  def serialize(arg0: LocalDateTime, arg1: JsonGenerator, arg2: SerializerProvider) {
    arg1.writeString(arg0.toString)
  }
}


class LocalDateTimeDeserializer extends JsonDeserializer[LocalDateTime] {

  @throws(classOf[IOException])
  @throws(classOf[JsonProcessingException])
  def deserialize(arg0: JsonParser, arg1: DeserializationContext): LocalDateTime = {
    val zonedDateTime:ZonedDateTime = ZonedDateTime.parse(arg0.getText)
    zonedDateTime.toLocalDateTime
  }
}
