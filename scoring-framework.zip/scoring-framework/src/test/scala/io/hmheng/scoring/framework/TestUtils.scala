package io.hmheng.scoring.framework

import java.io.InputStream
import java.nio.ByteBuffer

import com.amazonaws.services.kinesis.producer.{KinesisProducer, KinesisProducerConfiguration, UserRecordResult}
import com.google.common.util.concurrent.ListenableFuture
import io.hmheng.scoring.framework.config.KinesisConfiguration
import io.hmheng.scoring.framework.event.KinesisTestConfigFactory
import KinesisTestConfigFactory._
import io.hmheng.scoring.domain.benchmark.{BenchmarkInputData, BenchmarkScoreCalculator, BenchmarkScoringRequest, SubScoreInput}

import io.hmheng.scoring.framework.benchmark.simulation.BenchmarkSimulationUtils.createSubscore

import io.hmheng.scoring.proxies.PortCommunicator

import io.hmheng.scoring.services.learnosity.Subscore



import scala.collection.JavaConverters._


object TestUtils {

  val scoringResponseLossAndHoss:InputStream = getClass.getResourceAsStream("/lossandhoss.json")
  val streamBenchmark: InputStream = getClass.getResourceAsStream("/learnosityBenchmarkKinesis.json")
  val LEARNOSITY_BENCHMARK_MESSAGE = scala.io.Source.fromInputStream(streamBenchmark).getLines.mkString

  val streamFormative: InputStream = getClass.getResourceAsStream("/learnosityFormativeKinesis.json")
  val LEARNOSITY_FORMATIVE_MESSAGE = scala.io.Source.fromInputStream(streamFormative).getLines.mkString

  val streamFormativeTest: InputStream = getClass.getResourceAsStream("/learnosityFormativeTest.json")
  val LEARNOSITY_FORMATIVE_MESSAGE_TEST = scala.io.Source.fromInputStream(streamFormativeTest).getLines.mkString


  val streamAssignments: InputStream = getClass.getResourceAsStream("/assignmentsResponse.json")
  val ASSIGNMENTS_RESPONSE = scala.io.Source.fromInputStream(streamAssignments).getLines.mkString

  val streamAssignmentsNoDiscipline: InputStream = getClass.getResourceAsStream("/assignmentsResponseNoDiscipline.json")
  val ASSIGNMENTS_RESPONSE_NO_DISCIPLINE = scala.io.Source.fromInputStream(streamAssignmentsNoDiscipline).getLines.mkString

  val streamAssignmentsNoNormDate: InputStream = getClass.getResourceAsStream("/assignmentsResponseNoNormDate.json")
  val ASSIGNMENTS_RESPONSE_NO_NORMDATE = scala.io.Source.fromInputStream(streamAssignmentsNoNormDate).getLines.mkString

  val streamAssignmentsWithOriginalDates: InputStream = getClass.getResourceAsStream("/assignmentsResponseOriginalDates.json")
  val ASSIGNMENTS_RESPONSE_ORIGINAL_DATES = scala.io.Source.fromInputStream(streamAssignmentsWithOriginalDates).getLines.mkString


  def putMessage(aMessage: String): ListenableFuture[UserRecordResult] = {
    val config: KinesisProducerConfiguration =
      createKinesisProducerConfiguration
    val producer: KinesisProducer = new KinesisProducer(config)
    val data: ByteBuffer = ByteBuffer.wrap(aMessage.getBytes)
    producer.addUserRecord(KinesisConfiguration.getStreamName, KinesisConfiguration.getPartitionKey, data)
  }

  def putBenchmarkMessage():ListenableFuture[UserRecordResult] = {
    putMessage(TestUtils.LEARNOSITY_BENCHMARK_MESSAGE)
  }

  def putFormativeMessage():ListenableFuture[UserRecordResult] = {
    putMessage(TestUtils.LEARNOSITY_FORMATIVE_MESSAGE)
  }

  def putFormativeMessageTest():ListenableFuture[UserRecordResult] = {
    putMessage(TestUtils.LEARNOSITY_FORMATIVE_MESSAGE_TEST)
  }

  //run this main if you want to put data into the dev Kinesis stream, both Formative and Benchmark
  def main(args: Array[String]): Unit = {
    //putFormativeMessageTest()
    /*  val port:PortCommunicator = new PortCommunicator();
      port.post("test","test","test","test");
  */
    val producer: BenchmarkScoreCalculator = new BenchmarkScoreCalculator(null);
    var subscore:SubScoreInput = new SubScoreInput();
    subscore.setId("test");
    subscore.setMaxScore(10);
    var subscoreList: List[SubScoreInput] = List.empty

    subscoreList = subscoreList ::: List(subscore);

    var bench:BenchmarkInputData=new BenchmarkInputData();
    bench.setActivityId("test");
    bench.setSessionStatus("OPEN")
    bench.setSubscores(subscoreList.asJava);

    producer.score(new BenchmarkScoringRequest(bench));

  }



}

