package io.hmheng.scoring.framework.adapters


import java.time.LocalDateTime

import com.fasterxml.jackson.databind.JsonMappingException
import io.hmheng.scoring.framework.TestUtils
import org.scalatest._

class AssignmentsAdapterTest extends FunSpec with ShouldMatchers  with GivenWhenThen {

  /*describe("Assignments Adapter") {
    it("accepts the service response and returns correct object ") {
      Given("the Assignments service response")
      val response = TestUtils.ASSIGNMENTS_RESPONSE

      When("the assignments data object is created")
      val assignmentAdapter = new AssignmentsAdapter
      val assignmentsData = assignmentAdapter.accept(response)

      Then("the assignments data object is successfully created with the correct data")
      assignmentsData.grade should be ("04")
      assignmentsData.testType should be ("B")
      assignmentsData.testLevel should be ("4")
      assignmentsData.normDate should be (LocalDateTime.of(2016, 3, 15, 10, 30))
      assignmentsData.startDate should be (LocalDateTime.of(2016, 2, 28, 23, 30))
      assignmentsData.finishDate should be (LocalDateTime.of(2016, 3, 30, 21, 59))
      assignmentsData.battery should be ("M")
    }
  }

  describe("Assignments Adapter") {
    it("assignments adapter throws JsonMappingException ") {
      Given("the Assignments service response is empty")
      val response = ""

      When("the assignments data object is created")
      val thrown = intercept[JsonMappingException] {
        new AssignmentsAdapter().accept(response)
      }

      Then("throws a JsonMappingException")
      assert(thrown.getMessage === "No content to map due to end-of-input\n at [Source: ; line: 1, column: 1]")
    }
  }

  ignore("Issue with Jenkins BR Connectivity") {
    describe("Assignments Adapter") {
      it("assignments adapter throws JsonMappingException when discipline is not present") {
        Given("the Assignments service response has no discipline")
        val response = TestUtils.ASSIGNMENTS_RESPONSE_NO_DISCIPLINE

        When("the assignments data object is created")
        val thrown = intercept[JsonMappingException] {
        new AssignmentsAdapter().accept(response)
      }

        Then("throws a JsonMappingException")
        assert(thrown.getMessage.contains("Discipline should always be present"))

      }
    }
  }

  ignore("Issue with Jenkins BR Connectivity") {
    describe("Assignments Adapter") {
      it("assignments adapter throws JsonMappingException when normDate is not present") {
        Given("the Assignments service response has no discipline")
        val response = TestUtils.ASSIGNMENTS_RESPONSE_NO_NORMDATE

        When("the assignments data object is created")
        val thrown = intercept[JsonMappingException] {
        new AssignmentsAdapter().accept(response)
      }

        Then("throws a JsonMappingException")
        assert(thrown.getMessage.contains("NormDate should always be present"))

      }
    }
  }
  ignore("Issue with Jenkins BR Connectivity") {
    describe("Assignments Adapter") {
      it("accepts the service response when orginal dates are present") {
        Given("the Assignments service response")
        val response = TestUtils.ASSIGNMENTS_RESPONSE_ORIGINAL_DATES

        When("the assignments data object is created")
        val assignmentAdapter = new AssignmentsAdapter
        val assignmentsData = assignmentAdapter.accept(response)

        Then("the assignments data object is successfully created with the correct data")
        assignmentsData.startDate should be(LocalDateTime.of(2016, 2, 28, 23, 30))
        assignmentsData.finishDate should be(LocalDateTime.of(2016, 3, 30, 21, 59))

      }
    }
  }*/
}
