package io.hmheng.scoring.framework.adapters


import com.fasterxml.jackson.core.JsonParseException
import io.hmheng.scoring.framework.TestUtils
import org.scalatest._


class LearnosityAdapterTest extends FunSpec with ShouldMatchers with GivenWhenThen {

  /*describe("Learnosity Adapter") {
    it("returns the correct benchmark Learnosity data object ") {

      Given("the Learnosity benchmark stream contains 1 entry for data")
      val learnosityInput = TestUtils.LEARNOSITY_BENCHMARK_MESSAGE

      When("the benchmark Learnosity data object is obtained")
      val learnosityData = new LearnosityAdapter().getBenchmarkLearnosityData(learnosityInput)

      Then("the benchmark Learnosity data object should be successfully created")
      learnosityData should not be null
    }
  }

  describe("Learnosity Adapter") {
    it("returns no data for activityLevel, activityGrade,activityDiscipline, normDate and eventType in benchmark Learnosity data object ") {

      Given("the Learnosity benchmark stream contains 1 entry for data")
      val learnosityInput = TestUtils.LEARNOSITY_BENCHMARK_MESSAGE

      When("the benchmark Learnosity data object is obtained")
      val learnosityData = new LearnosityAdapter().getBenchmarkLearnosityData(learnosityInput)

      Then("the activityLevel, activityGrade,activityDiscipline, normDate and eventType on the benchmark Learnosity data should not be set")
      learnosityData.activityDiscipline should be (null)
      learnosityData.activityLevel should be (null)
      learnosityData.activityGrade should be (null)
      learnosityData.eventType should be (null)
      learnosityData.normDate should be (null)

    }
  }

  describe("Learnosity Adapter") {
    it("returns a list of lookups that contains the right values ") {

      Given("the Learnosity benchmark stream contains 1 entry for data with 6 subscores of ids: M02, M03, M04, M05, M12, M13")
      val learnosityInput = TestUtils.LEARNOSITY_BENCHMARK_MESSAGE

      When("the benchmark Learnosity data object is obtained")
      val learnosityData = new LearnosityAdapter().getBenchmarkLearnosityData(learnosityInput)

      Then("the Learnosity data object will contain 6 subscores of ids: M02, M03, M04, M05, M12, M13 ")
      val listOfScores = learnosityData.subscores
      listOfScores.size should be (6)
      listOfScores.map(x=>x.id) should be (List("M02", "M03", "M04", "M05", "M12", "M13"))

    }
  }


  describe("Learnosity Adapter") {
    it("throws an IllegalArgumentException ") {

      Given("the Learnosity stream contains no data")
      val learnosityInput ="{\n  \"data\": [] \n}"

      When("the Learnosity data object is obtained")
      val thrown = intercept[IllegalArgumentException] {
        new LearnosityAdapter().validate(learnosityInput)
      }

      Then("throws an IllegalArgumentException for no activity_id ")
      assert(thrown.getMessage === "requirement failed: Learnosity stream should contain activity_id!")
    }
  }

  describe("Learnosity Adapter") {
    it("learnosity benchmark adapter throws a JsonParseException ") {

      Given("the Learnosity benchmark stream contains malformed Json")
      val learnosityInput ="{\"data\": { \"activity_id\": \"e52b035b-2136-4a2f-b086-b900ce59db31\",\"session_id\": \"44f61dcb-418b-4f0a-8776-718ddb5aa5bf\"}]}"

      When("the list of Learnosity data object is obtained")
      val thrown = intercept[JsonParseException] {
        new LearnosityAdapter().getBenchmarkLearnosityData(learnosityInput)
      }

      Then("throws an JsonParseException")
      assert(thrown.isInstanceOf[JsonParseException])
    }
  }

  describe("Learnosity Adapter") {
    it("returns the correct formative Learnosity data object") {

      Given("the Learnosity formative stream contains 1 entry for data")
      val learnosityInput = TestUtils.LEARNOSITY_FORMATIVE_MESSAGE

      When("the formative Learnosity data object is obtained")
      val learnosityDataFormative = new LearnosityAdapter().getFormativeLearnosityData(learnosityInput)

      Then("the formative Learnosity data object should be successfully created")
      learnosityDataFormative should not be null
      learnosityDataFormative.activityId should be ("57dbf0ae-ccd2-69b2-7097-b535f3a41823")
      learnosityDataFormative.sessionId should be ("4976795d-765c-430c-b18b-d8fab741b10b")
    }
  }

  describe("Learnosity Adapter") {
    it("returns no eventType in formative Learnosity data object ") {

      Given("the Learnosity formative stream contains 1 entry for data")
      val learnosityInput = TestUtils.LEARNOSITY_FORMATIVE_MESSAGE

      When("the formative Learnosity data object is obtained")
      val learnosityDataFormative = new LearnosityAdapter().getFormativeLearnosityData(learnosityInput)

      Then("the eventType on the formative Learnosity data should be null")
      learnosityDataFormative.eventType should be (null)
    }
  }

 ignore("Issue with connetivity in BR") {
    describe("Learnosity Adapter") {
      it("returns the right number of responses for items") {

        Given("the Learnosity formative stream contains 1 entry for data with 20 responses for the items")
        val learnosityInput = TestUtils.LEARNOSITY_FORMATIVE_MESSAGE

        When("the formative Learnosity data object is obtained")
        val learnosityDataFormative = new LearnosityAdapter().getFormativeLearnosityData(learnosityInput)

        Then("the formative Learnosity data object will contain 20 responses for items with the correct values")

        learnosityDataFormative.responses.size should be(20)
        learnosityDataFormative.responses.head.maxScore should be(1)
        learnosityDataFormative.responses.head.score should be(1)
        learnosityDataFormative.responses.head.itemReference should be("483871186")
        learnosityDataFormative.responses.last.maxScore should be(1)
        learnosityDataFormative.responses.last.score should be(1)
        learnosityDataFormative.responses.last.itemReference should be("484316863")
      }
    }
  }*/
}
