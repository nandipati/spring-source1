package io.hmheng.scoring.framework.adapters

import java.io.InputStream

import io.hmheng.scoring.framework.TestUtils
import org.scalatest.{BeforeAndAfter, FunSpec, GivenWhenThen, ShouldMatchers}


class LookupTablesAdapterTest extends FunSpec with ShouldMatchers with GivenWhenThen with BeforeAndAfter {

  var scoringResponseLookups:InputStream=null

 /* before {
    scoringResponseLookups = getClass.getResourceAsStream("/lookupTables.json")
  }


  ignore("Issue with Jenkins BR Connectivity") {
    describe("LookupTables Adapter") {
      it("returns the correct number of lookups ") {
        Given("the response from the scoring service has 6 lookups entries")
        val scoringServiceResponse = "{ \"lookups\": " + scala.io.Source.fromInputStream(scoringResponseLookups).getLines.mkString + "}"

        When("the list of lookups objects is obtained")
        val lookupTablesList = new LookupTablesAdapter().getLookupTables(scoringServiceResponse)

        Then("the number of lookup Objects created should be 6")
        lookupTablesList.size should be(6)
      }
    }
  }

  ignore("Issue with Jenkins BR Connectivity") {
    describe("LookupTables Adapter") {
      it("returns a list of lookups that contains the right values") {
        Given("the response from the scoring service has the first lookup entry with values discipline=M,level=11,slot=09")
        val scoringServiceResponse = "{ \"lookups\": " + scala.io.Source.fromInputStream(scoringResponseLookups).getLines.mkString + "}"

        When("the list of lookups objects is obtained")
        val lookupTablesList = new LookupTablesAdapter().getLookupTables(scoringServiceResponse)

        Then("first lookup Object created should have the values discipline=M,level=11,slot=09")
        lookupTablesList.head.discipline should be("M")
        lookupTablesList.head.level should be("11")
        lookupTablesList.head.slot should be("09")
      }
    }
  }

  ignore("Issue with Jenkins BR Connectivity") {
    describe("LookupTables Adapter") {
      it("returns an empty list of lookups ") {
        Given("the response from the scoring service is an empty result(nothing found in scoring)")
        val scoringServiceResponse = "{ \"lookups\": []}"

        When("the list of lookups objects is obtained")
        val lookupTablesList = new LookupTablesAdapter().getLookupTables(scoringServiceResponse)

        Then("list of lookup objects will be empty")
        lookupTablesList.isEmpty should be(true)
      }
    }
  }

  ignore("Issue with Jenkins BR Connectivity") {
    describe("LookupTables Adapter") {
      it("returns the correct loss and hoss ") {
        Given("the response from the scoring service contains loss=900 and hoss=999")
        val scoringServiceResponse = scala.io.Source.fromInputStream(TestUtils.scoringResponseLossAndHoss).getLines.mkString

        When("the internal object is created from the scoring response")
        val lossAndHossObject = new LookupTablesAdapter().getLossAndHoss(scoringServiceResponse)

        Then("The object will have have loss=900 and hoss=999")
        lossAndHossObject.loss should be(900)
        lossAndHossObject.hoss should be(999)
      }
    }
  }

  ignore("Issue with Jenkins BR Connectivity") {
    describe("LookupTables Adapter") {
      it("returns a null object of loss and hoss ") {
        Given("The response from the scoring service is an empty result(nothing found in scoring)")
        val scoringServiceResponse = "{}"

        When("The lossAndHoss object is obtained")
        val lossAndHossObject = new LookupTablesAdapter().getLossAndHoss(scoringServiceResponse)

        Then("The object will be null")
        lossAndHossObject should be(null)
      }
    }
  }
  after {
    scoringResponseLookups.close()
  }*/


}
