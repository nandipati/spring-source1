package io.hmheng.scoring.framework.benchmark.simulation

import java.io.{BufferedWriter, FileWriter}
import java.text.SimpleDateFormat
import java.time.ZonedDateTime
import java.util.Calendar

import au.com.bytecode.opencsv.CSVWriter
import io.hmheng.scoring.framework.benchmark.simulation.BenchmarkSimulationUtils._
import io.hmheng.scoring.framework.config.ServicesConfiguration
import io.hmheng.scoring.processors.DataProcessor
import io.hmheng.scoring.services.assignments._
import io.hmheng.scoring.services.security.SecurityUtils
import io.hmheng.scoring.utils.json.JsonObjectMapper
import io.hmheng.scoring.{BenchmarkBootstrapEngine, Logging}
import org.scalamock.scalatest.MockFactory
import org.scalatest.{FunSpec, _}


class BenchmarkSimulationTesting extends FunSpec with ShouldMatchers
  with GivenWhenThen with BeforeAndAfter with MockFactory with Logging with JsonObjectMapper {

  val sifAuthorization = SecurityUtils.getSIFAuthorization(ServicesConfiguration.scoringClientId,
    ServicesConfiguration.scoringClientSecret)
  val authorization = sifAuthorization.getAuthorization
  val authCurrentDateTime = sifAuthorization.getAuthCurrentDateTime

  /* ignore("dev SCORING API endpoints not accesible from Jenkins") {
    describe("Unit Testing Benchmark Simulation") {
      it("Simulation Data is processed correctly") {

        Given("A csv file with benchmark simulation data")

        val refId = "01fddb0b-7734-4658-a1a6-9cd9bbcfda13"
        val zonedDateTime: ZonedDateTime = ZonedDateTime.parse("2016-03-15T10:30:00.000Z")
        val normDate = zonedDateTime.toLocalDateTime

        val assignmentsServiceMock = mock[AssignmentsService]

        When("The data is processed by scoring engine")


        val formatter: SimpleDateFormat = new SimpleDateFormat("d-M-y")
        val dateSelected: String = formatter.format(Calendar.getInstance().getTime())
        val outputFileName: String = "simulationCompleteTestCases_" + dateSelected + ".csv"
        val out = new BufferedWriter(new FileWriter(outputFileName))
        val writer = new CSVWriter(out)
        writeCsvHeader(writer)
        val reader: List[BenchmarkSimulationData] = readCsvFile()
        reader.foreach(testCase => {

          val result = convertToBenchmarkLearnosityData(testCase)
          val activityId = result.activityId
          val sessionId = result.sessionId

          activityId shouldBe testCase.activityId
          sessionId shouldBe testCase.sessionId

          val item: Item = new Item(null, testCase.content, null, normDate, normDate, normDate, null, null, refId,
            null, getOrganisations(result.activityGrade, result.activityLevel))
          val assignmentsResponse = new AssignmentsResponse(List(item))
          (assignmentsServiceMock.getAssignmentDetailsBySessionId _).expects(result.sessionId, activityId)
            .returning(objectMapper.writeValueAsString(assignmentsResponse).replace("2016-03-15T10:30", "2016-03-15T10:30:00.000Z"))

          DataProcessor.assignmentsService = assignmentsServiceMock
          val data: String = DataProcessor.processBenchmark(result, testCase.toString)


          BenchmarkBootstrapEngine.main(Array(data.replace("\"", "@"),
            scoringHostBenchmarkSimulation,
            authorization, authCurrentDateTime))

          val scoringResponse: ScoringBenchmarkResponse =
            objectMapper.readValue(getBenchmarkScores(activityId, sessionId), classOf[ScoringBenchmarkResponse])

          Then("The scoring engine will correctly calculate the expected scores for activity: " + activityId + " and session: " + sessionId)
          //TODO: fix unit test to verify actual results
          //testScores(testCase, scoringResponse)
          writeCsvData(testCase, scoringResponse, writer)

        })
        writer.close()
      }
    }
  }
  */

  //TODO: implement comparison of expected results csv with actual
  /*
  def testScores(inputData: BenchmarkSimulationData, scoringResponse: ScoringBenchmarkResponse): Unit = {

    val subscores: List[BenchmarkScore] = scoringResponse.session.scores
    subscores.foreach(score => {
      score.slot match {
        case "01" => score.scaleScore shouldBe inputData.scaleScoreSlot01.toDouble
        case "02" => score.scaleScore shouldBe inputData.scaleScoreSlot02.toDouble
        case "03" => score.scaleScore shouldBe inputData.scaleScoreSlot03.toDouble
        case "04" => score.scaleScore shouldBe inputData.scaleScoreSlot04.toDouble
        case "05" => score.scaleScore shouldBe inputData.scaleScoreSlot05.toDouble
        case "06" => score.scaleScore shouldBe inputData.scaleScoreSlot06.toDouble
        case "07" => score.scaleScore shouldBe inputData.scaleScoreSlot07.toDouble
        case "08" => score.scaleScore shouldBe inputData.scaleScoreSlot08.toDouble
        case "09" => score.scaleScore shouldBe inputData.scaleScoreSlot09.toDouble
        case "10" => score.scaleScore shouldBe inputData.scaleScoreSlot10.toDouble
        case "11" => score.scaleScore shouldBe inputData.scaleScoreSlot11.toDouble
        case "12" => score.scaleScore shouldBe inputData.scaleScoreSlot12.toDouble
        case "13" => score.scaleScore shouldBe inputData.scaleScoreSlot13.toDouble
        case "14" => score.scaleScore shouldBe inputData.scaleScoreSlot14.toDouble
      }})

  }
  */

}
