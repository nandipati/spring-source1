package io.hmheng.scoring.framework.benchmark.simulation

import java.util.UUID

import au.com.bytecode.opencsv.CSVWriter
import io.hmheng.scoring.services.HttpRestClient
import io.hmheng.scoring.services.assignments.{Grade, Organisation}
import io.hmheng.scoring.services.learnosity.{AbilityEstimate, LearnosityDataBenchmark, Subscore}
import io.hmheng.scoring.utils.FormatsAndConfiguration._
import purecsv.safe.CSVReader

import scala.Array._


object BenchmarkSimulationUtils {

  val scoringHostBenchmarkSimulation = "http://spring-scoring01.dev.hmheng.io/v1/benchmark"
  //for running against local scoring api
  //val scoringHostBenchmarkSimulation = "http://localhost:8080/v1/benchmark"

  def convertToBenchmarkLearnosityData(csvDataRow: BenchmarkSimulationData): LearnosityDataBenchmark = {
    val grade = if (csvDataRow.grade == "0") "KG" else if (csvDataRow.grade.length == 1) "0" + csvDataRow.grade else csvDataRow.grade
    val result: LearnosityDataBenchmark = new LearnosityDataBenchmark(csvDataRow.activityId,
      grade, csvDataRow.level, null, null, null, null, null, null.asInstanceOf[Int], null.asInstanceOf[Int],
      csvDataRow.sessionId, "Completed", //we assume tests have been completed
      null,
      UUID.randomUUID().toString, //user_id it is randomly generated as it is not provided in the csv
      null, null,null,null)

    if (csvDataRow.content.equals("ELA")) {
      result.subscores = getElaSubscore(csvDataRow)
    }
    else {
      result.subscores = getMathSubscore(csvDataRow)
    }

    result
  }

  def createSubscore(abilityEstimate: Double, id: String): Subscore = {
    new Subscore(new AbilityEstimate(abilityEstimate, 0.4106), id, 0, 1,
      1, 1, null.asInstanceOf[Int], 0, id, 0, null,null) //numAttempted, numQuestions = 1, indicating completion criteria true
  }

  def getElaSubscore(data: BenchmarkSimulationData): List[Subscore] = {
    var subscoreList: List[Subscore] = List.empty

    if (!data.abilityELATotal.isEmpty) {
      //"08" is default slot for ELA total
      subscoreList = subscoreList ::: List(createSubscore(data.abilityELATotal.toDouble, "E08"))
    }

    if (!data.abilityElaD1.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityElaD1.toDouble, "E01"))
    }

    if (!data.abilityElaD2.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityElaD2.toDouble, "E02"))
    }

    if (!data.abilityElaD3.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityElaD3.toDouble, "E03"))
    }

    if (!data.abilityElaD4.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityElaD4.toDouble, "E04"))
    }

    if (!data.abilityElaD6.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityElaD6.toDouble, "E06"))
    }



    subscoreList
  }


  def getMathSubscore(data: BenchmarkSimulationData): List[Subscore] = {
    var subscoreList: List[Subscore] = List.empty

    if (!data.abilityMathTotal.isEmpty) {
      //"12" is default slot for Math total
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathTotal.toDouble, "M12"))
    }
    if (!data.abilityMathD1.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD1.toDouble, "M01"))
    }
    if (!data.abilityMathD2.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD2.toDouble, "M02"))
    }
    if (!data.abilityMathD3.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD3.toDouble, "M03"))
    }
    if (!data.abilityMathD4.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD4.toDouble, "M04"))
    }
    if (!data.abilityMathD5.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD5.toDouble, "M05"))
    }
    if (!data.abilityMathD6.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD6.toDouble, "M06"))
    }
    if (!data.abilityMathD7.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD7.toDouble, "M07"))
    }
    if (!data.abilityMathD8.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD8.toDouble, "M08"))
    }
    if (!data.abilityMathD9.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD9.toDouble, "M09"))
    }
    if (!data.abilityMathD10.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD10.toDouble, "M10"))
    }
    if (!data.abilityMathD11.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD11.toDouble, "M11"))
    }
    if (!data.abilityMathD13.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD13.toDouble, "M13"))
    }
    if (!data.abilityMathD14.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD14.toDouble, "M14"))
    }
    if (!data.abilityMathD15.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD15.toDouble, "M15"))
    }
    if (!data.abilityMathD16.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD16.toDouble, "M16"))
    }
    if (!data.abilityMathD17.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD17.toDouble, "M17"))
    }
    if (!data.abilityMathD18.isEmpty) {
      subscoreList = subscoreList ::: List(createSubscore(data.abilityMathD18.toDouble, "M18"))
    }

    subscoreList
  }

  def getBenchmarkScores(activityId: String, sessionId: String): String = {
    require(activityId != null)
    require(sessionId != null)

    val endpoint = scoringHostBenchmarkSimulation + "/activities/{ACTIVITY_ID}/sessions/{SESSION_ID}"
    val url = format(endpoint, Map("ACTIVITY_ID" -> activityId, "SESSION_ID" -> sessionId))
    HttpRestClient.getRestContentWithSecurity(url)
  }


  def readCsvFile(): List[BenchmarkSimulationData] = {

    val classLoader: ClassLoader = getClass.getClassLoader
    //val path = classLoader.getResource("ContinuumMockupData_06-17-16_24000.csv").getPath
    val path = classLoader.getResource("ContinuumMockupData_07-26-16.csv").getPath
    val reader = CSVReader[BenchmarkSimulationData].readCSVFromFileName(path, skipHeader = true)

    reader.map(tryObj => tryObj.get)
  }

  def getTestCaseArray(testCase: BenchmarkSimulationData) = {

    val testCaseArray = new Array[String](2)
    testCaseArray(0) = testCase.activityId
    testCaseArray(1) = testCase.sessionId
    testCaseArray
  }

  def getScoreUsingAbility(abilityListArray: Array[String], subscores: List[BenchmarkScore], i: Int) = {
    subscores.foreach(score => {
    })
  }

  def getScoringResponseArray(scoringResponse: ScoringBenchmarkResponse) = {

    val scoringResponseArray = new Array[String](9 * 14)
    val subscores: List[BenchmarkScore] = scoringResponse.session.scores
    val sortedScores = subscores.sortWith((x, y) => x.slot < y.slot)
    var i = 0

    for (j <- 1 to 14) {
      var slotScore: BenchmarkScore = null
      var slotString: String = String.valueOf(j)
      if (slotString.length == 1) {
        slotString = "0" + slotString
      }

      sortedScores.foreach(score => {
        if (score.slot.contains(slotString)) {
          slotScore = score
        }
      })
      if (slotScore == null) {
        scoringResponseArray(i) = ""
        scoringResponseArray(i + 1) = ""
        scoringResponseArray(i + 2) = ""
        scoringResponseArray(i + 3) = ""
        scoringResponseArray(i + 4) = ""
        scoringResponseArray(i + 5) = ""
        scoringResponseArray(i + 6) = ""
        scoringResponseArray(i + 7) = ""
        scoringResponseArray(i + 8) = ""
      } else {
        val roundedScaleScore = Math.round(slotScore.scaleScore)
        scoringResponseArray(i) = roundedScaleScore.toString
        scoringResponseArray(i + 1) = slotScore.achievementLevel
        scoringResponseArray(i + 2) = slotScore.lowerLimitPnpr.toString
        scoringResponseArray(i + 3) = slotScore.upperLimitPnpr.toString
        scoringResponseArray(i + 4) = slotScore.lowerLimitPss.toString
        scoringResponseArray(i + 5) = slotScore.upperLimitPss.toString
        scoringResponseArray(i + 6) = slotScore.lowerLimitLexile
        scoringResponseArray(i + 7) = slotScore.upperLimitLexile
        if(scoringResponseArray(i + 6)!=null && !scoringResponseArray(i + 6).contains("BR")){
          scoringResponseArray(i + 6) = scoringResponseArray(i + 6) + "L"
        }
        if(scoringResponseArray(i + 7)!=null && !scoringResponseArray(i + 7).contains("BR")){
          scoringResponseArray(i + 7) = scoringResponseArray(i + 7) + "L"
        }
        scoringResponseArray(i + 8) = slotScore.collegeReadiness
      }
      i += 9

    }

    scoringResponseArray
  }

  def writeCsvHeader(writer: CSVWriter) = {


    val classLoader: ClassLoader = getClass.getClassLoader
    val path = classLoader.getResource("Header_07-26-16.csv").getPath
    //val path = classLoader.getResource("Header_06-17-16.csv").getPath
    val headerReader = CSVReader[BenchmarkSimulationHeader].readCSVFromFileName(path, skipHeader = false)

    val inputDataHeader: List[BenchmarkSimulationHeader] = headerReader.map(tryObj => tryObj.get)
    val headerArray = new Array[String](inputDataHeader(0).getClass().getDeclaredFields().length)
    for (i <- 0 to inputDataHeader(0).getClass().getDeclaredFields().length - 1) {
      val classAttributeArray = inputDataHeader(0).getClass().getDeclaredField(inputDataHeader(0).getClass()
        .getDeclaredFields().apply
      (i).getName)
      classAttributeArray.setAccessible(true)
      val attributeNameArray = classAttributeArray.get(inputDataHeader(0)).toString
      headerArray.update(i, attributeNameArray)
    }

    val outputHeaderArray = new Array[String](9 * 14)
    var i = 0
    var j = 1

    for (j <- 1 to 14) {
      outputHeaderArray(i) = "scale_score_slot" + j
      outputHeaderArray(i + 1) = "achievment_level" + j
      outputHeaderArray(i + 2) = "lower_limit_pnpr" + j
      outputHeaderArray(i + 3) = "upper_limit_pnpr" + j
      outputHeaderArray(i + 4) = "lower_limit_pss" + j
      outputHeaderArray(i + 5) = "upper_limit_pss" + j
      outputHeaderArray(i + 6) = "lower_limit_lexile" + j
      outputHeaderArray(i + 7) = "upper_limit_lexile" + j
      outputHeaderArray(i + 8) = "college_readiness" + j
      i += 9
    }

    val totalHeaderArray = concat(headerArray, outputHeaderArray)
    writer.writeNext(totalHeaderArray)
  }

  def writeCsvData(inputData: BenchmarkSimulationData, scoringResponse: ScoringBenchmarkResponse, outCSVWriter:
  CSVWriter):
  Unit = {
    val inputDataArray = new Array[String](inputData.getClass().getDeclaredFields().length)
    for (i <- 0 to inputData.getClass().getDeclaredFields().length - 1) {
      val classAttributeArray = inputData.getClass().getDeclaredField(inputData.getClass().getDeclaredFields().apply
      (i).getName)
      classAttributeArray.setAccessible(true)
      val attributeNameArray = classAttributeArray.get(inputData).toString
      inputDataArray.update(i, attributeNameArray)
    }
    val scoringresponseArray = getScoringResponseArray(scoringResponse)
    var fullDataArray = concat(inputDataArray, scoringresponseArray)
    outCSVWriter.writeNext(fullDataArray)
  }

  def getOrganisations(gradeP: String, level: String): List[Organisation] = {
    val grade: Grade = new Grade(gradeP, level, null)
    val organisation = new Organisation(List(grade))

    List(organisation)
  }

}
