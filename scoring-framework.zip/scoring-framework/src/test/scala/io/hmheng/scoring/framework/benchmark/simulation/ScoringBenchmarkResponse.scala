package io.hmheng.scoring.framework.benchmark.simulation

import java.util.UUID

import io.hmheng.scoring.utils.json.JsonBaseConfiguration


case class ScoringBenchmarkResponse(activityId: UUID,
                                    grade: String,
                                    level: String,
                                    discipline: String,
                                    session: SessionBenchmark) extends JsonBaseConfiguration {}

case class SessionBenchmark(sessionId: UUID,
                            scores: List[BenchmarkScore]) extends JsonBaseConfiguration {}

case class BenchmarkScore(mapId: Int,
                          slot: String,
                          achievementLevel: String,
                          scaleScore: Double,
                          scoreType: String,
                          lowerLimitPss: Double,
                          upperLimitPss: Double,
                          lowerLimitPnpr: Double,
                          upperLimitPnpr: Double,
                          lowerLimitLexile: String,
                          upperLimitLexile: String,
                          collegeReadiness: String) extends JsonBaseConfiguration {}

