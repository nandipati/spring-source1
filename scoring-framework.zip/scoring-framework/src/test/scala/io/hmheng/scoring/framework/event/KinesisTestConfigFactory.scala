package io.hmheng.scoring.framework.event

import com.amazonaws.services.kinesis.producer.KinesisProducerConfiguration
import io.hmheng.scoring.framework.config.{AwsConfiguration, KinesisConfiguration}
import io.hmheng.scoring.framework.scheduler.aws.configuration.CredentialProvider


object KinesisTestConfigFactory {
  def createKinesisProducerConfiguration: KinesisProducerConfiguration = {
    val config: KinesisProducerConfiguration = new KinesisProducerConfiguration
    config.setCredentialsProvider(new CredentialProvider(AwsConfiguration.getARN))
    config.setRegion(KinesisConfiguration.getRegion)
    config
  }

}
