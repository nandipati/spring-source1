package io.hmheng.scoring.framework.event

import java.nio.ByteBuffer
import java.util.{List => JList}

import com.amazonaws.services.kinesis.AmazonKinesisClient
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessorCheckpointer
import com.amazonaws.services.kinesis.clientlibrary.types.ProcessRecordsInput
import com.amazonaws.services.kinesis.model.ShardIteratorType._
import com.amazonaws.services.kinesis.model.{GetRecordsRequest, GetRecordsResult, GetShardIteratorResult, Record}
import com.amazonaws.services.kinesis.producer.UserRecordResult
import com.google.common.util.concurrent.ListenableFuture
import io.hmheng.scoring.framework.TestUtils
import io.hmheng.scoring.framework.adapters.LearnosityAdapter
import io.hmheng.scoring.framework.config.KinesisConfiguration
import io.hmheng.scoring.framework.scheduler.aws.configuration.CredentialProvider
import org.scalamock.scalatest.MockFactory
import org.scalatest._


class WhenRecordsAreAddedToKinesisStream extends FunSpec with ShouldMatchers
  with GivenWhenThen with BeforeAndAfter with MockFactory {

  /*describe("KinesisStream") {
    it("can be read") {
      Given("A Kinesis producer")
      When("Attempting to put a message into the Kinesis stream")
      val addResult: ListenableFuture[UserRecordResult] = TestUtils.putBenchmarkMessage()
      val userRecordResult: UserRecordResult = addResult.get
      val seqNo: String = userRecordResult.getSequenceNumber

      Then("The operation will be successful")
      userRecordResult.isSuccessful should be (true)

      When("The Amazon Client is initialized")
      val shardId: String = userRecordResult.getShardId
      val client: AmazonKinesisClient =  new AmazonKinesisClient(new CredentialProvider)
      val getRecordsResult: GetRecordsResult = getARecord(client, shardId, seqNo)
      val records: JList[Record] = getRecordsResult.getRecords

      Then("The client gets the right number of records")
      records.size() should be (1)

      Then("The data received is the correct data put into the stream")
      val record: Record = records.get(0)
      val data: ByteBuffer = record.getData
      val actualMsg: String = extractStringFromByteBuffer(data)

      actualMsg should be (TestUtils.LEARNOSITY_BENCHMARK_MESSAGE)

    }
  }

  it("data is passed to the Learnosity Adapter") {

    Given("A Learnosity message in the Kinesis stream")
    val data = TestUtils.LEARNOSITY_BENCHMARK_MESSAGE
    val learnosityAdapter = stub[LearnosityAdapter]
    val factory = new RecordProcessorFactory(learnosityAdapter)
    val processor = factory.createProcessor()
    val checkPointer = stub[IRecordProcessorCheckpointer]
    val processRecordInput=new ProcessRecordsInput(){
      override def getRecords: java.util.List[Record] = {
        val records:java.util.List[Record] = new java.util.ArrayList[Record]()
        val record:Record = new Record(){
          setData(ByteBuffer.wrap(data.getBytes))
        }
        records.add(record)
        this.withCheckpointer(checkPointer)
        records
      }
    }

    When("The Records processor starts processing the records")
    processor.processRecords(processRecordInput)

    Then("The Learnosity Adapter is called to accept the data on each record")
    learnosityAdapter.accept _ verify data

    }
*/

  private def getARecord(client: AmazonKinesisClient, shardId: String, seqNo: String): GetRecordsResult = {
    val shardIteratorResult: GetShardIteratorResult =
      client.getShardIterator(KinesisConfiguration.getStreamName, shardId, AT_SEQUENCE_NUMBER.name, seqNo)
    val getRecordsRequest: GetRecordsRequest =
      new GetRecordsRequest().withLimit(1).withShardIterator(shardIteratorResult.getShardIterator)
    client.getRecords(getRecordsRequest)
  }


  private def extractStringFromByteBuffer(data: ByteBuffer): String = {
    new String(data.array).trim
  }

}
