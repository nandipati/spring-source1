package io.hmheng.scoring.services.scoringapi

import java.io.InputStream

import io.hmheng.scoring.utils.json.JsonObjectMapper
import org.scalatest._


class LookupTableTest extends FunSpec with ShouldMatchers with GivenWhenThen with BeforeAndAfter with JsonObjectMapper{

  var streamGood:InputStream=null

  before {
    streamGood = getClass.getResourceAsStream("/lookupTable.json")
  }

  describe("LookupTable") {
    it("can be created from Json") {
      Given("the response from the scoring service has only one lookup entry for slot 9")
      val scoringServiceResponse =scala.io.Source.fromInputStream(streamGood).getLines.mkString

      When("the LookupTable object is obtained")
      val lookupTable = objectMapper.readValue(scoringServiceResponse, classOf[LookupTable])

      Then("the slot on the created LookupTable object will be 9 ")
      lookupTable.slot should be ("09")
    }
  }

  after {
    streamGood.close()
  }

}
