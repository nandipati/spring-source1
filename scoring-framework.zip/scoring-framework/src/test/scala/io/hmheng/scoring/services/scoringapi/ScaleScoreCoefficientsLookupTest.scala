package io.hmheng.scoring.services.scoringapi

import org.scalatest._


class ScaleScoreCoefficientsLookupTest extends FunSpec with ShouldMatchers with GivenWhenThen {
  describe("ScaleScoreCoefficientsLookup") {
    it("throws an IllegalArgumentException when slot is smaller than 1") {

      Given("The ScaleScoreCoefficientsLookup with slot value -1")
      val thrown = intercept[IllegalArgumentException]{
        new ScaleScoreCoefficientsLookup(1, 1, 3, "semester", -1, 0.0, 0.0, 0.0)
      }
      Then("throws an IllegalArgumentException for slot not being between 1 and 28 ")
      assert(thrown.getMessage === "requirement failed: Slot must have a value between 1 and 28!")
    }
  }

  describe("ScaleScoreCoefficientsLookup") {
    it("throws an IllegalArgumentException when equationType is not  equal to 3") {

      Given("The ScaleScoreCoefficientsLookup with equationType value 1")
      val thrown = intercept[IllegalArgumentException]{
        new ScaleScoreCoefficientsLookup(1, 1, 1, "semester", 28, 0.0, 0.0, 0.0)
      }
      Then("throws an IllegalArgumentException for equation type not being equal with 3 ")
      assert(thrown.getMessage === "requirement failed: Equation Type must be equal with 3!")
    }
  }
}
