package io.hmheng.scoring.services.scoringapi

import org.scalatest._


class ScaledScoreLimitsLookupTest extends FunSpec with ShouldMatchers with GivenWhenThen {
  describe("ScaledScoreLimitsLookup") {
    it("throws an IllegalArgumentException when slot is greater than 28") {

      Given("The ScaledScoreLimitsLookup with slot value -1")
      val thrown = intercept[IllegalArgumentException]{
        new ScaledScoreLimitsLookup(1, 1, 29, "", null, null, null, null, null, null, null, null)
      }
      Then("throws an IllegalArgumentException for slot not being between 1 and 28 ")
      assert(thrown.getMessage === "requirement failed: Slot must have a value between 1 and 28!")
    }
  }

}
