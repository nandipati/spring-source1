package io.hmheng.scoring.services.scoringapi

import org.scalatest._


class ThetaCoefficientsLookupTest extends FunSpec with ShouldMatchers with GivenWhenThen {

  describe("ThetaCoefficientsLookup") {
    it("throws an IllegalArgumentException when slot is smaller than 1") {

      Given("The ThetaCoefficientsLookup with slot value -1")
      val thrown = intercept[IllegalArgumentException] {
        new ThetaCoefficientsLookup(1, 1, 3, "semester", -1, 0.0, 0.0)
      }
      Then("throws an IllegalArgumentException for slot not being between 1 and 28 ")
      assert(thrown.getMessage === "requirement failed: Slot must have a value between 1 and 28!")
    }
  }

  describe("ThetaCoefficientsLookup") {
    it("throws an IllegalArgumentException when equationType is not  equal to 3") {

      Given("The ThetaCoefficientsLookup with equationType value 4")
      val thrown = intercept[IllegalArgumentException] {
        new ThetaCoefficientsLookup(1, 1, 1, "semester", 28, 0.0, 0.0)
      }
      Then("throws an IllegalArgumentException for equation type not being equal with 3 ")
      assert(thrown.getMessage === "requirement failed: Equation Type must be equal with 3!")
    }
  }

  describe("ThetaCoefficientsLookup") {
    it("can add all the parametersat construct time", Tag("construction")) {

      Given("The values lookupId=1, version=1, equationType=3, Semester=semester, slot=28 and coefficients=0.0")
      val thetaCoefficientsLookup = new ThetaCoefficientsLookup(1, 1, 3, "semester", 28, 0.0, 0.0)

      Then("then the ThetaCoefficientsLookup.lookupId should be 1")
      thetaCoefficientsLookup.lookupId should be (1)

      And("the ThetaCoefficientsLookup.version should be 1")
      thetaCoefficientsLookup.version should be (1)

      And("the ThetaCoefficientsLookup.equationType should be 3")
      thetaCoefficientsLookup.equationType should be (3)

      And("the ThetaCoefficientsLookup.semester should be \"semester\"")
      thetaCoefficientsLookup.semester should be ("semester")

      And("the ThetaCoefficientsLookup.coefficients should be 0.0")
      thetaCoefficientsLookup.coefficientA should be (0.0)
      thetaCoefficientsLookup.coefficientB should be (0.0)

    }
  }
}
