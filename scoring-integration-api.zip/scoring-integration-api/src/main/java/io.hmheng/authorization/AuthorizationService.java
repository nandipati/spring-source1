package io.hmheng.authorization;

public interface AuthorizationService {

  enum Service {
     GRADING,
     SCORING,
     ON_SEARCH
  }
    
  AuthorizationDetails createSIFAuthorization(Service service);

}


