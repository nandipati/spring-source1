package io.hmheng.services.api;

import io.hmheng.services.api.domain.AssesmentResourceInfo;

/**
 * Created by nandipatim on 2/28/18.
 */
public interface ContentSourceService {

  AssesmentResourceInfo resourceItemToStandardMapping(String resourceId);
}
