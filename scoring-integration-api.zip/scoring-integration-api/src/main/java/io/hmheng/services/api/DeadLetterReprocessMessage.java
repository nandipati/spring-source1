package io.hmheng.services.api;

/*
 *  @author Lenko Donchev
 */

public class DeadLetterReprocessMessage {
  String restEndpointURL;

  public String getRestEndpointURL() {
    return restEndpointURL;
  }

  public void setRestEndpointURL(String restEndpointURL) {
    this.restEndpointURL = restEndpointURL;
  }

  public String getMessagePayloadJSON() {
    return messagePayloadJSON;
  }

  public void setMessagePayloadJSON(String messagePayloadJSON) {
    this.messagePayloadJSON = messagePayloadJSON;
  }

  String messagePayloadJSON;
}
