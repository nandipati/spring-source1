package io.hmheng.services.api;

import com.google.gson.Gson;

import io.hmheng.services.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds JSON payload for the reprocessing of the failed messages(Dead Letters).
 *
 * <p>New clients of the Scoring API should add their custom dead message re-processing logic here.
 *
 * @author Lenko Donchev
 */
@Component
public class DeadLetterReprocessMessageBuilder {

  @Value("${deadletter.reprocess.rescore.url}")
  private String deadLetterReprocessRescoreUrl;

  @Value("${deadletter.reprocess.retryStudentSession.url}")
  private String deadLetterReprocessRetryStudentSessionUrl;

  @Autowired private Gson gson;

  public DeadLetterReprocessMessage buildReprocessMessage(
      final ScoringService.ClientName clientName, final String reprocessDataJSON) {
    DeadLetterReprocessMessage deadLetterReprocessMessage = new DeadLetterReprocessMessage();

    switch (clientName) {
      case SCORING_SAVE_DOMAIN_AND_STANDARD_SCORES:
      case SCORING_SAVE_SESSION_STANDARD_SCORES:
        Map<String, Object> errorDataMap = gson.fromJson(reprocessDataJSON, Map.class);

        Map<String, List> sessionsToRescore = new HashMap<>();
        List<String> reprocessSessions = new ArrayList<>();
        reprocessSessions.add(errorDataMap.get(Constants.DEAD_LETTER_DATACONTENT_SESSION_ID).toString());
        sessionsToRescore.put("sessionIds", reprocessSessions);

        deadLetterReprocessMessage.setMessagePayloadJSON(gson.toJson(sessionsToRescore));
        deadLetterReprocessMessage.setRestEndpointURL(deadLetterReprocessRescoreUrl);
        break;
      case STUDENT_SESSION_REPROCESS:
        errorDataMap = gson.fromJson(reprocessDataJSON, Map.class);

        deadLetterReprocessMessage
            .setMessagePayloadJSON(errorDataMap.get(Constants.DEAD_LETTER_DATACONTENT_DATA).toString());
        deadLetterReprocessMessage.setRestEndpointURL(deadLetterReprocessRetryStudentSessionUrl);
        break;
      default:
        throw new IllegalArgumentException("Unexpected client name:" + clientName);
    }

    return deadLetterReprocessMessage;
  }
}
