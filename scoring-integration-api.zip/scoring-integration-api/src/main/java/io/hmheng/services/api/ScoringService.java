package io.hmheng.services.api;

import com.hmhco.api.scoring.view.request.SaveAssignmentSessionStandardScoresView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;

import feign.FeignException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Created by nandipatim on 3/1/18. */
public interface ScoringService {

  List<AssignmentItemToStandardMapView> getItemStandardMap(UUID activityId);

  SaveAssignmentSessionStandardScoresView saveStudentSessionStandardScores(
      UUID activityId,
      UUID sessionId,
      SaveAssignmentSessionStandardScoresView saveAssignmentSessionStandardScoresView);

  enum ClientName {
    GRADING("GRADING"),
    SCORING("SCORING"),
    SCORING_SAVE_EVENT("SCORING_SAVE_EVENT"),
    SCORING_SAVE_SESSION_STANDARD_SCORES("SCORING_SAVE_SESSION_STANDARD_SCORES"),
    SCORING_SAVE_DOMAIN_AND_STANDARD_SCORES("SCORING_SAVE_DOMAIN_AND_STANDARD_SCORES"),
    STUDENT_SESSION_REPROCESS("STUDENT_SESSION_REPROCESS");

    private String clientName;

    ClientName(String clientName) {
      this.clientName = clientName;
    }

    public String getValue() {
      return clientName;
    }

    static Map<String, ClientName> map = new HashMap<>();

    static {
      for (ClientName clientName : ClientName.values()) {
        map.put(clientName.clientName, clientName);
      }
    }

    public static ClientName getByCode(String code) {
      return map.get(code);
    }
  }

  enum FailureType {
    DATA_INTEGRITY("DATA_INTEGRITY"),
    PROCESS_LOOKUP("PROCESS_LOOKUP"),
    SAVE_SCORES_TO_DB("SAVE_SCORES_TO_DB"),
    SAVE_EVENT_TO_DB("SAVE_EVENT_TO_DB"),
    LOAD_SCORES_FROM_DB("LOAD_SCORES_FROM_DB"),
    POST_SCORES("POST_SCORES"),
    ST_SESSION_REPROCESS("ST_SESSION_REPROCESS");

    FailureType(String failureType) {
      this.failureType = failureType;
    }

    public String getValue() {
      return failureType;
    }

    private String failureType;
  }

  enum FailureEventType {
    PROGRAM("PROGRAM"),
    PERFORMANCE_TASK("PERFORMANCE_TASK"),
    UNKNOWN("UNKNOWN"),
    FORMATIVE("FORMATIVE"),
    BENCHMARK("BENCHMARK"),
    OPTIMISTIC_LOCK_EXCEPTION("OPTIMISTIC_LOCK_EXCEPTION"),
    CUSTOM("CUSTOM");

    FailureEventType(String failureEventType) {
      this.failureEventType = failureEventType;
    }

    public String getValue() {
      return failureEventType;
    }

    private String failureEventType;
  }

  interface OnSuccessCallback {
    void execute(UUID messageId, Long recordId);
  }

  void saveDeadLetterMessageAsync(
      String errorDetails,
      Exception exception,
      Map errorData,
      FailureType failureType,
      FailureEventType failureEventType,
      ClientName clientName,
      boolean logErrorLocally);

  void saveDeadLetterMessageAsync(
      UUID messageId,
      String errorDetails,
      Exception exception,
      Map errorData,
      FailureType failureType,
      FailureEventType failureEventType,
      ClientName clientName,
      boolean logErrorLocally,
      OnSuccessCallback onSuccessCallback);

  boolean shouldRetry(
      Integer currentRetryCount, Integer maxNumberOfRetries, FeignException feignException);
}
