package io.hmheng.services.api.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;
import lombok.Data;

import java.util.List;

/**
 * Created by nandipatim on 2/28/18.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssesmentResourceInfo {

  private String resourceId;
  private List<AssignmentItemToStandardMapView> itemToStandardMapping;
}
