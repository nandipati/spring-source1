package io.hmheng.services.onesearch;

import feign.Headers;
import feign.Param;
import feign.RequestLine;

import io.hmheng.services.onesearch.domain.OneSearchAssesmentResponse;

/**
 * Created by nandipatim on 2/28/18.
 */
interface OneSearchApi {

  @RequestLine("GET /v1/assessments/rubrics?assessmentId={resourceId}&view=standards")
  @Headers({ "Authorization: {authorization}", "Content-Type: application/json" })
  OneSearchAssesmentResponse getItemsToStandardForResource(@Param("resourceId") String resourceId ,
                                                           @Param("authorization") String authorization);
}
