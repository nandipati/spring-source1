package io.hmheng.services.onesearch;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;

import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemDetailsView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;
import io.hmheng.services.api.domain.AssesmentResourceInfo;
import io.hmheng.services.onesearch.domain.Assessment;
import io.hmheng.services.onesearch.domain.Standard;
import io.hmheng.services.onesearch.domain.StandardSet;
import io.hmheng.services.onesearch.domain.StandardSets;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Created by nandipatim on 2/28/18.
 */

@Component
@Slf4j
public class OneSearchResponseHelper {

  private static final String ITEM_NAME_PREFIX = "ITEM ";
  private static final UUID noStandardId = UUID.fromString("7f537d60-67fb-41ea-8651-4d75b57be9cf");
  private ObjectMapper objectMapper;

  public OneSearchResponseHelper() {
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JodaModule());
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  }

  public AssesmentResourceInfo transformItemToStandardForResource(String resourceId, List<Assessment> assessments) {

    AssesmentResourceInfo assesmentResourceInfo = new AssesmentResourceInfo();
    assesmentResourceInfo.setResourceId(resourceId);

    if (!CollectionUtils.isEmpty(assessments)) {
      List<AssignmentItemToStandardMapView> itemToStandardMapping = new ArrayList<>();
      assesmentResourceInfo.setItemToStandardMapping(itemToStandardMapping);
      assessments.forEach(assessment -> {
        final int[] itemPosition = {0};
        assessment.getItem().forEach(item -> {
          AssignmentItemToStandardMapView assignmentItemToStandardMapView = new AssignmentItemToStandardMapView();
          List<UUID> standards = new ArrayList<>();
          assignmentItemToStandardMapView.setStandards(standards);
          assignmentItemToStandardMapView.setItemRefId(item.getIdentifier());
          AssignmentItemDetailsView itemDetailsView = new AssignmentItemDetailsView();
          assignmentItemToStandardMapView.setItemDetails(itemDetailsView);
          itemDetailsView.setDepthOfKnowledge(item.getDepthOfKnowledge());
          String itemPositionString = item.getItemPosition();
          if (StringUtils.isEmpty(itemPositionString)) {
            itemPosition[0] = itemPosition[0] + 1;
            itemPositionString = String.valueOf(itemPosition[0]);
            item.setItemPosition(itemPositionString);
          } else {
            itemPosition[0] = NumberUtils.toInt(itemPositionString);
          }
          itemDetailsView.setItemPosition(itemPositionString);
          itemDetailsView.setManuallyScorable(item.getManuallyScorable());
          itemDetailsView.setItemName(ITEM_NAME_PREFIX + itemPositionString);
          Object standardSetsObject = item.getStandardSets();
          if ((standardSetsObject instanceof String && standardSetsObject.equals("")) || standardSetsObject == null) {
            log.info("Item -->{} is not associated with any Standard Set" , item.getIdentifier());
            standards.add(noStandardId);
          } else {
            StandardSets standardSets = objectMapper
                .convertValue(standardSetsObject, new TypeReference<StandardSets>() {});;
            List<StandardSet> standardSetList = standardSets.getStandardSet();
            if (!CollectionUtils.isEmpty(standardSetList)) {
              standardSetList.forEach(standardSet -> {
                List<Standard> standardList = standardSet.getStandard();
                if (!CollectionUtils.isEmpty(standardList)) {
                  standardList.forEach(standard -> {
                    standards.add(standard.getGuid());
                  });
                }
              });
            } else {
              standards.add(noStandardId);
            }
          }
          itemToStandardMapping.add(assignmentItemToStandardMapView);
        });
      });
    }
    return assesmentResourceInfo;
  }
}