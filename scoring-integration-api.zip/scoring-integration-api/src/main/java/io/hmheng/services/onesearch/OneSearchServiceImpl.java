package io.hmheng.services.onesearch;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import feign.Feign;
import feign.Logger;
import feign.jackson.JacksonDecoder;
import feign.jackson.JacksonEncoder;
import feign.slf4j.Slf4jLogger;

import io.hmheng.authorization.AuthorizationService;
import io.hmheng.services.api.ContentSourceService;
import io.hmheng.services.api.domain.AssesmentResourceInfo;
import io.hmheng.services.onesearch.domain.OneSearchAssesmentResponse;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


/**
 * Created by nandipatim on 2/28/18.
 */
@Service
@Slf4j
public class OneSearchServiceImpl implements ContentSourceService {

  @Autowired
  private AuthorizationService authorizationService;

  @Autowired
  private OneSearchResponseHelper oneSearchResponseHelper;

  private final OneSearchApi oneSearchApi;

  private final String oneSearchHost;

  @Value("${onesearch.noOfRetries}")
  private Integer noOfRetries;

  @Autowired
  public OneSearchServiceImpl(@Value("${onesearch.host.baseUrl}") String oneSearchHost, ObjectMapper objectMapper) {
    this.oneSearchHost = oneSearchHost;
    this.oneSearchApi = Feign.builder()
                        .encoder(new JacksonEncoder(objectMapper))
                        .decoder(new JacksonDecoder(objectMapper.copy()
                                .enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY,
                                        DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)))
                        .logger(new Slf4jLogger(OneSearchServiceImpl.class)).logLevel(Logger.Level.FULL)
                        .target(OneSearchApi.class , this.oneSearchHost);
  }

  public AssesmentResourceInfo resourceItemToStandardMapping(String resourceId) {
    String authorizationToken = authorizationService.createSIFAuthorization(AuthorizationService.Service.ON_SEARCH)
              .getSifAuthorization().getAuthorization();

    return getAssesmentResourceInfo(resourceId , authorizationToken , 1);
  }

  private AssesmentResourceInfo getAssesmentResourceInfo(String resourceId , String authorizationToken ,
      int retryCount) {

    OneSearchAssesmentResponse response = null;

    try {
      response = oneSearchApi.getItemsToStandardForResource(resourceId, authorizationToken);
    } catch (Exception ex) {
      if (retryCount < noOfRetries) {
        getAssesmentResourceInfo(resourceId, authorizationToken, retryCount + 1);
      } else {
        log.error("Failed pull from one search for resource -->" + resourceId , ex);
        throw new RuntimeException("Failed pull from one search for resource -->" + resourceId);
      }
    }

    return oneSearchResponseHelper.transformItemToStandardForResource(resourceId, response.getAssessment());
  }
}

