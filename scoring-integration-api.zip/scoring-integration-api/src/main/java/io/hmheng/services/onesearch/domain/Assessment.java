package io.hmheng.services.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@NoArgsConstructor
@JsonRootName("assessment")
public class Assessment {

  private List<Item> item;

}