package io.hmheng.services.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;


@Data
@NoArgsConstructor
@JsonRootName("item")
public class Item {
  @NotNull
  private String identifier;

  private String itemPosition;

  private Boolean manuallyScorable;

  private String depthOfKnowledge;

  private Object standardSets;

}