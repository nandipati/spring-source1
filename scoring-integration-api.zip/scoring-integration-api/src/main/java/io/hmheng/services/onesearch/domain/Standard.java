package io.hmheng.services.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Created by nandipatim on 2/27/18.
 */
@Data
@NoArgsConstructor
@JsonRootName("standard")
public class Standard {

  private String id;
  private UUID guid;
}
