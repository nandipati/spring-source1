package io.hmheng.services.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import javax.validation.constraints.NotNull;


@Data
@NoArgsConstructor
@JsonRootName("standardSet")
public class StandardSet {
  @NotNull
  private String name;

  private String region;

  private String  provider;

  List<Standard> standard;

}