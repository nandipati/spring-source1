package io.hmheng.services.onesearch.domain;

import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Created by nandipatim on 2/27/18.
 */
@Data
@NoArgsConstructor
@JsonRootName("standardSets")
public class StandardSets {

  private List<StandardSet> standardSet;
}
