package io.hmheng.services.scoring;

import com.hmhco.api.scoring.view.request.SaveAssignmentSessionStandardScoresView;
import com.hmhco.api.scoring.view.save.ScoresAssessmentDeadLetterView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;
import feign.Body;
import feign.Headers;
import feign.Param;
import feign.RequestLine;

import java.util.List;
import java.util.UUID;

/**
 * Created by nandipatim on 3/1/18.
 */
public interface ScoringApi {

  @RequestLine("GET /v2/formative/activities/{ACTIVITY_ID}/getItemStandardMap")
  @Headers({ "Authorization: {authorization}", "authCurrentDateTime: {authCurrentDateTime}" ,
          "Content-Type: application/json" })
  List<AssignmentItemToStandardMapView> getItemStandardMap(@Param("ACTIVITY_ID") UUID activityId ,
                                                           @Param("authorization") String authorization ,
                                                           @Param("authCurrentDateTime") String authCurrentDateTime);

  @RequestLine("POST /v2/formative/activities/{ACTIVITY_ID}/sessions/{SESSION_ID}/standardscores?"
      + "pushStandardScores=true")
  @Headers({ "Authorization: {authorization}", "authCurrentDateTime: {authCurrentDateTime}" ,
            "Content-Type: application/json" })
  SaveAssignmentSessionStandardScoresView saveStudentSessionStandardScores(
      SaveAssignmentSessionStandardScoresView saveAssignmentSessionStandardScoresView,
      @Param("ACTIVITY_ID") UUID activityId ,
      @Param("SESSION_ID") UUID sessionId , @Param("authorization") String authorization ,
      @Param("authCurrentDateTime") String authCurrentDateTime);


  @RequestLine("POST /v1/deadletter/saveFailedMessage")
  @Headers({ "Authorization: {authorization}", "authCurrentDateTime: {authCurrentDateTime}" ,
            "Content-Type: application/json" })
  ScoresAssessmentDeadLetterView saveFailedMessage(
      ScoresAssessmentDeadLetterView scoresAssessmentDeadLetterView,
      @Param("authorization") String authorization ,
      @Param("authCurrentDateTime") String authCurrentDateTime);
}
