package io.hmheng.services.scoring;

import com.google.gson.Gson;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hmhco.api.scoring.exception.NotFoundException;
import com.hmhco.api.scoring.view.enums.DeadLetterStatus;
import com.hmhco.api.scoring.view.request.SaveAssignmentSessionStandardScoresView;
import com.hmhco.api.scoring.view.save.ScoresAssessmentDeadLetterView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;
import feign.Feign;
import feign.FeignException;
import feign.Logger;
import feign.jackson.JacksonDecoder;
import feign.jackson.JacksonEncoder;
import feign.slf4j.Slf4jLogger;
import io.hmheng.authorization.AuthorizationDetails;
import io.hmheng.authorization.AuthorizationService;
import io.hmheng.services.api.ScoringService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/** Created by nandipatim on 3/1/18. */
@Slf4j
@Service
public class ScoringServiceImpl implements ScoringService {

  @Autowired private AuthorizationService authorizationService;

  @Autowired private Gson gson;

  private final ScoringApi scoringApi;

  private final String oneScoringHost;

  @Value("${scoring.noOfRetries}")
  private Integer noOfRetries;

  @Value("${deadletter.retryIntervalInMinutes}")
  private Integer retryIntervalInMinutes;

  @Autowired private ThreadPoolTaskExecutor deadLetterThreadPoolTaskExecutor;

  @Bean
  private ThreadPoolTaskExecutor getDeadLetterThreadPoolTaskExecutor(
      @Value("${deadletter.threadPoolTaskExecutorMaxPoolSize}")
          Integer deadLetterThreadPoolTaskExecutorMaxPoolSize,
      @Value("${deadletter.threadPoolTaskExecutorQueueCapacity}")
          Integer deadLetterThreadPoolTaskExecutorQueueCapacity) {

    ThreadPoolTaskExecutor deadLetterThreadPoolTaskExecutor = new ThreadPoolTaskExecutor();
    deadLetterThreadPoolTaskExecutor.setMaxPoolSize(deadLetterThreadPoolTaskExecutorMaxPoolSize);
    deadLetterThreadPoolTaskExecutor.setQueueCapacity(
        deadLetterThreadPoolTaskExecutorQueueCapacity);
    deadLetterThreadPoolTaskExecutor.setThreadNamePrefix("dead-letter");
    deadLetterThreadPoolTaskExecutor.initialize();

    return deadLetterThreadPoolTaskExecutor;
  }

  @Autowired
  public ScoringServiceImpl(
      @Value("${scoring.host.baseUrl}") String oneScoringHost, ObjectMapper objectMapper) {
    this.oneScoringHost = oneScoringHost;
    this.scoringApi =
        Feign.builder()
            .encoder(new JacksonEncoder(objectMapper))
            .decoder(
                new JacksonDecoder(
                    objectMapper
                        .copy()
                        .enable(
                            DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY,
                            DeserializationFeature.UNWRAP_SINGLE_VALUE_ARRAYS)))
            .logger(new Slf4jLogger(ScoringServiceImpl.class))
            .logLevel(Logger.Level.FULL)
            .target(ScoringApi.class, this.oneScoringHost);
  }

  public List<AssignmentItemToStandardMapView> getItemStandardMap(UUID activityId) {

    AuthorizationDetails authorizationDetails =
        authorizationService.createSIFAuthorization(AuthorizationService.Service.SCORING);

    String authorization = authorizationDetails.getSifAuthorization().getAuthorization();
    String authCurrentDateTime = authorizationDetails.getAuthCurrentDateTime();

    return getItemStandardMap(activityId, authorization, authCurrentDateTime, 1);
  }

  private List<AssignmentItemToStandardMapView> getItemStandardMap(
      UUID activityId, String authorization, String authCurrentDateTime, int retryCount) {

    List<AssignmentItemToStandardMapView> assignmentItemToStandardMapViews = null;
    try {
      assignmentItemToStandardMapViews =
          scoringApi.getItemStandardMap(activityId, authorization, authCurrentDateTime);
    } catch (NotFoundException nfe) {
      return null;
    } catch (Exception ex) {
      if (retryCount < noOfRetries) {
        getItemStandardMap(activityId, authorization, authCurrentDateTime, retryCount + 1);
      }
    }
    return assignmentItemToStandardMapViews;
  }

  public SaveAssignmentSessionStandardScoresView saveStudentSessionStandardScores(
      UUID activityId,
      UUID sessionId,
      SaveAssignmentSessionStandardScoresView saveAssignmentSessionStandardScoresView) {

    AuthorizationDetails authorizationDetails =
        authorizationService.createSIFAuthorization(AuthorizationService.Service.SCORING);

    String authorization = authorizationDetails.getSifAuthorization().getAuthorization();
    String authCurrentDateTime = authorizationDetails.getAuthCurrentDateTime();

    return saveStudentSessionStandardScores(
        activityId,
        sessionId,
        saveAssignmentSessionStandardScoresView,
        authorization,
        authCurrentDateTime,
        1);
  }

  private SaveAssignmentSessionStandardScoresView saveStudentSessionStandardScores(
      UUID activityId,
      UUID sessionId,
      SaveAssignmentSessionStandardScoresView saveAssignmentSessionStandardScoresView,
      String authorization,
      String authCurrentDateTime,
      int retryCount) {

    SaveAssignmentSessionStandardScoresView assignmentSessionStandardScoresView = null;

    try {
      assignmentSessionStandardScoresView =
          scoringApi.saveStudentSessionStandardScores(
              saveAssignmentSessionStandardScoresView,
              activityId,
              sessionId,
              authorization,
              authCurrentDateTime);
    } catch (FeignException ex) {
      if (shouldRetry(retryCount, noOfRetries, ex)) {
        saveStudentSessionStandardScores(
            activityId,
            sessionId,
            saveAssignmentSessionStandardScoresView,
            authorization,
            authCurrentDateTime,
            retryCount + 1);
      }
    }

    return assignmentSessionStandardScoresView;
  }

  public boolean shouldRetry(
      Integer currentRetryCount, Integer maxNumberOfRetries, FeignException feignException) {

    HttpStatus httpStatus = HttpStatus.valueOf(feignException.status());

    if (currentRetryCount < maxNumberOfRetries
        && httpStatus.is5xxServerError()
        && !httpStatus.equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
      return true;
    } else {
      return false;
    }
  }

  public void saveDeadLetterMessageAsync(
      String errorDetails,
      Exception exception,
      Map errorData,
      FailureType failureType,
      FailureEventType failureEventType,
      ClientName clientName,
      boolean logErrorLocally) {

    if (failureEventType == null) {
      failureEventType = FailureEventType.UNKNOWN;
    }

    saveDeadLetterMessageAsync(
        UUID.randomUUID(),
        errorDetails,
        exception,
        errorData,
        failureType,
        failureEventType,
        clientName,
        logErrorLocally,
        (messageId, deadLetterRecordId) -> {
          log.info(
              "sucessfully saved dead letter message context in the DB for messageId: {}, DB record Id: {}",
              messageId,
              deadLetterRecordId);
        });
  }

  public void saveDeadLetterMessageAsync(
      UUID messageId,
      String errorDetails,
      Exception exception,
      Map errorData,
      FailureType failureType,
      FailureEventType failureEventType,
      ClientName clientName,
      boolean logErrorLocally,
      OnSuccessCallback onSuccessCallback) {

    if (messageId == null) {
      throw new IllegalArgumentException(
          "Please provide a message id. You can generate a random one if not available.");
    }

    CompletableFuture.supplyAsync(
        () -> {
            if (logErrorLocally) {
              log.error(errorDetails, exception);
            }

            ScoresAssessmentDeadLetterView scoresAssessmentDeadLetter = null;
            AuthorizationDetails authorizationDetails =
                authorizationService.createSIFAuthorization(AuthorizationService.Service.SCORING);

            String authorization = authorizationDetails.getSifAuthorization().getAuthorization();
            String authCurrentDateTime = authorizationDetails.getAuthCurrentDateTime();

            scoresAssessmentDeadLetter = new ScoresAssessmentDeadLetterView();

            scoresAssessmentDeadLetter.setMessageId(messageId);

            scoresAssessmentDeadLetter.setFailureType(failureType.getValue());
            scoresAssessmentDeadLetter.setFailureEventType(failureEventType.getValue());
            scoresAssessmentDeadLetter.setErrorDetails(errorDetails);
            if (exception != null) {
              scoresAssessmentDeadLetter.setException(
                  String.format(
                      "ExceptionMessage: %s, FullStackTrace: %s , RootCauseMessage: %s",
                      ExceptionUtils.getMessage(exception),
                      ExceptionUtils.getFullStackTrace(exception),
                      ExceptionUtils.getRootCauseMessage(exception)));
            }
            scoresAssessmentDeadLetter.setData(gson.toJson(errorData));
            scoresAssessmentDeadLetter.setStatus(DeadLetterStatus.NONE.getDeadLetterStatus());
            scoresAssessmentDeadLetter.setFailureDate(LocalDateTime.now());
            scoresAssessmentDeadLetter.setClientName(clientName.getValue());

            boolean hasError = true;
            ScoresAssessmentDeadLetterView scoresAssessmentDeadLetterView = null;
            Integer failCount = 0;
            while (hasError) {
              try {
                scoresAssessmentDeadLetterView =
                    scoringApi.saveFailedMessage(
                        scoresAssessmentDeadLetter, authorization, authCurrentDateTime);
                hasError = false;
                onSuccessCallback.execute(
                    messageId, scoresAssessmentDeadLetterView.getScoresAssessmentDeadletterId());
              } catch (RuntimeException ex) {
                ++failCount;
                if (failCount == 1) {
                  log.error(
                      "Failed to submit dead letter message. Error: {}. ScoresAssessmentDeadLetter: {}",
                      ex,
                      scoresAssessmentDeadLetter);
                }

                try {
                  Thread.currentThread().sleep(retryIntervalInMinutes * 60 * 1000);
                } catch (InterruptedException e) {
                  log.info(
                      "Got interrupt request:{}. Stacktrace:{}",
                      e,
                      ExceptionUtils.getFullStackTrace(e));
                }
              }
            }

            return null;
        },
        deadLetterThreadPoolTaskExecutor)
        .exceptionally(
            ex -> {
              log.error(
                  "Failed to process save dead letter message request for messageId: {}"
                        + ",  error: {}, errorData: {}, Stacktrace:{}",
                  messageId,
                  ex,
                  errorData,
                  ExceptionUtils.getFullStackTrace(ex));
              return null;
            });
  }
}
