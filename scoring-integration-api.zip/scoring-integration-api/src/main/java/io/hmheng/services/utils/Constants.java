package io.hmheng.services.utils;

public interface Constants {
  public static String DEAD_LETTER_DATACONTENT_SESSION_ID = "SESSION_ID";
  public static String DEAD_LETTER_DATACONTENT_DATA = "DATA";
  public static String DEAD_LETTER_DATACONTENT_REPROCESSING_URL = "REPROCESSING_URL";
}
