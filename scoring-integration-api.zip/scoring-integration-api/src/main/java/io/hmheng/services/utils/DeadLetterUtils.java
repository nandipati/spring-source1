package io.hmheng.services.utils;

import io.hmheng.services.api.ScoringService;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/*
 *  @author Lenko Donchev
 */

public class DeadLetterUtils {

  public static Map buildErrorDataObject(UUID sessionId) {
    Map<String, Object> errorData = new HashMap();

    if (sessionId != null) {
      errorData.put(Constants.DEAD_LETTER_DATACONTENT_SESSION_ID, sessionId.toString());
    }

    return errorData;
  }

  public static Map buildErrorDataObject(String dataStr) {
    Map<String, Object> errorData = new HashMap();

    errorData.put(Constants.DEAD_LETTER_DATACONTENT_DATA, dataStr);

    return errorData;
  }
}
