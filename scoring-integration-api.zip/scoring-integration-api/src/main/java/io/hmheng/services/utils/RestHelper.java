package io.hmheng.services.utils;

import io.hmheng.authorization.AuthorizationService;
import io.hmheng.authorization.util.HeadersHelper;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/*
 *  @author Lenko Donchev
 */

@Component
public class RestHelper {

  @Autowired private RestTemplate restTemplate;

  @Autowired private HeadersHelper headersHelper;

  @Bean
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }

  public ResponseEntity<String> postEntity(String serviceUrl, Object object) {
    HttpHeaders httpHeaders = headersHelper.createHttpHeaders(AuthorizationService.Service.SCORING);
    if (httpHeaders == null) {
      throw new RuntimeException("Unable to create authorisation headers.");
    }
    return postEntity(serviceUrl, object, httpHeaders);
  }

  public ResponseEntity<String> postEntity(
      String serviceUrl, Object domainObject, HttpHeaders httpHeaders) {
    HttpEntity<Object> httpEntity = new HttpEntity<>(domainObject, httpHeaders);

    ResponseEntity<String> response =
        restTemplate.postForEntity(serviceUrl, httpEntity, String.class);

    if (!response.getStatusCode().is2xxSuccessful()) {
      throw new RuntimeException(
          String.format(
              "Unable to process for url %s , server returned %d ",
              serviceUrl, response.getStatusCode()));
    }

    return response;
  }
}
