package com.hmhco.api.scoring.exception;

/**
 * Created by suryadevarap on 12/7/15.
 */
public class UnsupportedMediaTypeException extends RuntimeException {

}
