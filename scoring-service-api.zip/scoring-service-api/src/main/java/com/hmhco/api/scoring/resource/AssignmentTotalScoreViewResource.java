package com.hmhco.api.scoring.resource;

import com.hmhco.api.scoring.view.save.AssignmentTotalScoreView;
import org.springframework.hateoas.Resource;

/**
 * Created by mfeng on 11/15/17.
 */
public class AssignmentTotalScoreViewResource extends Resource<AssignmentTotalScoreView> {
  public AssignmentTotalScoreViewResource(AssignmentTotalScoreView content) {
    super(content);
  }
}
