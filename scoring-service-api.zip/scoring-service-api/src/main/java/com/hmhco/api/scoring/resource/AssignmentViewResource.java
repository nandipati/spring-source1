package com.hmhco.api.scoring.resource;

import com.hmhco.api.scoring.view.retrive.EventDetailView;
import com.hmhco.api.scoring.view.retrive.RetriveAssignmentListDetailStandardScoresView;

import org.springframework.hateoas.Resource;

/**
 * Created by mfeng on 7/19/18.
 */
public class AssignmentViewResource extends Resource<EventDetailView> {
  public AssignmentViewResource(EventDetailView content) {
    super(content);
  }
}
