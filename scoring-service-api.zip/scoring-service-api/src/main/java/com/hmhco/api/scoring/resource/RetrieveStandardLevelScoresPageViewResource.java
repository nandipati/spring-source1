package com.hmhco.api.scoring.resource;

import com.hmhco.api.scoring.view.retrive.RetrieveStandardLevelScoresPageView;

import org.springframework.hateoas.Resource;

/**
 * Created by mfeng on 5/3/18.
 */
public class RetrieveStandardLevelScoresPageViewResource extends Resource<RetrieveStandardLevelScoresPageView> {
  public RetrieveStandardLevelScoresPageViewResource(RetrieveStandardLevelScoresPageView content) {
    super(content);
  }
}
