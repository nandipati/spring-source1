package com.hmhco.api.scoring.resource;

import com.hmhco.api.scoring.view.retrive.RetriveAssignmentListDetailStandardScoresView;

import org.springframework.hateoas.Resource;

/**
 * Created by mfeng on 7/31/18.
 */
public class RetriveAssignmentListDetailStandardScoresViewResource
    extends Resource<RetriveAssignmentListDetailStandardScoresView> {
  public RetriveAssignmentListDetailStandardScoresViewResource(RetriveAssignmentListDetailStandardScoresView content) {
    super(content);
  }
}
