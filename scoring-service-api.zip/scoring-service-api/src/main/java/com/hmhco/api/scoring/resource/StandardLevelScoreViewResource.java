package com.hmhco.api.scoring.resource;

import com.hmhco.api.scoring.view.retrive.StandardLevelScoreView;

import org.springframework.hateoas.Resource;

/**
 * Created by mfeng on 5/3/18.
 */
public class StandardLevelScoreViewResource extends Resource<StandardLevelScoreView> {
  public StandardLevelScoreViewResource(StandardLevelScoreView content) {
    super(content);
  }
}
