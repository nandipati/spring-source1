package com.hmhco.api.scoring.utils;

import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by suryadevarap on 2/3/16.
 */
public enum AchievementLevel {

  ONE("1"),
  TWO("2"),
  THREE("3"),
  FOUR("4");

  private final String achievementLevel;

  private static Map<String, AchievementLevel> levelBySymbol;

  private AchievementLevel(String achievementLevel) {

    this.achievementLevel = achievementLevel;
    register(this);
  }

  private void register(AchievementLevel achievementLevel) {
    if (levelBySymbol == null) {
      levelBySymbol = new HashMap<>();
    }
    levelBySymbol.put(achievementLevel.achievementLevel, achievementLevel);
  }

  public static AchievementLevel getForSymbol(String symbol) {
    return levelBySymbol.get(symbol);
  }

  @JsonValue
  public String getName() {
    return achievementLevel;
  }
}
