package com.hmhco.api.scoring.utils;

public interface AttributeHelper {

  String clearContextMethodName = "clearContext";
  void clearContext();
}
