package com.hmhco.api.scoring.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import org.springframework.stereotype.Component;

@Component
public class AttributeHelperImpl implements AttributeHelper {

  @Override
  public void clearContext() {
    MDC.clear();
  }

}
