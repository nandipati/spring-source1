package com.hmhco.api.scoring.utils;

/**
 * Created by suryadevarap on 2/3/16.
 */
public enum Discipline {
  E, M
}
