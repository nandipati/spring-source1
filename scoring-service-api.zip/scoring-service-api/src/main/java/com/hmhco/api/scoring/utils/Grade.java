package com.hmhco.api.scoring.utils;

import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by suryadevarap on 2/3/16.
 */
public enum Grade {

  KINDERGARTEN("KG"),
  KINDERGARTEN_K("K"),
  GRADE_01("01"),
  GRADE_2("02"),
  GRADE_3("03"),
  GRADE_4("04"),
  GRADE_5("05"),
  GRADE_6("06"),
  GRADE_7("07"),
  GRADE_8("08"),
  GRADE_9("09"),
  GRADE_10("10"),
  GRADE_11("11"),
  GRADE_12("12");

  private final String symbol;
  private static Map<String, Grade> gradesBySymbol;

  Grade(String symbol) {

    this.symbol = symbol;
    register(this);
  }

  private void register(Grade grade) {
    if (gradesBySymbol == null) {
      gradesBySymbol = new HashMap<>();
    }
    gradesBySymbol.put(grade.symbol, grade);
  }

  public static Grade getForSymbol(String symbol) {
    //        "K" is obsolete, still used in some services
    if ("K".equals(symbol)) {
      symbol = "KG";
    }
    return gradesBySymbol.get(symbol);
  }

  @JsonValue
  public String getSymbol() {
    return symbol;
  }
}
