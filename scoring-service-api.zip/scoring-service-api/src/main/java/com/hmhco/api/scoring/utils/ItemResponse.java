package com.hmhco.api.scoring.utils;

/**
 * Created by suryadevarap on 1/29/16.
 */
public enum ItemResponse {

  CORRECT,
  INCORRECT,
  NOT_ANSWERED,
  PARTIAL_CREDIT,
  NOT_SCORED

}
