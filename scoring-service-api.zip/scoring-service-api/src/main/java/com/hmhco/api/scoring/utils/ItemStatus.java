package com.hmhco.api.scoring.utils;

/**
 * Created by tallurir on 8/30/17.
 */
public enum ItemStatus {
        NOT_STARTED,
        IN_PROGRESS,
        COMPLETED;

}
