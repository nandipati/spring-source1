package com.hmhco.api.scoring.utils;

import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by suryadevarap on 2/3/16.
 */
public enum Level {

  LEVEL_0("0"),
  LEVEL_1("1"),
  LEVEL_2("2"),
  LEVEL_3("3"),
  LEVEL_4("4"),
  LEVEL_5("5"),
  LEVEL_6("6"),
  LEVEL_7("7"),
  LEVEL_8("8"),
  LEVEL_9("9"),
  LEVEL_10("10"),
  LEVEL_11("11"),
  LEVEL_12("12"),
  KINDERGARTEN("KG"),
  KINDERGARTEN_K("K");

  private final String symbol;
  private static Map<String, Level> levelBySymbol;

  Level(String symbol) {

    this.symbol = symbol;
    register(this);
  }

  private void register(Level level) {
    if (levelBySymbol == null) {
      levelBySymbol = new HashMap<>();
    }
    levelBySymbol.put(level.symbol, level);
  }

  public static Level getForSymbol(String symbol) {
    //        "K" is obsolete, still used in some services
    if ("K".equals(symbol)) {
      symbol = "KG";
    }
    return levelBySymbol.get(symbol);
  }

  @JsonValue
  public String getSymbol() {
    return symbol;
  }

}
