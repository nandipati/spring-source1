package com.hmhco.api.scoring.utils;

import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by suryadevarap on 3/3/16.
 */
public enum Order {
  ZERO("0"),
  ONE("1"),
  TWO("2"),
  THREE("3"),
  FOUR("4"),
  FIVE("5");

  private final String order;

  private static Map<String, Order> orderBySymbol;

  private Order(String order) {

    this.order = order;
    register(this);
  }

  private void register(Order order) {
    if (orderBySymbol == null) {
      orderBySymbol = new HashMap<>();
    }
    orderBySymbol.put(order.order, order);
  }

  public static Order getForSymbol(String symbol) {
    return orderBySymbol.get(symbol);
  }

  @JsonValue
  public String getName() {
    return order;
  }
}
