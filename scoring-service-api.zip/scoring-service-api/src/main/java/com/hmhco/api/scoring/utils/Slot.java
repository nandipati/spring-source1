package com.hmhco.api.scoring.utils;

import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by suryadevarap on 2/24/16.
 */
public enum Slot {

  ONE("01"),
  TWO("02"),
  THREE("03"),
  FOUR("04"),
  FIVE("05"),
  SIX("06"),
  SEVEN("07"),
  EIGHT("08"),
  NINE("09"),
  TEN("10"),
  ELVEN("11"),
  TWELVE("12"),
  THIRTEEN("13"),
  FOURTEEN("14");

  private final String slot;

  private static Map<String, Slot> slotBySymbol;

  private Slot(String slot) {

    this.slot = slot;
    register(this);
  }

  private void register(Slot slot) {
    if (slotBySymbol == null) {
      slotBySymbol = new HashMap<>();
    }
    slotBySymbol.put(slot.slot, slot);
  }

  public static Slot getForSymbol(String symbol) {
    return slotBySymbol.get(symbol);
  }

  @JsonValue
  public String getName() {
    return slot;
  }
}
