package com.hmhco.api.scoring.utils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;
import java.math.BigDecimal;

/**
 * Created by fodori on 4/3/17.
 */
// TODO: remove once Learnosity sends correct integers for max_score in the adaptive message
public class StringToIntegerDeserializer extends JsonDeserializer<Integer> {
  public Integer deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
      throws IOException, JsonProcessingException {
    String valueStr = jsonParser.getValueAsString("");
    Integer ret = null;
    if (!valueStr.equals("")) {
      ret = new BigDecimal(valueStr).intValue();
    }
    return ret;
  }
}
