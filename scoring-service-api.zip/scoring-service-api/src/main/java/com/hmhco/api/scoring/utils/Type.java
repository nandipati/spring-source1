package com.hmhco.api.scoring.utils;

/**
 * Created by suryadevarap on 2/24/16.
 */
public enum Type {
  T, S, D;

  public static Boolean isTypeT(String type) {
    if (T.name().equals(type)) {
      return Boolean.TRUE;
    }
    return Boolean.FALSE;
  }
}
