package com.hmhco.api.scoring.view;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.hateoas.ResourceSupport;

/** Created by suryadevarap on 2/1/16. */
public abstract class AbstractView {
  // this is a base class used for entityMapper
  @JsonIgnore private String version;

  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  @JsonIgnore private Integer numberOfDecimalToRoundOff;

  public Integer getNumberOfDecimalToRoundOff() {
    return numberOfDecimalToRoundOff;
  }

  public void setNumberOfDecimalToRoundOff(Integer numberOfDecimalToRoundOff) {
    this.numberOfDecimalToRoundOff = numberOfDecimalToRoundOff;
  }
}
