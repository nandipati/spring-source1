package com.hmhco.api.scoring.view;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;

import org.springframework.hateoas.core.Relation;

@Data
@JsonRootName("lookups")
@Relation(value = "lookup", collectionRelation = "lookups")
public class LookupsView {

  private Integer mapId;
  private String discipline;
  private String level;
  private String slot;
  private int version;
  @JsonIgnore
  private int order;
  @JsonIgnore
  private String name;
  @JsonIgnore
  private String abbr;
  @JsonIgnore
  private String col;
  private String type;

  private ScaledScoreLimitsLookupView scaledScoreLimitsLookup;
  private ScaleScoreCoefficientsLookupView scaleScoreCoefficientsLookup;
  private ThetaCoefficientsLookupView thetaCoefficientsLookup;
  private PredictedStandardScoreCoefficientsLookupView pssCoeficientsLookup;

}
