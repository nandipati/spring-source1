package com.hmhco.api.scoring.view;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.utils.Grade;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.hateoas.core.Relation;

import javax.validation.constraints.NotNull;

@Data
@JsonRootName("lossAndHoss")
@Relation(value = "lossAndHoss", collectionRelation = "lossAndHoss")
public class LossAndHossLookupView extends AbstractView {

  @NotNull
  private Integer lookupId;
  @NotBlank
  private String battery;
  @NotNull
  private Grade grade;
  @NotNull
  private int loss;
  @NotNull
  private int hoss;
}
