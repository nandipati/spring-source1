package com.hmhco.api.scoring.view;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.utils.Grade;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.hateoas.core.Relation;

import javax.validation.constraints.NotNull;

/**
 * Created by nandipatim on 6/29/16.
 */
@Data
@JsonRootName("pnpr")
@Relation(value = "npr", collectionRelation = "nprs")
public class NationalPercentileRankLookupView extends AbstractView {
  @NotNull
  private Long lookupId;
  @NotBlank
  private String conversionType;
  private String normBase;
  @NotBlank
  private String quarterMonth;
  @NotNull
  private int normYear;
  @NotBlank
  private Grade grade;
  @NotNull
  private int standardScore;
  @NotNull
  private String slot;
  @NotNull
  private int nprValue;

}
