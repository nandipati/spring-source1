package com.hmhco.api.scoring.view;

import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;

import org.springframework.hateoas.core.Relation;

@Data
@JsonRootName("pssLookups")
@Relation(value = "psslookup", collectionRelation = "psslookups")
public class PredictedStandardScoreCoefficientsLookupView extends AbstractView {

  private Integer lookupId;
  private String testType;
  private String battery;
  private int equationType;
  private int testLevel;
  private String semester;
  private int normYear;
  private int slot;
  private double coefficientA;
  private double coefficientB;
  private double coefficientC;

}
