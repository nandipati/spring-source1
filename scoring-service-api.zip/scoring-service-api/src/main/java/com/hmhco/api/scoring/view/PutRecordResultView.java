package com.hmhco.api.scoring.view;

import java.util.UUID;

public class PutRecordResultView {

  private String sequenceNumber;

  private String shardId;

  public UUID getMessageId() {
    return messageId;
  }

  public void setMessageId(UUID messageId) {
    this.messageId = messageId;
  }

  private UUID messageId;

  public String getSequenceNumber() {
    return sequenceNumber;
  }

  public void setSequenceNumber(String sequenceNumber) {
    this.sequenceNumber = sequenceNumber;
  }

  public String getShardId() {
    return shardId;
  }

  public void setShardId(String shardId) {
    this.shardId = shardId;
  }
}
