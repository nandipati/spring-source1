package com.hmhco.api.scoring.view;

import lombok.Data;

@Data
public class ScaleScoreCoefficientsLookupView {

  private Integer lookupId;

  private int version;

  private String testType;

  private String battery;

  private int equationType;

  private int testLevel;

  private String semester;

  private int normYear;

  private int slot;

  private double coefficientA;

  private double coefficientB;

  private double coefficientC;

}
