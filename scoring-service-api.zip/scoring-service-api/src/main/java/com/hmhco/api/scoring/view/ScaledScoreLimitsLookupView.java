package com.hmhco.api.scoring.view;

import lombok.Data;

@Data
public class ScaledScoreLimitsLookupView {

  private Integer lookupId;

  private int version;

  private String testType;

  private String battery;

  private int slot;

  private String bins;

  private String skillsetCode;

  private int normYear;

  private int testLevel;

  private String input;

  private String bin1Lo;

  private String bin1Hi;

  private String bin2Lo;

  private String bin2Hi;

  private String bin3Lo;

  private String bin3Hi;

  private String bin4Lo;

  private String bin4Hi;

}