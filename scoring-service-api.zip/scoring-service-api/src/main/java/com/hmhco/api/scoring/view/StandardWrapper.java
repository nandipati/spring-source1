package com.hmhco.api.scoring.view;

import lombok.Data;

import java.util.List;
import java.util.UUID;

@Data
public class StandardWrapper {

  private List<UUID> standardIds;

}