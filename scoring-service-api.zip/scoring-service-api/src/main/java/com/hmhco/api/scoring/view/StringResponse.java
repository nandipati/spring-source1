package com.hmhco.api.scoring.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by fodori on 3/15/17.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StringResponse {

  private String response;

}
