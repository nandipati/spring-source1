package com.hmhco.api.scoring.view.config;

import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

public enum Functionalities {
  DOMAIN_SORTING_BY_ATTRIBUTES(SupportedVersion.V2),
  DOMAIN_STUDENT_SORTING_BY_PROFICIENCY_SCORE(SupportedVersion.V2),
  GET_STANDARD_SCORE_APPLICATION_JSON(SupportedVersion.V1),
  GET_ASSIGNMENT_LIST_BY_STANDARD_SCORE_APPLICATION_JSON(SupportedVersion.V1);

  private final List<SupportedVersion> supportedVersions;

  Functionalities(SupportedVersion... supportedVersions) {
    this.supportedVersions = Arrays.asList(supportedVersions);
  }

  public boolean isSupported(Integer version) {
    if (version == null) {
      return false;
    }

    SupportedVersion supportedVersion = SupportedVersion.fromStringSafe(version.toString());

    if (supportedVersion == null) {
      return false;
    }

    return !CollectionUtils.isEmpty(supportedVersions)
        ? supportedVersions.contains(supportedVersion)
        : false;
  }
}
