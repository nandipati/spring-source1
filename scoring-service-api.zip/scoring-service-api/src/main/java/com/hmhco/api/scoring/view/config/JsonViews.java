package com.hmhco.api.scoring.view.config;

public class JsonViews {

  public interface V1 {}

  public interface V2 extends V1 {}

  public interface V3 extends V2 {}
}
