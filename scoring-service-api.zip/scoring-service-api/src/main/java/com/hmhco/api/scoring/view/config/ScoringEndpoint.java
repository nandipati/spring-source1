package com.hmhco.api.scoring.view.config;

import java.util.Arrays;
import java.util.List;

/** Created by nandipatim on 9/30/15. */
public enum ScoringEndpoint {
  STUDENT_GET_ASSIGNMENT_PROFICIENCY_FOR_SESSION("false",SupportedVersion.V1, SupportedVersion.V2),
  STUDENT_GET_ASSIGNMENT_PROFICIENCY("false",SupportedVersion.V1, SupportedVersion.V2),

  FORMATIVE_SAVE_STUDENT("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_GET_STUDENTS("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_GET_STUDENT("true" ,SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_GET_STUDENT_SCORES("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_GET_ACTIVITY_SCORES_RESCORE("true", SupportedVersion.V1, SupportedVersion.V2),

  FORMATIVE_GET_STANDARD_ITEM_MAP("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_SAVE_STANDARD_ITEM_MAP("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_SAVE_STUDENT_SESSION_STANDARD_SCORES("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_GET_STANDARD_LEVEL_SCORES("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_GET_DOMAIN_LEVEL_SCORES("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_REAGGREGATE_DOMAIN_LEVEL_SCORES("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_GET_STANDARD_LEVEL_SCORES_JSON("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_GET_STANDARD_LEVEL_SCORES_HALJSON("true", SupportedVersion.V2),
  FORMATIVE_GET_STANDARD_LEVEL_SCORES_DETAIL("true", SupportedVersion.V1, SupportedVersion.V2),
  FORMATIVE_GET_ASSIGNMENT_LIST_BY_STANDARD_SCORE("true", SupportedVersion.V1, SupportedVersion.V2),

  FORMATIVE_REPROCESS_STUDENT_SESSION("true", SupportedVersion.V1, SupportedVersion.V2);

  private final List<SupportedVersion> supportedVersions;
  private String isScoringFunction = "false";

  ScoringEndpoint(SupportedVersion... supportedVersions) {
    this.supportedVersions = Arrays.asList(supportedVersions);
  }

  ScoringEndpoint(String isScoringFunction , SupportedVersion... supportedVersions) {
    this.supportedVersions = Arrays.asList(supportedVersions);
    this.isScoringFunction = isScoringFunction;
  }

  public List<SupportedVersion> getSupportedVersions() {
    return supportedVersions;
  }

  public String getScoringFunction() {
    return isScoringFunction;
  }


}
