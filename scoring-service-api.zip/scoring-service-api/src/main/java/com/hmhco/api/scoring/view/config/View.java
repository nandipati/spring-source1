package com.hmhco.api.scoring.view.config;

/**
 * Created by jayachandranj on 2/20/18.
 */
public class View {

  public static class OveralView {
  }

  public static class DetailView extends OveralView {
  }

}
