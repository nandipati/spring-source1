package com.hmhco.api.scoring.view.enums;

/**
 * Created by nandipatim on 8/2/16.
 */
public enum CollegeReadiness {
  ON_TRACK,
  NOT_ON_TRACK;
}
