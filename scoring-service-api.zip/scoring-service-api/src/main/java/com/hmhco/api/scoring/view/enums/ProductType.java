package com.hmhco.api.scoring.view.enums;

/**
 * Created by tallurir on 12/18/17.
 */
public enum ProductType {

  HMH1(Boolean.FALSE),
  ED(Boolean.TRUE);

  private final Boolean calculateStandardScores;

  ProductType(Boolean calculateStandardScores) {
    this.calculateStandardScores = calculateStandardScores;
  }

  public Boolean isCalculateStandardScores() {
    return calculateStandardScores;
  }
}
