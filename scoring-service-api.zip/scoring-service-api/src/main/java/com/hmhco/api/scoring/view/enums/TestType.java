package com.hmhco.api.scoring.view.enums;

/**
 * Created by nandipatim on 4/4/17.
 */
public enum TestType {

  FORMATIVE(ProductType.HMH1),
  BENCHMARK(ProductType.HMH1),
  PROGRAM(ProductType.ED),
  PERFORMANCE_TASK(ProductType.ED),
  CUSTOM(ProductType.ED);

  private final ProductType eventType;

  TestType(ProductType productType) {
    this.eventType = productType;
  }


  public ProductType getProductType() {
    return this.eventType;
  }
}
