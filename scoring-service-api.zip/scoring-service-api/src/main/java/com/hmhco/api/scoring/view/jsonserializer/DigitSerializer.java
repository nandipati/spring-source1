package com.hmhco.api.scoring.view.jsonserializer;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.utils.CalculationUtils;

import java.io.IOException;

public class DigitSerializer extends StdSerializer<Double> {

  public DigitSerializer() {
    super(Double.class);
  }

  @Override
  public void serialize(Double value, JsonGenerator jgen, SerializerProvider provider)
      throws IOException, JsonGenerationException {

    AbstractView view = (AbstractView) jgen.getCurrentValue();

    jgen.writeNumber(CalculationUtils.roundValue(value, view.getNumberOfDecimalToRoundOff()));
  }
}
