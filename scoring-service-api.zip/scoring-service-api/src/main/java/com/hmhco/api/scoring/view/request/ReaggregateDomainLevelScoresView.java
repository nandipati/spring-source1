package com.hmhco.api.scoring.view.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.AbstractView;
import lombok.Data;

import java.util.List;
import java.util.UUID;


@Data
public class ReaggregateDomainLevelScoresView extends AbstractView {

  @JsonProperty("programId")
  private String programId;

  @JsonProperty("sectionRefid")
  private UUID sectionRefid;

  @JsonProperty("studentRefId")
  private String studentRefId;
}
