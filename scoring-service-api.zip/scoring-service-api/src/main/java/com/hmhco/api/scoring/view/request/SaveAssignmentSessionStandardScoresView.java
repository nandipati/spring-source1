package com.hmhco.api.scoring.view.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.enums.TestType;
import com.hmhco.api.scoring.view.retrive.StandardScoreView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;

import lombok.Data;

import java.util.List;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;


/**
 * Created by nandipatim on 3/1/18.
 */

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SaveAssignmentSessionStandardScoresView extends AbstractView {

  @Null
  private UUID activityId;

  @Null
  private UUID sessionId;

  @Valid
  @NotNull
  private String resourceId;

  @Valid
  @NotNull
  private TestType testType;

  private List<StandardScoreView> standardScores;

  private List<AssignmentItemToStandardMapView> itemToStandardMapping;
}
