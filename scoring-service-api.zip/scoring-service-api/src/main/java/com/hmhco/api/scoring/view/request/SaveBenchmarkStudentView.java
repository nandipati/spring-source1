package com.hmhco.api.scoring.view.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.save.BenchmarkActivityView;
import com.hmhco.api.scoring.view.save.BenchmarkSessionView;
import com.hmhco.api.scoring.view.save.itemlevel.BenchmarkItemResponseView;
import com.hmhco.api.scoring.view.save.itemlevel.BenchmarkItemView;

import lombok.Data;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * Created by suryadevarap on 2/1/16.
 */
@Data
public class SaveBenchmarkStudentView extends AbstractView {

  @Valid
  @NotNull
  @JsonProperty("session")
  private BenchmarkSessionView benchmarkSessionView;

  @Valid
  @NotNull
  @JsonProperty("activity")
  private BenchmarkActivityView benchmarkActivityView;

  @Valid
  @JsonProperty("items")
  private List<BenchmarkItemView> benchmarkItems;

  @Valid
  @JsonProperty("itemResponses")
  private List<BenchmarkItemResponseView> benchmarkItemResponses;

  private Long startTimeInEngine;

}
