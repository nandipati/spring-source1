package com.hmhco.api.scoring.view.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.save.FormativeActivityView;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * Created by suryadevarap on 2/10/16.
 */
@Data
public class SaveFormativeStudentView extends AbstractView {

  @Valid
  @NotNull
  @JsonProperty("activity")
  private FormativeActivityView formativeActivityView;

}
