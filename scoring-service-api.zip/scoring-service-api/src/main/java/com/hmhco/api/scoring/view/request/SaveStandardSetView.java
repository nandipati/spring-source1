package com.hmhco.api.scoring.view.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.AbstractView;
import lombok.Data;

/**
 * Created by jayachandranj on 2/6/18.
 */
@Data
public class SaveStandardSetView extends AbstractView {

  @JsonProperty("standardSetId")
  private String standardSetId;

  @JsonProperty("data")
  private String data;

}
