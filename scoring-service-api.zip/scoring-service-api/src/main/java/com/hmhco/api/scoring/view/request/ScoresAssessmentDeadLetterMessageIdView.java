package com.hmhco.api.scoring.view.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

/**
 * Created by pabonaj on 5/11/17.
 */
public class ScoresAssessmentDeadLetterMessageIdView {

  @JsonProperty("message_id")
  private List<String> message;

  public List<String> getMessageIdList() {
    return message;
  }

  public void setMessageIdList(List<String> sessionList) {
    this.message = message;
  }

}
