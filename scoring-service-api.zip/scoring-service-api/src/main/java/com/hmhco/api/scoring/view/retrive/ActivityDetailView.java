package com.hmhco.api.scoring.view.retrive;

import com.hmhco.api.scoring.view.AbstractView;
import lombok.Data;

import java.util.List;
import java.util.UUID;

/**
 * Created by mfeng on 7/18/2018.
 */
@Data
public class ActivityDetailView extends AbstractView {

  private UUID activityId;

  List<SessionDetailView> sessions;

}
