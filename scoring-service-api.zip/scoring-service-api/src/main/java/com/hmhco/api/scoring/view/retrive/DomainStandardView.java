package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.config.View;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

/**
 * Created by jayachandranj on 2/19/18.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DomainStandardView extends AbstractView implements Serializable {

  private UUID domainId;

  private String standardSetId;

  @JsonView(View.DetailView.class)
  private String name;

  @JsonView(View.DetailView.class)
  private String description;

  @JsonProperty("standards")
  private List<StandardView> standardViews;

  @Override
  public String toString() {
    return "DomainStandardView{"
            + "domainId=" + domainId
            + ", name='" + name + '\''
            + ", description='" + description + '\''
            + ", standardViews=" + standardViews
            + '}';
  }
}
