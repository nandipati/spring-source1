package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonView;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.config.View;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.UUID;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "domainId", "students", "performanceLevels" })
public class DomainStudentView extends AbstractView implements Serializable {

  private UUID domainId;

  private String standardSetId;

  @JsonView(View.DetailView.class)
  private String name;

  @JsonView(View.DetailView.class)
  private String description;

  @JsonProperty("students")
  private List<StudentView> studentViews;

  @JsonProperty("performanceLevels")
  private List<StudentsPerformanceView> studentsPerformanceLevels;

  @Override
  public String toString() {
    return "DomainStudentView{"
            + "domainId=" + domainId
            + ", standardSetId='" + standardSetId + '\''
            + ", name='" + name + '\''
            + ", description='" + description + '\''
            + ", studentViews=" + studentViews
            + '}';
  }

}
