package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Created by mfeng on 7/18/2018.
 */
@Data
public class EventDetailView extends AbstractView {

  private UUID eventRefId;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime dueDate;

  List<ActivityDetailView> activities;

}
