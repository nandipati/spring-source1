package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by mfeng on 10/19/17.
 */
@Data
public class EventSessionView extends AbstractView {

  private UUID sessionId;
  private UUID activityId;
  private String eventType;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime availableDate;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime dueDate;
  private boolean manualScoringRequired;
  private String resourceId;
  private UUID staffPersonalRefId;
  private String studentPersonRefId;
  private String status;
}
