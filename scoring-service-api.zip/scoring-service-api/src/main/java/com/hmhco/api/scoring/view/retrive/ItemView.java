package com.hmhco.api.scoring.view.retrive;

import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import java.util.UUID;


/**
 * Created by mfeng on 7/18/2018.
 */
@Data
public class ItemView extends AbstractView {
  private UUID activityId;
  private UUID sessionId;
  private String itemRef;
  private String name;
  private String position;
  private Boolean manuallyScorable;
  private Integer score;
  private Integer maxScore;
  private String response;
}
