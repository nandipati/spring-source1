package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import org.springframework.data.domain.Page;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by suryadevarap on 2/18/16.
 */
@Data
@JsonRootName("activity")
public class RetrieveBenchmarkActivityView extends AbstractView {

  private UUID activityId;
  private String grade;
  private String level;
  private LocalDateTime normDate;
  private String discipline;
  private String eventType;
  private String status;
  private LocalDateTime createdDate;
  private LocalDateTime updatedDate;

  @JsonProperty("sessions")
  private Page<RetrieveBenchmarkSessionView> benchmarkSessionViewList;

}
