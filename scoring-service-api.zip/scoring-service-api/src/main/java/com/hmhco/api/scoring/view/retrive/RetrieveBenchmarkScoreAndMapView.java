package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.enums.CollegeReadiness;

import lombok.Data;

import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by suryadevarap on 2/1/16.
 */
@Data
@JsonRootName("scores")
@Relation(value = "scores", collectionRelation = "scores")
public class RetrieveBenchmarkScoreAndMapView extends AbstractView {

  private UUID sessionId;
  private Long mapId;
  private String slot;
  private Integer order;
  private String name;
  private String abbr;
  @JsonProperty("scoreType")
  private String type;
  private Double abilityEstimate;
  private Double standardError;
  private String achievementLevel;
  private Integer numberAttempted;
  private Integer numberQuestions;
  private Integer maxScore;
  private Integer score;
  private Double scaleScore;
  private Double lpr;
  private Double ipFloor;
  private Double ipCeil;
  private Double lowerLimitPss;
  private Double upperLimitPss;
  private Double lowerLimitPnpr;
  private Double upperLimitPnpr;
  private String lowerLimitLexile;
  private String upperLimitLexile;
  private CollegeReadiness collegeReadiness;
  private Double completionCriteriaPercentage;
  private boolean completionCriteria;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime createdDate;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime updatedDate;
}
