package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Created by suryadevarap on 2/1/16.
 */
@Data
@JsonRootName("session")
@Relation(value = "session", collectionRelation = "sessions")
public class RetrieveBenchmarkSessionView extends AbstractView {

  private UUID sessionId;
  private UUID activityId;
  private String studentPersonRefId;
  private String status;
  private boolean skippedQuestions;
  private Boolean itemsOmitted;
  private Boolean completionCriteriaNotMet;
  private Boolean inCompleteTestRecord;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime createdDate;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime updatedDate;

  @JsonProperty("scores")
  private List<RetrieveBenchmarkScoreAndMapView> scoreAndMapViewEntityList;

}
