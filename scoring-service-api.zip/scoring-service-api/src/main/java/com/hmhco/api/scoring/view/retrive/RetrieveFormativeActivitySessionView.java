package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Created by suryadevarap on 2/18/16.
 */
@Data
@JsonRootName("activity")
public class RetrieveFormativeActivitySessionView extends AbstractView {

  private UUID activityId;
  private String eventType;
  private String status;

  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime createdDate;

  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime updatedDate;
  private String resourceId;
  private boolean manualScoringRequired;
  private boolean isAllowProvisionalScores;

  @JsonProperty("session")
  private RetrieveFormativeSessionView retrieveFormativeSessionView;

}
