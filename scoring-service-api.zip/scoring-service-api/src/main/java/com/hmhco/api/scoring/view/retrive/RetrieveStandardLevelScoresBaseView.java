package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import java.util.UUID;

/**
 * Created by mfeng on 4/25/18.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RetrieveStandardLevelScoresBaseView extends AbstractView {

  private UUID domainId;
  private String domainName;
  private String domainDescription;
  private String programId;
  private String studentRefId;
  private String standardsetId;
  private Integer schoolyear;

}
