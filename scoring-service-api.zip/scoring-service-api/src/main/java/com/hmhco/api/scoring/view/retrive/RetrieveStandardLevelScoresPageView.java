package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hmhco.api.scoring.resource.StandardLevelScoreViewResource;

import lombok.Data;

import org.springframework.hateoas.PagedResources;

/**
 * Created by mfeng on 4/25/18.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RetrieveStandardLevelScoresPageView extends RetrieveStandardLevelScoresBaseView {

  private PagedResources<StandardLevelScoreViewResource> standards;

  @Override
  public String toString() {
    return "RetrieveStandardLevelScoresListView{" + "domainId=" + this.getDomainId() + ", programId=" + this
        .getStandards() + ", " + "studentRefId='" + this.getStudentRefId() + '\'' + ", standardsetId='" + this
        .getStandardsetId() + '\'' + ", schoolyear=" + this.getSchoolyear() + ", standards=" + standards + '}';
  }
}
