package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;
import lombok.Data;

import java.util.List;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * Created by jayachandranj on 2/28/18.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RetrieveStandardScoresView<T extends StandardScoreView> extends AbstractView{

  protected UUID studentPersonId;

  @Valid @NotNull protected UUID sessionId;

  @Valid @NotNull protected UUID activityId;
  protected String testType;

  @Valid @NotNull protected String resourceId;

  @JsonProperty(value = "standards")
  protected List<T> standardScores;

  private List<AssignmentItemToStandardMapView> itemToStandardMapping;

  @JsonProperty(value = "domains")
  private List<StandardView> standardViews;

  public RetrieveStandardScoresView(UUID studentPersonId, UUID sessionId, UUID activityId, String testType,
                                    String resourceId, List<AssignmentItemToStandardMapView> itemToStandardMapping,
                                    List<StandardView> standardViews) {
    this.studentPersonId = studentPersonId;
    this.sessionId = sessionId;
    this.activityId = activityId;
    this.testType = testType;
    this.resourceId = resourceId;
    this.itemToStandardMapping = itemToStandardMapping;
    this.standardViews = standardViews;
  }

  public RetrieveStandardScoresView() {
  }
}
