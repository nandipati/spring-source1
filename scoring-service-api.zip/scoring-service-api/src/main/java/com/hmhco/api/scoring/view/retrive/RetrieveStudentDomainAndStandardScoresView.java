package com.hmhco.api.scoring.view.retrive;

/**
 * Created by jayachandranj on 3/28/18.
 */
public class RetrieveStudentDomainAndStandardScoresView {
}
