package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.AbstractView;
import lombok.Data;

import java.util.List;
import java.util.UUID;


@Data

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RetrieveStudentDomainLevelScoresResponse extends AbstractView {

  @JsonProperty("standardSetId")
  private String standardSetId;

  @JsonProperty("programId")
  private String programId;

  @JsonProperty("sectionRefid")
  private UUID sectionRefid;

  @JsonProperty("domains")
  private List<DomainStudentView> domainStudentViews;

}
