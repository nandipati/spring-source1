package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hmhco.api.scoring.resource.AssignmentViewResource;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import org.springframework.hateoas.PagedResources;

import java.util.UUID;

/**
 * Created by mfeng on 7/18/18.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RetriveAssignmentListDetailStandardScoresView extends AbstractView {

  private UUID standardId;
  private String standardName;
  private String description;
  private String standardSetId;
  private String studentPersonRefId;
  private UUID sectionId;
  private String programId;
  private Integer schoolyear;

  PagedResources<AssignmentViewResource> events;

  @Override
  public String toString() {
    return "RetriveAssignmentListDetailStandardScoresView{" + "standardId=" + standardId + "standardSetId="
        + standardSetId + "studentPersonRefId=" + studentPersonRefId + "sectionId=" + sectionId + "programId="
        + programId + "schoolyear=" + schoolyear;
  }
}
