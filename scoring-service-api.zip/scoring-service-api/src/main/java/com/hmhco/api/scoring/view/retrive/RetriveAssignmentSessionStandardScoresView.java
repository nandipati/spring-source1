package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.save.standardlevel.AssignmentItemToStandardMapView;

import lombok.Data;

import java.util.List;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/** Created by nandipatim on 3/1/18. */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RetriveAssignmentSessionStandardScoresView extends RetrieveStandardScoresView<StandardScoreExtView> {

  @JsonProperty(value = "standards")
  private List<StandardScoreExtView> standardScores;

  private Boolean standardScoresChanged;

  public RetriveAssignmentSessionStandardScoresView(UUID studentPersonId, UUID sessionId, UUID activityId, String
          testType, String resourceId, List<AssignmentItemToStandardMapView> itemToStandardMapping,
                                                    List<StandardView> standardViews) {
    super(studentPersonId, sessionId, activityId, testType, resourceId, itemToStandardMapping, standardViews);
    this.standardScores = standardScores;
    this.standardScoresChanged = standardScoresChanged;
  }

  public RetriveAssignmentSessionStandardScoresView() {

  }


  @Override
  public String toString() {
    return "RetriveAssignmentSessionStandardScoresView{"
            + "standardScores=" + standardScores
            + ", standardScoresChanged=" + standardScoresChanged
            + " Values from parent class=" + super.toString()
            + '}';
  }
}
