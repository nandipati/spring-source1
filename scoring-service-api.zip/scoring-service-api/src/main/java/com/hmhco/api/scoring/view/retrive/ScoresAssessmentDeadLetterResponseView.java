package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.save.ScoresAssessmentDeadLetterView;
import org.springframework.data.domain.Page;

/**
 * Created by pabonaj on 5/10/17.
 */
public class ScoresAssessmentDeadLetterResponseView {

  @JsonProperty("scoresAssessmentDeadLetter")
  private Page<ScoresAssessmentDeadLetterView> scoresAssessmentDeadLetterViews;

  public Page<ScoresAssessmentDeadLetterView> getScoresAssessmentDeadLetterViews() {
    return scoresAssessmentDeadLetterViews;
  }

  public void setScoresAssessmentDeadLetterViews(Page<ScoresAssessmentDeadLetterView> scoresAssessmentDeadLetterViews) {
    this.scoresAssessmentDeadLetterViews = scoresAssessmentDeadLetterViews;
  }

}
