package com.hmhco.api.scoring.view.retrive;

import com.hmhco.api.scoring.view.AbstractView;
import lombok.Data;

import java.util.List;
import java.util.UUID;

/**
 * Created by mfeng on 7/18/2018.
 */
@Data
public class SessionDetailView extends AbstractView {

  private UUID sessionId;

  private List<ItemView> items;

}
