package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;

import org.springframework.hateoas.core.Relation;


@Data
@JsonRootName("standardScore")
@Relation(value = "standardScore", collectionRelation = "standardScores")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StandardLevelScoreView extends StandardLevelScoreBaseView {

  private String standardName;
  private String description;

  @Override
  public String toString() {
    return "StandardLevelScoreView{"
        + "standardName='"
        + standardName
        + '\''
        + ", standardDesciption='"
        + description
        + '\''
        + "standardId="
        + this.getStandardId()
        + ", itemCount="
        + this.getItemCount()
        + ", totalPoints="
        + this.getTotalPoints()
        + ", attainedPoints="
        + this.getAttainedPoints()
        + ", correctItemsPoints="
        + this.getCorrectItemsPoints()
        + ", totalItemsCount="
        + this.getTotalItemsCount()
        + ", correctItemsCount="
        + this.getCorrectItemsCount()
        + ", avgItemsCorrect="
        + this.getAvgItemsCorrect()
        + ", avgPointsCorrect="
        + this.getAvgPointsCorrect()
        + ", standardProficiencyScore="
        + this.getStandardProficiencyScore()
        + '}';
  }
}
