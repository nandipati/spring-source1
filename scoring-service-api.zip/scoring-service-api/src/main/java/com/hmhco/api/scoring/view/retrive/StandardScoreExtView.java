package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StandardScoreExtView extends StandardScoreView {

  private Integer previousItemCount;
  private Integer previousTotalPoints;
  private Integer previousAttainedPoints;
  private Integer previousCorrectItemsPoints;
  private Integer previousTotalItemsCount;
  private Integer previousCorrectItemsCount;
  private Double previousAvgItemsCorrect;
  private Double previousAvgPointsCorrect;
  private Double previousStandardProficiencyScore;
  private Boolean standardScoreChanged;

  @Override
  public String toString() {
    return "StandardScoreExtView{"
            + "standardId=" + this.getStandardId() + ", itemCount=" + this.getItemCount()
            + ", totalPoints=" + this.getTotalPoints() + ", attainedPoints=" + this.getAttainedPoints()
            + ", correctItemsPoints=" + this.getAttainedPoints() + ", totalItemsCount=" + this.getTotalItemsCount()
            + ", correctItemsCount=" + this.getCorrectItemsCount() + ", avgItemsCorrect=" + this.getAvgItemsCorrect()
            + ", avgPointsCorrect=" + this.getAvgPointsCorrect() + ", standardProficiencyScore="
            + this.getStandardProficiencyScore()
            + "previousItemCount=" + previousItemCount + ", previousTotalPoints=" + previousTotalPoints
            + ", previousAttainedPoints=" + previousAttainedPoints
            + ", previousCorrectItemsPoints=" + previousCorrectItemsPoints
            + ", previousTotalItemsCount=" + previousTotalItemsCount
            + ", previousCorrectItemsCount=" + previousCorrectItemsCount
            + ", previousAvgItemsCorrect=" + previousAvgItemsCorrect
            + ", previousAvgPointsCorrect=" + previousAvgPointsCorrect
            + ", previousStandardProficiencyScore=" + previousStandardProficiencyScore
            + ", standardScoreChanged=" + standardScoreChanged
            + '}';
  }
}
