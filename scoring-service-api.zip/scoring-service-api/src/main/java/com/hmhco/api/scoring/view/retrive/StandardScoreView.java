package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.jsonserializer.DigitSerializer;
import com.hmhco.api.scoring.view.save.PerformanceBandView;

import lombok.Data;

import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

/**
 * Created by jayachandranj on 2/28/18.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StandardScoreView extends AbstractView {

  @Valid
  @NotNull
  private UUID standardId;
  private Integer itemCount;
  private Integer totalPoints;
  private Integer attainedPoints;
  private Integer correctItemsPoints;
  private Integer totalItemsCount;
  private Integer correctItemsCount;
  @JsonSerialize(using = DigitSerializer.class)
  private Double avgItemsCorrect;
  @JsonSerialize(using = DigitSerializer.class)
  private Double avgPointsCorrect;
  @JsonSerialize(using = DigitSerializer.class)
  private Double standardProficiencyScore;
  @Null
  private PerformanceBandView proficiencyBand;

  @Override
  public String toString() {
    return "StandardScoreView{" + "standardId=" + standardId + ", itemCount=" + itemCount + ", totalPoints="
        + totalPoints + ", attainedPoints=" + attainedPoints + ", correctItemsPoints=" + correctItemsPoints
        + ", totalItemsCount=" + totalItemsCount + ", correctItemsCount=" + correctItemsCount + ", avgItemsCorrect="
        + avgItemsCorrect + ", avgPointsCorrect=" + avgPointsCorrect + ", standardProficiencyScore="
        + standardProficiencyScore + '}';
  }
}
