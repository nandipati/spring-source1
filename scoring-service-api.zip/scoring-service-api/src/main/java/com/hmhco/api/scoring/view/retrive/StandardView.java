package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonView;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.config.View;
import lombok.Data;

import java.io.Serializable;
import java.util.UUID;

/**
 * Created by mfeng on 10/19/17.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class StandardView extends AbstractView implements Serializable {

  private UUID standardId;

  @JsonView(View.DetailView.class)
  private UUID domainId;

  @JsonView(View.DetailView.class)
  private String standardSetId;

  @JsonView(View.DetailView.class)
  private String description;

  @JsonView(View.DetailView.class)
  private String name;

  @JsonView(View.DetailView.class)
  private boolean status;

  @Override
  public String toString() {
    return "StandardView{"
            + "standardId=" + standardId
            + ", domainId=" + domainId
            + ", standardSetId='" + standardSetId + '\''
            + ", standardDescription='" + description + '\''
            + ", standardName='" + name + '\''
            + ", status=" + status + '}';
  }
}
