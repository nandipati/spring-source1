package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.config.View;
import com.hmhco.api.scoring.view.jsonserializer.DigitSerializer;
import com.hmhco.api.scoring.view.save.PerformanceBandView;
import lombok.Data;

import java.io.Serializable;
import java.util.UUID;
import javax.validation.constraints.Null;


@Data
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public class StudentView extends AbstractView implements Serializable {

  private String studentPersonRefid;

  @JsonView(View.DetailView.class)
  private UUID domainId;

  @JsonView(View.DetailView.class)
  private String standardSetId;

  @JsonView(View.DetailView.class)
  private String description;

  private Integer totalPoints;
  private Integer attainedPoints;
  private Integer correctItemsPoints;
  private Integer totalItemsCount;
  private Integer totalCorrectItemsCount;

  @JsonSerialize(using = DigitSerializer.class)
  private Double avgItemsCorrect;

  @JsonSerialize(using = DigitSerializer.class)
  private Double avgPointsCorrect;

  @JsonSerialize(using = DigitSerializer.class)
  private Double domainProficiencyScore;

  @Null private PerformanceBandView proficiencyBand;

  @JsonSerialize(using = DigitSerializer.class)
  private Double proficiencyPercentage;

  private Integer truncatedProficiencyPercentage;

  private Integer schoolYear;

  private Integer noOfStandards;

}
