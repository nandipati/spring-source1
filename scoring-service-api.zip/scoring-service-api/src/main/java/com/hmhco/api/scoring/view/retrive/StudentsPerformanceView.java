package com.hmhco.api.scoring.view.retrive;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.save.PerformanceBandView;
import lombok.Data;

import java.util.List;
import java.util.UUID;

/**
 * Created by jayachandranj on 5/8/18.
 */
@Data
public class StudentsPerformanceView extends PerformanceBandView {

  @JsonProperty("students")
  private List<String> students;


}
