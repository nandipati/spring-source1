package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.ItemResponse;
import com.hmhco.api.scoring.utils.ItemStatus;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;

import com.hmhco.api.scoring.view.jsonserializer.DigitSerializer;
import lombok.Data;

import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

/**
 * Created by suryadevarap on 2/10/16.
 */
@Data
@JsonRootName("itemScores")
@Relation(value = "itemScores", collectionRelation = "itemScores")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssignmentItemScoreView extends AbstractView {

  @NotNull
  private String itemRefId;
  @Null
  private UUID sessionId;
  @NotNull
  private Integer itemScore;
  @NotNull
  private Integer itemMaxScore;
  @NotNull
  @JsonSerialize(using = DigitSerializer.class)
  private Double itemProficiencyScore;
  @NotNull
  private ItemResponse itemResponse;
  private Integer time;
  @NotNull
  private String itemName;
  @NotNull
  private Boolean manualscoring;
  @NotNull
  private ItemStatus itemStatus;

  @Null
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime createdDate;
  @Null
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime updatedDate;

  public Boolean isItemCorrect() {
    return (ItemResponse.CORRECT == itemResponse);
  }

  public Boolean isScored() {
    return (ItemStatus.COMPLETED == itemStatus);
  }
}
