package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.config.JsonViews;
import com.hmhco.api.scoring.view.jsonserializer.DigitSerializer;
import lombok.Data;
import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

/** Created by suryadevarap on 2/10/16. */
@Data
@JsonRootName("totalScore")
@Relation(value = "totalScore", collectionRelation = "scores")
public class AssignmentTotalScoreView extends AbstractView {

  @Null
  private UUID sessionId;
  @NotNull
  private Integer itemsCorrect;
  @NotNull
  private Integer pointsCorrect;
  @NotNull
  private Integer totalPoints;
  @NotNull
  private Integer totalItems;
  @NotNull
  private Integer totalAttainedPoints;

  @NotNull
  @JsonSerialize(using = DigitSerializer.class)
  private Double totalProficiencyScore;

  private Integer totalTime;

  @Null
  @JsonSerialize(using = DigitSerializer.class)
  private Double totalProficiencyPercentage;

  private List<AssignmentItemScoreView> itemLevelScores = new ArrayList<AssignmentItemScoreView>();

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @JsonView(JsonViews.V2.class)
  private PerformanceBandView performanceBand;

  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime createdDate;

  @Null
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime updatedDate;
}
