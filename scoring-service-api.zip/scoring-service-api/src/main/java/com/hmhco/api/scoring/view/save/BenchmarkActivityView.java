package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.utils.Discipline;
import com.hmhco.api.scoring.utils.Grade;
import com.hmhco.api.scoring.utils.Level;
import com.hmhco.api.scoring.utils.Status;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.validation.constraints.NotNull;

/**
 * Created by suryadevarap on 2/1/16.
 */
@Data
@JsonRootName("activity")
@Relation(value = "activity", collectionRelation = "activities")
public class BenchmarkActivityView extends AbstractView {

  @NotNull
  private UUID activityId;
  @NotNull
  private Grade grade;
  @NotNull
  private Level level;
  private LocalDateTime normDate;
  private LocalDateTime startDate;
  private LocalDateTime finishDate;
  @NotNull
  private Discipline discipline;
  @NotBlank
  private String eventType;
  private Status status;

  private LocalDateTime createdDate;

  private LocalDateTime updatedDate;

}
