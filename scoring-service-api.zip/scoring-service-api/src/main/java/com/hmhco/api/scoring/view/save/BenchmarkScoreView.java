package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.utils.AchievementLevel;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.enums.CollegeReadiness;

import lombok.Data;

import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

/**
 * Created by suryadevarap on 2/1/16.
 */
@Data
@JsonRootName("scores")
@Relation(value = "scores", collectionRelation = "scores")
public class BenchmarkScoreView extends AbstractView {

  @Null
  private UUID sessionId;
  @NotNull
  private Long mapId;
  @NotNull
  private Double abilityEstimate;
  @NotNull
  private Double standardError;
  @NotNull
  private AchievementLevel achievementLevel;
  @NotNull
  private Integer numberAttempted;
  @NotNull
  private Integer numberQuestions;
  @NotNull
  private Integer maxScore;
  @NotNull
  private Integer score;
  @NotNull
  private Double scaleScore;
  private Double lpr;
  private Double ipFloor;
  private Double ipCeil;
  private Double lowerLimitPss;
  private Double upperLimitPss;
  private Double lowerLimitPnpr;
  private Double upperLimitPnpr;
  private String lowerLimitLexile;
  private String upperLimitLexile;
  private CollegeReadiness collegeReadiness;
  private Double completionCriteriaPercentage;
  private boolean completionCriteria;
  @Null
  private LocalDateTime createdDate;
  @Null
  private LocalDateTime updatedDate;

}
