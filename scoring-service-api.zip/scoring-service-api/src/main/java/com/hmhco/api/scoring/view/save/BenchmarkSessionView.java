package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.utils.Status;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

/**
 * Created by suryadevarap on 2/1/16.
 */
@Data
@JsonRootName("session")
@Relation(value = "session", collectionRelation = "sessions")
public class BenchmarkSessionView extends AbstractView {

  @NotNull
  private UUID sessionId;
  @Null
  private UUID activityRefId;
  @NotBlank
  private String studentPersonRefId;
  @NotNull
  private Status status;
  private Boolean itemsOmitted;
  private Boolean completionCriteriaNotMet;
  private Boolean inCompleteTestRecord;

  private boolean skippedQuestions;
  @Null
  private LocalDateTime createdDate;
  @Null
  private LocalDateTime updatedDate;

  @Valid
  @NotEmpty
  @JsonProperty("scores")
  private List<BenchmarkScoreView> benchmarkScoreViewList;

}
