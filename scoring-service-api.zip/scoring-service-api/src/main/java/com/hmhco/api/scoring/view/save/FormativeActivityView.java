package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.Discipline;
import com.hmhco.api.scoring.utils.Grade;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.utils.Level;
import com.hmhco.api.scoring.utils.Status;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

/**
 * Created by suryadevarap on 2/10/16.
 */
@Data
@JsonRootName("activity")
@Relation(value = "activity", collectionRelation = "activities")
public class FormativeActivityView extends AbstractView {
  @NotNull
  private UUID activityId;
  @Null
  private Grade grade;
  @Null
  private Level level;
  @Null
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime normDate;
  @Null
  private Discipline discipline;
  @NotBlank
  private String eventType;
  @NotNull
  private Status status;
  private String resourceId;
  private Boolean manualScoringRequired;
  private Boolean isAllowProvisionalScores;
  private Long startTimeInEngine;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime createdDate;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime updatedDate;

  @Valid
  @NotNull
  @JsonProperty("session")
  private FormativeSessionView formativeSessionView;

}
