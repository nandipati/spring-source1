package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.utils.Status;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

/**
 * Created by suryadevarap on 2/10/16.
 */
@Data
@JsonRootName("session")
@Relation(value = "session", collectionRelation = "sessiones")
public class FormativeSessionView extends AbstractView {

  @NotNull
  private UUID sessionId;
  @Null
  private UUID activityId;
  @NotBlank
  private String studentPersonRefId;
  @NotNull
  private Status status;
  @Null
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime createdDate;
  @Null
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime updatedDate;

  @Valid
  @NotEmpty
  @JsonProperty("itemScores")
  private List<AssignmentItemScoreView> assignmentItemScoreView;
  @Valid
  @NotNull
  @JsonProperty("totalScore")
  private AssignmentTotalScoreView assignmentTotalScoreView;

}
