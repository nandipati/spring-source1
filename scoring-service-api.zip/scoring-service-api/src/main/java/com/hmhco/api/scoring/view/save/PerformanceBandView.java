package com.hmhco.api.scoring.view.save;


import lombok.Data;

@Data
public class PerformanceBandView {

  private Integer bandSeq;
  private String id;
  private String name;

}
