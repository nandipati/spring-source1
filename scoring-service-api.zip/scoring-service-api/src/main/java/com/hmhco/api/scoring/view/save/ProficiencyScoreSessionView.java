package com.hmhco.api.scoring.view.save;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;


@Data
public class ProficiencyScoreSessionView {
  @Valid
  @NotNull
  @JsonProperty("scores")
  private List<AssignmentTotalScoreView> assignmentTotalScoreView;

}