package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.request.SaveBenchmarkStudentView;

import lombok.Data;

import org.hibernate.validator.constraints.NotBlank;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

@Data
@JsonRootName("thetaScore")
public class SaveBenchmarkThetaScoreView extends AbstractView {

  @NotBlank
  @JsonProperty("studentPersonRefId")
  private String studentPersonRefId;
  @NotNull
  @JsonProperty("sessionId")
  private UUID sessionId;
  @NotNull
  @JsonProperty("theta")
  private Double theta;
  @NotNull
  private LocalDateTime startDate;
  @NotNull
  private LocalDateTime finishDate;
  @NotNull
  private LocalDateTime normDate;
  @NotNull
  private String program;
  @NotNull
  private String grade;
  @NotNull
  private String level;
  @Null
  private LocalDateTime createdDate;
  @Null
  private LocalDateTime updatedDate;

  public SaveBenchmarkThetaScoreView() {

  }

  public SaveBenchmarkThetaScoreView(SaveBenchmarkStudentView saveStudentView, Double theta) {
    this.studentPersonRefId = saveStudentView.getBenchmarkSessionView().getStudentPersonRefId();
    this.sessionId = saveStudentView.getBenchmarkSessionView().getSessionId();
    this.theta = theta;
    this.startDate = saveStudentView.getBenchmarkActivityView().getStartDate();
    this.finishDate = saveStudentView.getBenchmarkActivityView().getFinishDate();
    this.normDate = saveStudentView.getBenchmarkActivityView().getNormDate();
    this.program = saveStudentView.getBenchmarkActivityView().getDiscipline().name();
    this.grade = saveStudentView.getBenchmarkActivityView().getGrade().getSymbol();
    this.level = saveStudentView.getBenchmarkActivityView().getLevel().getSymbol();
  }

}
