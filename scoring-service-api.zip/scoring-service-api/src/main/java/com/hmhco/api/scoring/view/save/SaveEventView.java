package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.enums.TestType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.hateoas.core.Relation;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;

import javax.validation.constraints.NotNull;

/**
 * Created by nandipatim on 4/4/17.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonRootName("event")
@Relation(value = "event", collectionRelation = "events")
public class SaveEventView extends AbstractView {

  private UUID activityId;
  private UUID eventId;
  private UUID sectionId;
  private String programId;
  private String disciplineId;
  private String disciplineName;
  @NotNull
  private TestType testType;
  @NotNull
  private LocalDateTime availableDate;
  @NotNull
  private LocalDateTime dueDate;

  private UUID leaRefId;

  private boolean manualScoringRequired;

  private Set<EventGroupView> eventGroups;
  private Set<StudentSessionToGroupView> studentSessionGroups;

  private String resourceId;

  private UUID staffPersonalRefId;

  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime createdDate;
  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime updatedDate;

}
