package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

import java.time.LocalDateTime;
import java.util.UUID;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

/**
 * Created by pabonaj on 4/27/17.
 */
@Data
@JsonRootName("scoresAssessmentDeadLetter")
public class ScoresAssessmentDeadLetterView extends AbstractView {

  @JsonProperty("scoresAssessmentDeadletterId")

  private Long scoresAssessmentDeadletterId;

  @NotNull
  @JsonProperty("messageId")
  private UUID messageId;

  @JsonProperty("failureType")
  private String failureType;

  @JsonProperty("failureEventType")
  private String failureEventType;

  @NotNull
  @JsonProperty("clientName")
  private String clientName;

  @JsonProperty("exception")
  private String exception;

  @JsonProperty("errorDetails")
  private String errorDetails;

  @NotNull
  @JsonProperty("data")
  private String data;

  @JsonProperty("status")
  private Integer status;

  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  @JsonProperty("failureDate")
  private LocalDateTime failureDate;

}
