package com.hmhco.api.scoring.view.save;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.hmhco.api.scoring.utils.JsonCommons;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

import javax.validation.constraints.NotNull;

/*
 * @author Lenko Donchev
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentSessionToGroupView extends AbstractView {

  @NotNull private UUID groupId;
  @NotNull private UUID studentRefId;
  @NotNull private UUID sessionId;

  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime createdDate;

  @JsonSerialize(using = JsonCommons.LocalDateTimeSerializer.class)
  @JsonDeserialize(using = JsonCommons.LocalDateTimeDeserializer.class)
  private LocalDateTime updatedDate;
}
