package com.hmhco.api.scoring.view.save;

import com.hmhco.api.scoring.view.AbstractView;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

import javax.validation.constraints.NotNull;

/*
 * @author Lenko Donchev
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StudentSessionsGroupView extends AbstractView {
  @NotNull private UUID studentPersonalRefId;
  @NotNull private UUID sessionId;
  @NotNull private UUID groupId;
}
