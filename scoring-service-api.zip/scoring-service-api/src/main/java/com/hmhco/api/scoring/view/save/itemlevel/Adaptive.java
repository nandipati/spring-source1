package com.hmhco.api.scoring.view.save.itemlevel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

import java.util.List;

/**
 * Created by fodori on 2/22/17.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "ability_estimate", "items", "exposed_items", "exposed_activities", "organisation_id",
                       "item_pool_id" })
public class Adaptive {

  @JsonProperty("ability_estimate")
  private AbilityEstimate abilityEstimate;

  @JsonProperty("items")
  private List<AdaptiveItem> items;

  @JsonProperty("exposed_items")
  private ExposedItems exposedItems;

  @JsonProperty("exposed_activities")
  private ExposedActivities exposedActivities;

  @JsonProperty("organisation_id")
  private Integer organisationId;

  @JsonProperty("item_pool_id")
  private String itemPoolId;

}
