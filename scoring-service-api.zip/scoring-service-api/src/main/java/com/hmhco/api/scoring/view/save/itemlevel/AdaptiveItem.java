package com.hmhco.api.scoring.view.save.itemlevel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by fodori on 2/22/17.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "reference", "score", "difficulty", "difficulty_target", "ability_estimate", "standard_error",
                       "estimation_method" })
public class AdaptiveItem {

  @JsonProperty("reference")
  private String reference;

  @JsonProperty("score")
  private Integer score;

  @JsonProperty("difficulty")
  private BigDecimal difficulty;

  @JsonProperty("difficulty_target")
  private BigDecimal difficultyTarget;

  @JsonProperty("ability_estimate")
  private BigDecimal abilityEstimate;

  @JsonProperty("standard_error")
  private BigDecimal standardError;

  @JsonProperty("estimation_method")
  private String estimationMethod;

  @JsonProperty("tags")
  private List<Tag> tags;

}
