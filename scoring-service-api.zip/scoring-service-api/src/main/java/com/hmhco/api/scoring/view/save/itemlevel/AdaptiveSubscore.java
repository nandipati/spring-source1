package com.hmhco.api.scoring.view.save.itemlevel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

import java.util.List;

/**
 * Created by fodori on 2/23/17.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "id", "title", "num_questions", "num_attempted", "num_unmarked", "score", "max_score",
                       "attempted_max_score", "unmarked_max_score", "items", "ability_estimate" })
public class AdaptiveSubscore {

  @JsonProperty("id")
  private String id;

  @JsonProperty("title")
  private String title;

  @JsonProperty("num_questions")
  private Integer numQuestions;

  @JsonProperty("num_attempted")
  private Integer numAttempted;

  @JsonProperty("num_unmarked")
  private Integer numUnmarked;

  @JsonProperty("score")
  private Integer score;

  @JsonProperty("max_score")
  private Integer maxScore;

  @JsonProperty("attempted_max_score")
  private Integer attemptedMaxScore;

  @JsonProperty("unmarked_max_score")
  private Integer unmarkedMaxScore;

  @JsonProperty("items")
  private List<String> items;

  @JsonProperty("ability_estimate")
  private AbilityEstimate abilityEstimate;

}
