package com.hmhco.api.scoring.view.save.itemlevel;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;
import org.springframework.hateoas.core.Relation;

import java.util.Map;

/**
 * Created by fodori on 4/10/17.
 */
@Data
@JsonRootName("itemResponse")
@Relation(value = "itemResponse", collectionRelation = "itemResponses")
public class BenchmarkItemResponseView extends AbstractView {

  @JsonProperty("response_id")
  private String responseId;

  @JsonProperty("question_type")
  private String questionType;

  @JsonProperty("automarkable")
  private Boolean automarkable;

  @JsonProperty("attempted")
  private Boolean attempted;

  @JsonProperty("max_score")
  private Integer maxScore;

  @JsonProperty("score")
  private Integer score;

  @JsonProperty("question_reference")
  private String questionReference;

  @JsonProperty("item_reference")
  private String itemRefId;

  @JsonProperty("manual_score")
  private Integer manualScore;

  @JsonProperty("manual_max_score")
  private Integer manualMaxScore;

  @JsonProperty("response")
  private Map<String,Object> response;
}
