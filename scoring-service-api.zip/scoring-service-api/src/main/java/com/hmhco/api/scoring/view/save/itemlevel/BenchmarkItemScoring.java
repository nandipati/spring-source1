package com.hmhco.api.scoring.view.save.itemlevel;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

/**
 * Created by fodori on 3/22/17.
 */
@Data
public class BenchmarkItemScoring extends AbstractView {

  @JsonProperty("score")
  private Integer score;

  @JsonProperty("max_score")
  private Integer maxScore;

  @JsonProperty("type")
  private String itemType;

  @JsonProperty("max_score_of_attempted")
  private Integer maxScoreAttempted;

  @JsonProperty("max_score_of_unmarked")
  private Integer maxScoreUnmarked;



}
