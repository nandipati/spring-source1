package com.hmhco.api.scoring.view.save.itemlevel;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import org.springframework.hateoas.core.Relation;

import java.util.List;

/**
 * Created by fodori on 3/22/17.
 */
@Data
@JsonRootName("item")
@Relation(value = "item", collectionRelation = "items")
public class BenchmarkItemView extends AbstractView {

  @JsonProperty("reference")
  private String itemReference;

  @JsonProperty("time")
  private Integer time;

  @JsonProperty("user_flagged")
  private Boolean userFlagged;

  @JsonProperty("response_ids")
  private List<String> responseIds;

  @JsonProperty("scoring")
  private BenchmarkItemScoring scoring;

}
