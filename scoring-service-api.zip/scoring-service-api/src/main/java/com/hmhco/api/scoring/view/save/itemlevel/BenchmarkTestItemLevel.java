package com.hmhco.api.scoring.view.save.itemlevel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.hmhco.api.scoring.utils.StringToIntegerDeserializer;

import lombok.Data;

import java.util.List;
import java.util.UUID;

/**
 * Created by fodori on 2/22/17.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "meta", "user_id", "activity_id", "num_attempted", "num_questions", "session_id", "score",
                       "max_score", "subscores", "session_duration", "status", "dt_started", "dt_completed",
                       "adaptive" })
public class BenchmarkTestItemLevel {

  @JsonProperty("meta")
  private Meta meta;

  @JsonProperty("session_id")
  private UUID sessionId;

  @JsonProperty("user_id")
  private UUID userId;

  @JsonProperty("school_id")
  private UUID schoolId;

  @JsonProperty("activity_id")
  private UUID activityId;

  @JsonProperty("num_attempted")
  private Integer numAttempted;

  @JsonProperty("num_questions")
  private Integer numQuestions;

  @JsonProperty("score")
  private Integer score;

  @JsonProperty("max_score")
  // TODO: remove once Learnosity sends correct integers for max_score in the adaptive message
  @JsonDeserialize(using = StringToIntegerDeserializer.class)
  @JsonTypeInfo(use = JsonTypeInfo.Id.NONE)
  private Integer maxScore;

  @JsonProperty("subscores")
  private List<AdaptiveSubscore> subscores;

  @JsonProperty("session_duration")
  private Integer sessionDuration;

  @JsonProperty("status")
  private String status;

  @JsonProperty("dt_started")
  private String dtStarted;

  @JsonProperty("dt_completed")
  private String dtCompleted;

  @JsonProperty("adaptive")
  private Adaptive adaptive;
}
