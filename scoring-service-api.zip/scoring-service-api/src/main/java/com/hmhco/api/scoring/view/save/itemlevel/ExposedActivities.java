package com.hmhco.api.scoring.view.save.itemlevel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

import java.util.List;

/**
 * Created by fodori on 2/22/17.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "operational", "seeding" })
public class ExposedActivities {

  @JsonProperty("operational")
  private List<String> operational = null;

  @JsonProperty("seeding")
  private List<String> seeding = null;

}
