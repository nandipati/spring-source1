package com.hmhco.api.scoring.view.save.itemlevel;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hmhco.api.scoring.view.AbstractView;

import lombok.Data;

import java.util.List;

/**
 * Created by fodori on 4/10/17.
 */
@Data
public class Response extends AbstractView {

  @JsonProperty("value")
  private List<String> value;

  @JsonProperty("wordCount")
  private Integer wordCount;

  @JsonProperty("type")
  private String type;

  @JsonProperty("apiVersion")
  private String apiVersion;
}
