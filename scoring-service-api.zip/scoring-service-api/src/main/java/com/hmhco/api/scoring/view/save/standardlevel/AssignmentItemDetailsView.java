package com.hmhco.api.scoring.view.save.standardlevel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.view.AbstractView;
import lombok.Data;

import org.springframework.hateoas.core.Relation;

import javax.validation.constraints.Null;

/** Created by nandipatim on 2/28/18. */
@Data
@JsonRootName("itemDetail")
@Relation(value = "itemDetail", collectionRelation = "itemDetails")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssignmentItemDetailsView extends AbstractView {

  @Null private String itemRefId;

  private String itemName;

  private String itemPosition;

  private String depthOfKnowledge;

  private Boolean manuallyScorable;

  @Override
  public String toString() {
    return "AssignmentItemDetailsView{"
        + "itemRefId='"
        + itemRefId
        + '\''
        + ", itemName='"
        + itemName
        + '\''
        + ", itemPosition='"
        + itemPosition
        + '\''
        + ", depthOfKnowledge='"
        + depthOfKnowledge
        + '\''
        + ", manuallyScorable="
        + manuallyScorable
        + '}';
  }
}
