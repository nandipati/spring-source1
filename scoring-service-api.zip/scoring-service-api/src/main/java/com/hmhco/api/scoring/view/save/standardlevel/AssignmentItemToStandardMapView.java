package com.hmhco.api.scoring.view.save.standardlevel;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.hmhco.api.scoring.view.AbstractView;
import com.hmhco.api.scoring.view.retrive.DomainStandardView;

import lombok.Data;
import org.springframework.hateoas.core.Relation;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * Created by nandipatim on 2/27/18.
 */
@Data
@JsonRootName("itemToStandardMap")
@Relation(value = "itemToStandardMap", collectionRelation = "itemToStandardMaps")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssignmentItemToStandardMapView extends AbstractView {

  @Valid
  @NotNull
  private String itemRefId;

  //Use this if we want to use all the List of Standards with out Standard Set Maping
  private List<UUID> standards;

  //Use below if you want to provide Standard Set to standards (Domain View will have List<Standard>)
  @JsonProperty(value = "standardSet")
  private Map<String,List<DomainStandardView>> standardsetToStandards;
  
  private AssignmentItemDetailsView itemDetails;

  @Override
  public String toString() {
    return "AssignmentItemToStandardMapView{" + "itemRefId='" + itemRefId + '\''
            + ", standards=" + standards + ", standardsetToStandards=" + standardsetToStandards
            + ", itemDetails=" + itemDetails + '}';
  }
}
