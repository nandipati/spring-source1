package com.hmhco.api.scoring.view.standardset;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class StandardSetMssStandard {

  @JsonProperty("TOPIC")
  List<StandardSetMssStandardTopic> listMssStandardTopic;
}
