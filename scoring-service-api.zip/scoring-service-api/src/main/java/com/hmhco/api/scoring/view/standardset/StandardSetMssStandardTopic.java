package com.hmhco.api.scoring.view.standardset;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class StandardSetMssStandardTopic {

  @JsonProperty("id")
  String id;

  @JsonProperty("level")
  String level;

  @JsonProperty("state_num")
  String name;

  @JsonProperty("label")
  String label;

  @JsonProperty("value")
  String description;

  @JsonProperty("TOPIC")
  List<StandardSetMssStandardTopic> subTopics;

  String parentId;
  String domainId;
  String standardSetId;
}
