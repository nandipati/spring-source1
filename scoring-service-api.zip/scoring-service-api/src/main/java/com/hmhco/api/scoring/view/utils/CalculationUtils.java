package com.hmhco.api.scoring.view.utils;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.IntStream;

/** Created by odowdj on 13/Oct/15. */
public class CalculationUtils {
  private static final int DEFAULT_DECIMAL_PLACES = 2;

  public static int sumContents(int[] array) {
    int sum = 0;
    if (array != null) {
      sum = IntStream.of(array).sum();
    }
    return sum;
  }

  public static Double sumContents(List<Double> list) {
    Double sum = 0D;
    if (list != null) {
      sum = list.stream().reduce(0.0, Double::sum);
    }
    return sum;
  }

  public static String roundto2Decimal(double value) {
    return String.format("%.2f", roundValue(value, "2"));
  }

  public static String roundtoDecimal(double value, int scale) {
    return String.format("%." + scale + "f", roundValue(value, scale));
  }

  public static double roundValue(double value, String scale) {
    return scale == null ? value : roundValue(value, Integer.parseInt(scale));
  }

  public static double roundValue(double value, Integer scale) {
    if (scale == null || scale < 0) {
      return value; // by default no rounding
    }
    return BigDecimal.valueOf(value).setScale(scale, BigDecimal.ROUND_HALF_UP).doubleValue();
  }
}
