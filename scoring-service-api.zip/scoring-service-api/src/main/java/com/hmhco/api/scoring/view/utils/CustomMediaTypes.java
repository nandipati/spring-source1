package com.hmhco.api.scoring.view.utils;

import org.springframework.http.MediaType;

import java.nio.charset.Charset;

public interface CustomMediaTypes {

  MediaType CSV_MEDIA_TYPE = new MediaType("text", "csv", Charset.forName("utf-8"));
  String CSV_MEDIA_TYPE_VALUE = "text/csv";
}
