package com.hmhco.api.scoring.view.utils;

import com.hmhco.api.scoring.view.config.ScoringEndpoint;
import com.hmhco.api.scoring.view.config.SupportedVersion;

/** Created by mfeng on 11/28/2017. */
public class EndpointVersionUtil {

  public static boolean isSupportedVersion(String version, ScoringEndpoint reportingEndpoint) {

    if (reportingEndpoint == null
        || reportingEndpoint.getSupportedVersions() == null
        || version == null) {
      return false;
    }

    SupportedVersion supportedVersion = SupportedVersion.fromStringSafe(version);

    if (supportedVersion == null) {
      return false;
    }

    return reportingEndpoint.getSupportedVersions().contains(supportedVersion);
  }
}
